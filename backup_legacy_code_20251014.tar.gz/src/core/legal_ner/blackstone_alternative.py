"""
Alternative to Blackstone for Legal NER - Compatible with Python 3.12+
Uses spaCy with legal entity patterns instead of the Blackstone library
"""

import spacy
from spacy.tokens import Span, Doc
from spacy.language import Language
from typing import List, Dict, Tuple, Optional
import re
import logging

logger = logging.getLogger(__name__)

# Legal entity patterns for NER
LEGAL_PATTERNS = {
    "CASE": [
        r"\b[A-Z][a-z]+\s+v\.?\s+[A-Z][a-z]+\b",  # Smith v. Jones
        r"\bIn re\s+[A-Z][a-z]+\b",  # In re Smith
        r"\bEx parte\s+[A-Z][a-z]+\b",  # Ex parte Smith
        r"\bMatter of\s+[A-Z][a-z]+\b",  # Matter of Smith
    ],
    "COURT": [
        r"\b(?:Supreme|Superior|District|Circuit|Appellate|Bankruptcy)\s+Court\b",
        r"\b(?:U\.S\.|United States)\s+(?:Supreme|District)\s+Court\b",
        r"\b(?:First|Second|Third|Fourth|Fifth|Sixth|Seventh|Eighth|Ninth|Tenth|Eleventh|D\.C\.)\s+Circuit\b",
        r"\b[A-Z][a-z]+\s+(?:County|State)\s+Court\b",
    ],
    "JUDGE": [
        r"\b(?:Judge|Justice|Magistrate|Hon\.|Honorable)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?\b",
        r"\b[A-Z][a-z]+,?\s+(?:C\.J\.|J\.|A\.J\.)\b",  # Smith, J.
    ],
    "LEGISLATION": [
        r"\b\d+\s+U\.S\.C\.\s+§?\s*\d+\b",  # 42 U.S.C. § 1983
        r"\b\d+\s+C\.F\.R\.\s+§?\s*\d+\.\d+\b",  # 45 C.F.R. § 164.502
        r"\bPublic Law\s+\d+-\d+\b",
        r"\b(?:Act|Code|Statute)\s+of\s+\d{4}\b",
    ],
    "LAW_FIRM": [
        r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:LLP|LLC|P\.C\.|P\.A\.|L\.L\.C\.|L\.L\.P\.)\b",
        r"\b[A-Z][a-z]+\s+(?:&|and)\s+[A-Z][a-z]+(?:\s+(?:LLP|LLC))?\b",
        r"\b[A-Z][a-z]+,\s+[A-Z][a-z]+\s+(?:&|and)\s+[A-Z][a-z]+\b",
    ],
    "ATTORNEY": [
        r"\b[A-Z][a-z]+\s+[A-Z][a-z]+,?\s+(?:Esq\.|Esquire|Attorney)\b",
        r"\b(?:Attorney|Counsel)\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b",
    ],
    "LEGAL_PROVISION": [
        r"\b(?:Section|Sec\.|§)\s+\d+(?:\.\d+)*\b",
        r"\b(?:Article|Art\.)\s+[IVXLCDM]+\b",
        r"\b(?:Rule|Regulation|Provision)\s+\d+(?:\.\d+)*\b",
        r"\b(?:Paragraph|Para\.)\s+\d+(?:\([a-z]\))*\b",
    ],
    "LEGAL_INSTRUMENT": [
        r"\b(?:Contract|Agreement|Treaty|Convention|Charter|Constitution)\b",
        r"\b(?:Motion|Brief|Complaint|Petition|Order|Judgment|Verdict|Settlement)\b",
        r"\b(?:Warrant|Subpoena|Summons|Writ|Injunction|Decree)\b",
    ],
}


class LegalNER:
    """
    Legal Named Entity Recognition - Alternative to Blackstone
    Compatible with modern Python and SpaCy versions
    """
    
    def __init__(self, nlp: Optional[Language] = None):
        """Initialize Legal NER with SpaCy model"""
        if nlp is None:
            try:
                # Try to load transformer model first
                self.nlp = spacy.load("en_core_web_trf")
                logger.info("Loaded transformer-based SpaCy model")
            except:
                try:
                    # Fall back to large model
                    self.nlp = spacy.load("en_core_web_lg")
                    logger.info("Loaded large SpaCy model")
                except:
                    # Fall back to medium model
                    self.nlp = spacy.load("en_core_web_md")
                    logger.info("Loaded medium SpaCy model")
        else:
            self.nlp = nlp
            
        # Add custom component to pipeline
        if "legal_ner" not in self.nlp.pipe_names:
            self.nlp.add_pipe("legal_ner", last=True)
            
        # Compile patterns
        self.compiled_patterns = self._compile_patterns()
        
    def _compile_patterns(self) -> Dict[str, List[re.Pattern]]:
        """Compile regex patterns for efficiency"""
        compiled = {}
        for entity_type, patterns in LEGAL_PATTERNS.items():
            compiled[entity_type] = [re.compile(pattern, re.IGNORECASE) for pattern in patterns]
        return compiled
    
    def __call__(self, text: str) -> Doc:
        """Process text and return SpaCy Doc with legal entities"""
        return self.nlp(text)
    
    def extract_entities(self, text: str) -> List[Dict]:
        """Extract legal entities from text"""
        doc = self.nlp(text)
        entities = []
        
        # Get SpaCy's built-in entities
        for ent in doc.ents:
            entities.append({
                "text": ent.text,
                "type": ent.label_,
                "start": ent.start_char,
                "end": ent.end_char,
                "source": "spacy"
            })
        
        # Add legal-specific entities
        legal_entities = doc._.legal_entities if hasattr(doc._, "legal_entities") else []
        for ent in legal_entities:
            entities.append({
                "text": ent["text"],
                "type": ent["type"],
                "start": ent["start"],
                "end": ent["end"],
                "source": "legal_ner"
            })
        
        return entities


@Language.component("legal_ner")
def legal_ner_component(doc: Doc) -> Doc:
    """SpaCy component for legal NER"""
    
    legal_entities = []
    text = doc.text
    
    # Extract legal entities using patterns
    for entity_type, patterns in LEGAL_PATTERNS.items():
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                legal_entities.append({
                    "text": match.group(),
                    "type": entity_type,
                    "start": match.start(),
                    "end": match.end()
                })
    
    # Store in doc
    if not hasattr(doc._, "legal_entities"):
        Doc.set_extension("legal_entities", default=[], force=True)
    doc._.legal_entities = legal_entities
    
    # Also add as SpaCy entities where they don't overlap
    existing_spans = [(ent.start_char, ent.end_char) for ent in doc.ents]
    new_ents = list(doc.ents)
    
    for ent in legal_entities:
        # Check for overlap
        overlaps = False
        for start, end in existing_spans:
            if (ent["start"] >= start and ent["start"] < end) or \
               (ent["end"] > start and ent["end"] <= end):
                overlaps = True
                break
        
        if not overlaps:
            # Find token indices
            start_token = None
            end_token = None
            for token in doc:
                if token.idx == ent["start"]:
                    start_token = token.i
                if token.idx + len(token.text) == ent["end"]:
                    end_token = token.i + 1
                    
            if start_token is not None and end_token is not None:
                span = Span(doc, start_token, end_token, label=ent["type"])
                new_ents.append(span)
                existing_spans.append((ent["start"], ent["end"]))
    
    # Filter out duplicates and overlaps
    filtered_ents = []
    seen_spans = set()
    for ent in sorted(new_ents, key=lambda x: (x.start_char, x.end_char)):
        span_key = (ent.start_char, ent.end_char)
        if span_key not in seen_spans:
            filtered_ents.append(ent)
            seen_spans.add(span_key)
    
    doc.ents = filtered_ents
    return doc


# Convenience function to create a legal NER pipeline
def load_legal_ner() -> LegalNER:
    """Load legal NER model (Blackstone alternative)"""
    return LegalNER()


# Make it compatible with Blackstone API
class BlackstoneCompatible:
    """Wrapper to make this compatible with Blackstone API"""
    
    def __init__(self):
        self.ner = LegalNER()
    
    def __call__(self, text: str) -> Doc:
        """Process text like Blackstone would"""
        return self.ner(text)
    
    @staticmethod
    def load() -> Language:
        """Load method compatible with Blackstone"""
        ner = LegalNER()
        return ner.nlp


# For drop-in replacement
blackstone = BlackstoneCompatible()