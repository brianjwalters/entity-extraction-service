"""
Enhanced CALES Configuration for Pattern-Guided Extraction

This module provides enhanced configuration for CALES that integrates with the
new dynamic prompt builder and pattern-based examples from the YAML files.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

logger = logging.getLogger(__name__)


class ExtractionMode(Enum):
    """Enhanced extraction modes for CALES."""
    REGEX_ONLY = "regex"
    AI_ENHANCED = "ai_enhanced"
    HYBRID = "hybrid"  # Default: Uses both patterns and AI with enhanced prompts
    PATTERN_GUIDED = "pattern_guided"  # New: AI guided by pattern examples


class ExtractionStrategy(Enum):
    """Extraction strategies for CALES."""
    UNIFIED = "unified"  # Single comprehensive pass
    MULTIPASS = "multipass"  # 7 specialized passes
    AUTO = "auto"  # Automatically select based on document complexity


@dataclass
class EnhancedCALESConfig:
    """
    Enhanced configuration for CALES service with pattern integration.
    """
    
    # === Core Extraction Configuration ===
    extraction_mode: ExtractionMode = ExtractionMode.HYBRID
    extraction_strategy: ExtractionStrategy = ExtractionStrategy.AUTO
    
    # === Pattern Integration Settings ===
    enable_pattern_examples: bool = True
    pattern_service_url: str = "http://10.10.0.87:8007"
    max_examples_per_entity: int = 3
    pattern_confidence_boost: float = 0.15  # Boost confidence for pattern matches
    enable_pattern_validation: bool = True
    
    # === Enhanced Model Configuration ===
    enable_dynamic_models: bool = True
    enable_context_resolution: bool = True
    enable_relationship_extraction: bool = True
    enable_unpatterned_handling: bool = True
    
    # === Confidence Thresholds (Enhanced) ===
    context_confidence_threshold: float = 0.6
    relationship_confidence_threshold: float = 0.5
    unpatterned_confidence_threshold: float = 0.4
    pattern_match_threshold: float = 0.7  # Minimum confidence for pattern-based extraction
    ai_enhancement_threshold: float = 0.6  # Minimum confidence for AI enhancement
    
    # === Performance Settings ===
    batch_size: int = 10
    max_concurrent_extractions: int = 5
    enable_parallel_processing: bool = True
    processing_timeout_seconds: int = 600  # 10 minutes
    
    # === Cache Settings (Enhanced) ===
    cache_contexts: bool = True
    cache_relationships: bool = True
    cache_pattern_examples: bool = True  # New: Cache pattern examples
    cache_enhanced_prompts: bool = True  # New: Cache generated prompts
    cache_ttl_seconds: int = 3600
    pattern_cache_size: int = 1000
    
    # === Integration Settings ===
    fallback_to_base_models: bool = True
    backward_compatibility: bool = True
    enable_caching: bool = True
    
    # === Quality Assurance ===
    enable_cross_validation: bool = True  # Validate AI results against patterns
    enable_confidence_calibration: bool = True
    min_entity_length: int = 2
    max_entity_length: int = 500
    
    # === Monitoring and Debugging ===
    enable_performance_monitoring: bool = True
    enable_extraction_metrics: bool = True
    enable_debug_logging: bool = False
    log_prompt_generation: bool = False
    log_pattern_matches: bool = False
    
    # === Multipass Configuration ===
    multipass_passes: List[Dict[str, Any]] = field(default_factory=lambda: [
        {
            "pass_number": 1,
            "name": "Core Legal Entities",
            "entity_types": ["CASE_CITATION", "STATUTE_CITATION", "PARTY", "ATTORNEY", "COURT", "JUDGE"],
            "confidence_threshold": 0.9,
            "examples_per_type": 4
        },
        {
            "pass_number": 2,
            "name": "Legal Citations & References",
            "entity_types": ["USC_CITATION", "CFR_CITATION", "STATE_STATUTE_CITATION", "CONSTITUTIONAL_CITATION"],
            "confidence_threshold": 0.85,
            "examples_per_type": 4
        },
        {
            "pass_number": 3,
            "name": "Case Information & Procedural Elements",
            "entity_types": ["CASE_NUMBER", "DOCKET_NUMBER", "MOTION", "BRIEF", "PROCEDURAL_RULE"],
            "confidence_threshold": 0.8,
            "examples_per_type": 3
        },
        {
            "pass_number": 4,
            "name": "Dates, Deadlines & Temporal Information",
            "entity_types": ["DATE", "FILING_DATE", "DEADLINE", "HEARING_DATE", "TRIAL_DATE"],
            "confidence_threshold": 0.85,
            "examples_per_type": 3
        },
        {
            "pass_number": 5,
            "name": "Financial & Monetary Elements",
            "entity_types": ["MONETARY_AMOUNT", "DAMAGES", "FINE", "FEE", "AWARD"],
            "confidence_threshold": 0.8,
            "examples_per_type": 3
        },
        {
            "pass_number": 6,
            "name": "Legal Professionals & Organizations",
            "entity_types": ["LAW_FIRM", "PROSECUTOR", "PUBLIC_DEFENDER", "GOVERNMENT_ENTITY"],
            "confidence_threshold": 0.75,
            "examples_per_type": 2
        },
        {
            "pass_number": 7,
            "name": "Geographic & Miscellaneous Entities",
            "entity_types": ["ADDRESS", "EMAIL", "PHONE_NUMBER", "BAR_NUMBER", "CORPORATION"],
            "confidence_threshold": 0.7,
            "examples_per_type": 2
        }
    ])
    
    # === Advanced Features ===
    enable_entity_linking: bool = True
    enable_coreference_resolution: bool = True
    enable_semantic_validation: bool = True
    enable_bluebook_compliance: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "extraction_mode": self.extraction_mode.value,
            "extraction_strategy": self.extraction_strategy.value,
            "enable_pattern_examples": self.enable_pattern_examples,
            "pattern_service_url": self.pattern_service_url,
            "max_examples_per_entity": self.max_examples_per_entity,
            "pattern_confidence_boost": self.pattern_confidence_boost,
            "enable_pattern_validation": self.enable_pattern_validation,
            "context_confidence_threshold": self.context_confidence_threshold,
            "relationship_confidence_threshold": self.relationship_confidence_threshold,
            "pattern_match_threshold": self.pattern_match_threshold,
            "ai_enhancement_threshold": self.ai_enhancement_threshold,
            "batch_size": self.batch_size,
            "max_concurrent_extractions": self.max_concurrent_extractions,
            "enable_parallel_processing": self.enable_parallel_processing,
            "cache_pattern_examples": self.cache_pattern_examples,
            "cache_enhanced_prompts": self.cache_enhanced_prompts,
            "enable_cross_validation": self.enable_cross_validation,
            "enable_performance_monitoring": self.enable_performance_monitoring,
            "multipass_passes": len(self.multipass_passes),
            "advanced_features": {
                "entity_linking": self.enable_entity_linking,
                "coreference_resolution": self.enable_coreference_resolution,
                "semantic_validation": self.enable_semantic_validation,
                "bluebook_compliance": self.enable_bluebook_compliance
            }
        }
    
    @classmethod
    def for_production(cls) -> 'EnhancedCALESConfig':
        """Create production-optimized configuration."""
        return cls(
            extraction_mode=ExtractionMode.HYBRID,
            extraction_strategy=ExtractionStrategy.AUTO,
            enable_pattern_examples=True,
            pattern_confidence_boost=0.15,
            enable_pattern_validation=True,
            context_confidence_threshold=0.7,
            relationship_confidence_threshold=0.6,
            pattern_match_threshold=0.8,
            ai_enhancement_threshold=0.7,
            batch_size=15,
            max_concurrent_extractions=8,
            enable_parallel_processing=True,
            cache_pattern_examples=True,
            cache_enhanced_prompts=True,
            enable_cross_validation=True,
            enable_performance_monitoring=True,
            enable_debug_logging=False
        )
    
    @classmethod
    def for_development(cls) -> 'EnhancedCALESConfig':
        """Create development-friendly configuration."""
        return cls(
            extraction_mode=ExtractionMode.HYBRID,
            extraction_strategy=ExtractionStrategy.UNIFIED,
            enable_pattern_examples=True,
            pattern_confidence_boost=0.10,
            enable_pattern_validation=True,
            context_confidence_threshold=0.6,
            relationship_confidence_threshold=0.5,
            pattern_match_threshold=0.7,
            ai_enhancement_threshold=0.6,
            batch_size=5,
            max_concurrent_extractions=3,
            enable_debug_logging=True,
            log_prompt_generation=True,
            log_pattern_matches=True
        )
    
    @classmethod
    def for_testing(cls) -> 'EnhancedCALESConfig':
        """Create testing configuration with aggressive caching."""
        return cls(
            extraction_mode=ExtractionMode.PATTERN_GUIDED,
            extraction_strategy=ExtractionStrategy.MULTIPASS,
            enable_pattern_examples=True,
            pattern_confidence_boost=0.20,
            enable_pattern_validation=True,
            context_confidence_threshold=0.5,
            relationship_confidence_threshold=0.4,
            pattern_match_threshold=0.6,
            ai_enhancement_threshold=0.5,
            batch_size=3,
            max_concurrent_extractions=2,
            cache_ttl_seconds=7200,  # 2 hours for testing
            enable_debug_logging=True,
            log_prompt_generation=True,
            log_pattern_matches=True,
            processing_timeout_seconds=60  # Shorter timeout for tests
        )


def get_enhanced_cales_config(environment: str = "production") -> EnhancedCALESConfig:
    """
    Get CALES configuration for the specified environment.
    
    Args:
        environment: "production", "development", or "testing"
        
    Returns:
        Configured EnhancedCALESConfig instance
    """
    if environment == "production":
        return EnhancedCALESConfig.for_production()
    elif environment == "development":
        return EnhancedCALESConfig.for_development()
    elif environment == "testing":
        return EnhancedCALESConfig.for_testing()
    else:
        logger.warning(f"Unknown environment '{environment}', using production config")
        return EnhancedCALESConfig.for_production()


# Default configuration instance
DEFAULT_ENHANCED_CALES_CONFIG = EnhancedCALESConfig.for_production()