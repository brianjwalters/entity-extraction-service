"""
Hybrid Extraction Pipeline for CALES

Combines multiple extraction methods for optimal performance:
1. Fast regex patterns (primary)
2. Lightweight NER models (DistilBERT, Legal-BERT)
3. Optional direct vLLM for complex cases
"""

import logging
import time
import asyncio
from typing import List, Dict, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json

# Import extractors
from .direct_vllm_extractor import DirectVLLMExtractor, MiniVLLMExtractor, ExtractedEntity as VLLMEntity
from .lightweight_ner_extractor import (
    HybridNERExtractor, 
    NEREntity,
    DistilBERTNERExtractor,
    LegalBERTSmallExtractor,
    ZeroShotEntityExtractor
)

# Import pattern loader
try:
    from utils.pattern_loader import PatternLoader, CompiledPattern
    PATTERN_LOADER_AVAILABLE = True
except ImportError:
    try:
        from src.utils.pattern_loader import PatternLoader, CompiledPattern
        PATTERN_LOADER_AVAILABLE = True
    except ImportError:
        PATTERN_LOADER_AVAILABLE = False
        logging.warning("Pattern loader not available")

logger = logging.getLogger(__name__)


class ExtractionMode(Enum):
    """Extraction modes for the pipeline"""
    REGEX_ONLY = "regex_only"
    FAST_AI = "fast_ai"  # Regex + lightweight NER
    FULL_AI = "full_ai"  # All methods including vLLM
    HYBRID = "hybrid"  # Adaptive based on document


@dataclass
class ExtractionConfig:
    """Configuration for extraction pipeline"""
    mode: ExtractionMode = ExtractionMode.HYBRID
    enable_regex: bool = True
    enable_fast_ai: bool = True
    enable_vllm: bool = False  # Disabled by default due to performance
    enable_context: bool = True
    enable_relationships: bool = True
    enable_unpatterned: bool = True
    
    # Performance settings
    max_document_size_for_vllm: int = 5000  # Characters
    chunk_size: int = 2000
    batch_size: int = 32
    confidence_threshold: float = 0.6
    
    # Entity filtering
    entity_types: Optional[List[str]] = None
    unpatterned_types: Optional[List[str]] = None


@dataclass
class UnifiedEntity:
    """Unified entity format for all extraction methods"""
    text: str
    entity_type: str
    start_pos: Optional[int]
    end_pos: Optional[int]
    confidence: float
    extraction_method: str
    context: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExtractionResult:
    """Result from hybrid extraction pipeline"""
    entities: List[UnifiedEntity]
    extraction_time_ms: float
    methods_used: List[str]
    entity_count_by_method: Dict[str, int]
    performance_metrics: Dict[str, float]
    warnings: List[str] = field(default_factory=list)


class HybridExtractionPipeline:
    """
    Main extraction pipeline combining all methods.
    Optimized for performance with flexible configuration.
    """
    
    def __init__(self, device: str = "cuda:1"):
        """
        Initialize the hybrid extraction pipeline.
        
        Args:
            device: Device to run models on (cuda:1 for GPU 1)
        """
        self.device = device
        self.extractors = {}
        
        # Initialize pattern matcher (always available)
        if PATTERN_LOADER_AVAILABLE:
            logger.info("Initializing pattern loader...")
            self.pattern_loader = PatternLoader()
            self.pattern_loader.load_all_patterns()
            self.extractors['regex'] = self.pattern_loader
        else:
            self.pattern_loader = None
            logger.warning("Pattern loader not available - regex extraction disabled")
        
        # Initialize lightweight NER (lazy loading)
        self.ner_extractor = None
        self.distilbert_extractor = None
        self.legal_bert_extractor = None
        self.zero_shot_extractor = None
        
        # Initialize vLLM (lazy loading)
        self.vllm_extractor = None
        
        # Cache for extracted entities
        self.entity_cache = {}
        
        logger.info("Hybrid extraction pipeline initialized")
    
    def _initialize_ner_extractors(self):
        """Lazy initialization of NER extractors"""
        if self.ner_extractor is None:
            logger.info("Initializing lightweight NER extractors...")
            self.ner_extractor = HybridNERExtractor(self.device)
            self.distilbert_extractor = self.ner_extractor.distilbert
            self.legal_bert_extractor = self.ner_extractor.legal_bert
            self.zero_shot_extractor = self.ner_extractor.zero_shot
            self.extractors['ner'] = self.ner_extractor
            logger.info("NER extractors initialized")
    
    def _initialize_vllm_extractor(self):
        """Lazy initialization of vLLM extractor"""
        if self.vllm_extractor is None:
            logger.info("Initializing direct vLLM extractor...")
            try:
                self.vllm_extractor = MiniVLLMExtractor()  # Use smaller model
                self.extractors['vllm'] = self.vllm_extractor
                logger.info("vLLM extractor initialized")
            except Exception as e:
                logger.error(f"Failed to initialize vLLM: {e}")
                self.vllm_extractor = False  # Mark as failed
    
    async def extract(self, 
                     text: str,
                     config: Optional[ExtractionConfig] = None) -> ExtractionResult:
        """
        Main extraction method using hybrid approach.
        
        Args:
            text: Text to extract entities from
            config: Extraction configuration
        """
        if config is None:
            config = ExtractionConfig()
        
        start_time = time.time()
        all_entities = []
        methods_used = []
        entity_counts = {}
        performance_metrics = {}
        warnings = []
        
        # Step 1: Regex extraction (always first, fastest)
        if config.enable_regex and self.pattern_loader:
            regex_start = time.time()
            regex_entities = await self._extract_with_regex(text, config)
            all_entities.extend(regex_entities)
            methods_used.append("regex")
            entity_counts["regex"] = len(regex_entities)
            performance_metrics["regex_time_ms"] = (time.time() - regex_start) * 1000
            logger.info(f"Regex extracted {len(regex_entities)} entities")
        
        # Step 2: Fast AI extraction (lightweight NER)
        if config.enable_fast_ai:
            ai_start = time.time()
            self._initialize_ner_extractors()
            
            # DistilBERT NER
            distilbert_entities = await self._extract_with_distilbert(text)
            all_entities.extend(distilbert_entities)
            entity_counts["distilbert"] = len(distilbert_entities)
            
            # Legal-BERT
            legal_entities = await self._extract_with_legal_bert(text)
            all_entities.extend(legal_entities)
            entity_counts["legal_bert"] = len(legal_entities)
            
            # Zero-shot for unpatterned types
            if config.enable_unpatterned and config.unpatterned_types:
                zero_shot_entities = await self._extract_unpatterned(
                    text, config.unpatterned_types
                )
                all_entities.extend(zero_shot_entities)
                entity_counts["zero_shot"] = len(zero_shot_entities)
            
            methods_used.append("fast_ai")
            performance_metrics["fast_ai_time_ms"] = (time.time() - ai_start) * 1000
            logger.info(f"Fast AI extracted {sum([entity_counts.get('distilbert', 0), entity_counts.get('legal_bert', 0), entity_counts.get('zero_shot', 0)])} entities")
        
        # Step 3: Optional vLLM extraction (only for small documents or specific cases)
        if config.enable_vllm and self._should_use_vllm(text, config):
            vllm_start = time.time()
            self._initialize_vllm_extractor()
            
            if self.vllm_extractor and self.vllm_extractor is not False:
                try:
                    vllm_entities = await self._extract_with_vllm(text, config)
                    all_entities.extend(vllm_entities)
                    methods_used.append("vllm")
                    entity_counts["vllm"] = len(vllm_entities)
                    performance_metrics["vllm_time_ms"] = (time.time() - vllm_start) * 1000
                    logger.info(f"vLLM extracted {len(vllm_entities)} entities")
                except Exception as e:
                    logger.error(f"vLLM extraction failed: {e}")
                    warnings.append(f"vLLM extraction failed: {str(e)}")
            else:
                warnings.append("vLLM extractor not available")
        
        # Step 4: Deduplicate and merge entities
        dedup_start = time.time()
        unique_entities = self._deduplicate_entities(all_entities)
        performance_metrics["deduplication_time_ms"] = (time.time() - dedup_start) * 1000
        
        # Step 5: Filter by confidence threshold
        filtered_entities = [
            e for e in unique_entities 
            if e.confidence >= config.confidence_threshold
        ]
        
        # Calculate total time
        total_time_ms = (time.time() - start_time) * 1000
        
        # Create result
        result = ExtractionResult(
            entities=filtered_entities,
            extraction_time_ms=total_time_ms,
            methods_used=methods_used,
            entity_count_by_method=entity_counts,
            performance_metrics=performance_metrics,
            warnings=warnings
        )
        
        logger.info(f"Extraction complete: {len(filtered_entities)} entities in {total_time_ms:.2f}ms")
        
        return result
    
    async def _extract_with_regex(self, 
                                  text: str, 
                                  config: ExtractionConfig) -> List[UnifiedEntity]:
        """Extract entities using regex patterns"""
        entities = []
        
        if not self.pattern_loader:
            return entities
        
        # Direct access to patterns
        try:
            # Access the internal _patterns attribute directly
            if hasattr(self.pattern_loader, '_patterns') and self.pattern_loader._patterns:
                pattern_groups = self.pattern_loader._patterns
                logger.debug(f"Retrieved {len(pattern_groups)} pattern groups directly")
                
                # Flatten all patterns from groups
                for group_name, group in pattern_groups.items():
                    if hasattr(group, 'patterns'):
                        for pattern_name, pattern in group.patterns.items():
                            if hasattr(pattern, 'compiled_regex') and pattern.compiled_regex:
                                try:
                                    matches = pattern.compiled_regex.finditer(text)
                                    
                                    for match in matches:
                                        entity = UnifiedEntity(
                                            text=match.group(0),
                                            entity_type=getattr(pattern, 'entity_type', pattern_name),
                                            start_pos=match.start(),
                                            end_pos=match.end(),
                                            confidence=getattr(pattern, 'confidence', 0.8),
                                            extraction_method="regex",
                                            metadata={
                                                "pattern": f"{group_name}.{pattern_name}",
                                                "group": group_name,
                                                "pattern_name": pattern_name
                                            }
                                        )
                                        entities.append(entity)
                                except Exception as e:
                                    logger.warning(f"Error applying pattern {group_name}.{pattern_name}: {e}")
            else:
                logger.warning("No patterns found in PatternLoader._patterns")
                                
        except Exception as e:
            logger.error(f"Failed to access patterns from PatternLoader: {e}")
            
            # Fallback: try the old methods
            patterns = {}
            try:
                if hasattr(self.pattern_loader, 'all_patterns'):
                    patterns = self.pattern_loader.all_patterns
                elif hasattr(self.pattern_loader, 'get_all_patterns'):
                    patterns = self.pattern_loader.get_all_patterns()
                elif hasattr(self.pattern_loader, 'compiled_patterns'):
                    patterns = self.pattern_loader.compiled_patterns
                    
                # Apply patterns (fallback method)
                for pattern_name, pattern_data in patterns.items():
                    if isinstance(pattern_data, CompiledPattern):
                        matches = pattern_data.compiled_regex.finditer(text)
                        
                        for match in matches:
                            entity = UnifiedEntity(
                                text=match.group(0),
                                entity_type=pattern_data.entity_type or pattern_name,
                                start_pos=match.start(),
                                end_pos=match.end(),
                                confidence=pattern_data.confidence,
                                extraction_method="regex",
                                metadata={"pattern": pattern_name}
                            )
                            entities.append(entity)
            except Exception as fallback_e:
                logger.error(f"Fallback pattern access also failed: {fallback_e}")
        
        logger.info(f"Regex extraction completed: {len(entities)} entities found")
        return entities
    
    async def _extract_with_distilbert(self, text: str) -> List[UnifiedEntity]:
        """Extract using DistilBERT-NER"""
        entities = []
        
        if not self.distilbert_extractor:
            return entities
        
        ner_entities = self.distilbert_extractor.extract(text)
        
        for ner_ent in ner_entities:
            entity = UnifiedEntity(
                text=ner_ent.text,
                entity_type=ner_ent.entity_type,
                start_pos=ner_ent.start_pos,
                end_pos=ner_ent.end_pos,
                confidence=ner_ent.confidence,
                extraction_method=ner_ent.extraction_method,
                context=ner_ent.context
            )
            entities.append(entity)
        
        return entities
    
    async def _extract_with_legal_bert(self, text: str) -> List[UnifiedEntity]:
        """Extract using Legal-BERT-Small"""
        entities = []
        
        if not self.legal_bert_extractor:
            return entities
        
        legal_entities = self.legal_bert_extractor.extract_legal_entities(text)
        
        for legal_ent in legal_entities:
            entity = UnifiedEntity(
                text=legal_ent.text,
                entity_type=legal_ent.entity_type,
                start_pos=legal_ent.start_pos,
                end_pos=legal_ent.end_pos,
                confidence=legal_ent.confidence,
                extraction_method=legal_ent.extraction_method,
                context=legal_ent.context
            )
            entities.append(entity)
        
        return entities
    
    async def _extract_unpatterned(self, 
                                   text: str,
                                   unpatterned_types: List[str]) -> List[UnifiedEntity]:
        """Extract unpatterned entities using zero-shot"""
        entities = []
        
        if not self.zero_shot_extractor or not unpatterned_types:
            return entities
        
        zero_shot_entities = self.zero_shot_extractor.detect_unpatterned_entities(
            text, unpatterned_types
        )
        
        for zs_ent in zero_shot_entities:
            entity = UnifiedEntity(
                text=zs_ent.text,
                entity_type=zs_ent.entity_type,
                start_pos=zs_ent.start_pos,
                end_pos=zs_ent.end_pos,
                confidence=zs_ent.confidence,
                extraction_method=zs_ent.extraction_method,
                context=zs_ent.context
            )
            entities.append(entity)
        
        return entities
    
    async def _extract_with_vllm(self, 
                                 text: str,
                                 config: ExtractionConfig) -> List[UnifiedEntity]:
        """Extract using direct vLLM"""
        entities = []
        
        if not self.vllm_extractor or self.vllm_extractor is False:
            return entities
        
        # Get entity types for vLLM
        entity_types = config.entity_types or self._get_default_entity_types()
        
        # Extract with vLLM
        vllm_entities = await self.vllm_extractor.extract_entities(
            text[:config.max_document_size_for_vllm],  # Limit size
            entity_types
        )
        
        for vllm_ent in vllm_entities:
            entity = UnifiedEntity(
                text=vllm_ent.text,
                entity_type=vllm_ent.entity_type,
                start_pos=vllm_ent.start_pos,
                end_pos=vllm_ent.end_pos,
                confidence=vllm_ent.confidence,
                extraction_method=vllm_ent.extraction_method,
                context=vllm_ent.context
            )
            entities.append(entity)
        
        return entities
    
    def _should_use_vllm(self, text: str, config: ExtractionConfig) -> bool:
        """Determine if vLLM should be used"""
        # Only use vLLM for small documents
        if len(text) > config.max_document_size_for_vllm:
            logger.info(f"Document too large for vLLM: {len(text)} > {config.max_document_size_for_vllm}")
            return False
        
        # Check if explicitly requested
        if config.mode == ExtractionMode.FULL_AI:
            return True
        
        # In hybrid mode, use vLLM selectively
        if config.mode == ExtractionMode.HYBRID:
            # Use for complex documents or when other methods found few entities
            return len(text) < 2000  # Very conservative
        
        return False
    
    def _deduplicate_entities(self, entities: List[UnifiedEntity]) -> List[UnifiedEntity]:
        """Deduplicate and merge overlapping entities"""
        if not entities:
            return []
        
        # Sort by position and confidence
        entities.sort(key=lambda x: (x.start_pos or 0, -x.confidence))
        
        unique = []
        seen_texts = set()
        seen_positions = set()
        
        for entity in entities:
            # Create unique key
            text_key = (entity.text.lower(), entity.entity_type)
            
            # Check for exact duplicates
            if text_key in seen_texts:
                continue
            
            # Check for overlapping positions
            if entity.start_pos is not None and entity.end_pos is not None:
                pos_key = (entity.start_pos, entity.end_pos)
                if pos_key in seen_positions:
                    continue
                
                # Check for partial overlaps
                overlap = False
                for start, end in seen_positions:
                    if (entity.start_pos < end and entity.end_pos > start):
                        # Overlapping - keep higher confidence
                        overlap = True
                        break
                
                if not overlap:
                    seen_positions.add(pos_key)
            
            seen_texts.add(text_key)
            unique.append(entity)
        
        return unique
    
    def _get_default_entity_types(self) -> List[str]:
        """Get default entity types for extraction"""
        return [
            "JUDGE", "ATTORNEY", "LAW_FIRM", "PARTY", "COURT",
            "CASE", "STATUTE", "REGULATION", "CITATION", "DATE",
            "MONETARY_AMOUNT", "JURISDICTION", "VENUE", "WITNESS",
            "EXPERT", "AGENCY", "COMPANY", "CONTRACT", "MOTION", "ORDER"
        ]
    
    def cleanup(self):
        """Clean up resources"""
        if self.vllm_extractor and self.vllm_extractor is not False:
            self.vllm_extractor.cleanup()
        
        # Clear cache
        self.entity_cache.clear()
        
        logger.info("Pipeline resources cleaned up")