"""
Lightweight NER Extractors for CALES

This module provides fast, lightweight NER models for entity extraction:
- DistilBERT-NER: Fast general entity extraction
- Legal-BERT-Small: Legal domain-specific extraction
- DeBERTa-Small: Zero-shot classification for unpatterned entities
"""

import logging
import torch
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from collections import defaultdict

try:
    from transformers import (
        AutoTokenizer, 
        AutoModelForTokenClassification,
        AutoModel,
        pipeline
    )
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("Transformers not available - install with: pip install transformers")

logger = logging.getLogger(__name__)


@dataclass
class NEREntity:
    """Entity extracted by NER models"""
    text: str
    entity_type: str
    start_pos: int
    end_pos: int
    confidence: float
    extraction_method: str
    context: Optional[str] = None


class DistilBERTNERExtractor:
    """
    Fast NER extraction using DistilBERT-NER.
    ~250MB model, 2x faster than BERT-base.
    """
    
    def __init__(self, device: str = "cuda:1", batch_size: int = 32):
        """
        Initialize DistilBERT-NER extractor.
        
        Args:
            device: Device to run on (cuda:1 for GPU 1)
            batch_size: Batch size for processing
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("Transformers library not installed")
        
        self.device = device
        self.batch_size = batch_size
        
        logger.info("Loading DistilBERT-NER model...")
        
        # Load model and tokenizer
        model_name = "dslim/distilbert-NER"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForTokenClassification.from_pretrained(model_name)
        
        # Move to GPU
        if "cuda" in device and torch.cuda.is_available():
            self.model = self.model.to(device)
            self.model.eval()
        
        # Create NER pipeline for convenience
        # Using "max" aggregation for best entity boundary detection
        self.pipeline = pipeline(
            "ner",
            model=self.model,
            tokenizer=self.tokenizer,
            device=0 if device == "cuda:0" else 1,
            aggregation_strategy="max",  # "max" gives best whole-word entities
            batch_size=batch_size
        )
        
        # Initialize PatternLoader for dynamic entity mapping
        self._init_pattern_loader()
        
        logger.info("DistilBERT-NER loaded successfully")
    
    def _init_pattern_loader(self):
        """
        Initialize PatternLoader and build dynamic entity mappings.
        NO HARDCODING - all patterns and examples loaded from PatternLoader.
        """
        try:
            from ...utils.pattern_loader import PatternLoader
            
            # Initialize PatternLoader
            self.pattern_loader = PatternLoader()
            self.pattern_loader.load_all_patterns()
            
            # Load entity type mappings from JSON config
            import json
            import os
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                'config', 'entity_type_mappings.json'
            )
            
            with open(config_path, 'r') as f:
                config = json.load(f)
                self.entity_type_mappings = config.get('entity_type_mappings', {})
            
            # Build comprehensive entity mapping using PatternLoader examples
            self.entity_mapping = self._build_dynamic_entity_mapping()
            
            # Load all entity examples for context-aware classification
            self.entity_examples = self._load_entity_examples()
            
            logger.info(f"Loaded {len(self.entity_type_mappings)} entity type mappings")
            logger.info(f"Loaded {len(self.entity_examples)} entity examples")
            
        except Exception as e:
            logger.warning(f"Failed to initialize PatternLoader: {e}")
            # Fallback to basic mapping if PatternLoader fails
            self.pattern_loader = None
            self.entity_type_mappings = {}
            self.entity_examples = {}
            self.entity_mapping = {
                "PER": ["PARTY", "ATTORNEY", "JUDGE"],
                "ORG": ["COURT", "LAW_FIRM", "CORPORATION"],
                "LOC": ["JURISDICTION", "VENUE", "ADDRESS"],
                "MISC": ["CASE_CITATION", "STATUTE_CITATION", "DOCUMENT"]
            }
    
    def _build_dynamic_entity_mapping(self) -> Dict[str, List[str]]:
        """
        Build entity mapping dynamically from PatternLoader.
        Maps BERT's generic entity types (PER, ORG, LOC, MISC) to specific legal types.
        """
        mapping = defaultdict(list)
        
        # Get all entity types from PatternLoader
        if hasattr(self.pattern_loader, 'entity_examples'):
            for entity_type, examples in self.pattern_loader.entity_examples.items():
                # Classify based on entity type characteristics
                if any(word in entity_type.upper() for word in [
                    'JUDGE', 'ATTORNEY', 'PARTY', 'PLAINTIFF', 'DEFENDANT',
                    'WITNESS', 'EXPERT', 'MAGISTRATE', 'JUSTICE', 'COUNSEL',
                    'APPELLANT', 'APPELLEE', 'PETITIONER', 'RESPONDENT'
                ]):
                    mapping["PER"].append(entity_type)
                    
                elif any(word in entity_type.upper() for word in [
                    'COURT', 'FIRM', 'COMPANY', 'CORPORATION', 'AGENCY',
                    'ORGANIZATION', 'GOVERNMENT', 'DEPARTMENT', 'LLC', 
                    'PARTNERSHIP', 'NONPROFIT', 'ASSOCIATION'
                ]):
                    mapping["ORG"].append(entity_type)
                    
                elif any(word in entity_type.upper() for word in [
                    'JURISDICTION', 'VENUE', 'ADDRESS', 'LOCATION',
                    'DISTRICT', 'CIRCUIT', 'STATE', 'COUNTY', 'CITY'
                ]):
                    mapping["LOC"].append(entity_type)
                    
                else:
                    # Everything else goes to MISC
                    mapping["MISC"].append(entity_type)
        
        # Convert defaultdict to regular dict
        return dict(mapping)
    
    def _load_entity_examples(self) -> Dict[str, List[str]]:
        """
        Load all entity examples from PatternLoader for context matching.
        """
        examples = {}
        
        if hasattr(self.pattern_loader, 'entity_examples'):
            for entity_type, example_list in self.pattern_loader.entity_examples.items():
                if isinstance(example_list, list):
                    # Store lowercase examples for matching
                    examples[entity_type] = [ex.lower() for ex in example_list if isinstance(ex, str)]
        
        return examples
    
    def _classify_entity_with_context(self, text: str, bert_type: str, context: str = None) -> str:
        """
        Classify entity type using PatternLoader examples and context.
        Returns the most appropriate legal entity type.
        """
        text_lower = text.lower()
        
        # Get possible entity types for this BERT type
        possible_types = self.entity_mapping.get(bert_type, [bert_type])
        
        if not possible_types:
            return bert_type
        
        # Score each possible type based on example matching
        scores = {}
        for entity_type in possible_types:
            score = 0.0
            
            # Check if entity matches any examples
            if entity_type in self.entity_examples:
                examples = self.entity_examples[entity_type]
                for example in examples:
                    if example in text_lower:
                        score += 1.0
                    elif text_lower in example:
                        score += 0.5
                    # Partial match scoring
                    elif any(word in text_lower for word in example.split()):
                        score += 0.2
            
            # Check entity type keywords in text
            type_words = entity_type.replace('_', ' ').lower().split()
            for word in type_words:
                if word in text_lower:
                    score += 0.5
            
            # Context-based scoring if available
            if context:
                context_lower = context.lower()
                # Legal role indicators
                if entity_type == "JUDGE" and any(w in context_lower for w in ["justice", "judge", "hon.", "magistrate"]):
                    score += 2.0
                elif entity_type == "ATTORNEY" and any(w in context_lower for w in ["attorney", "counsel", "esq.", "lawyer"]):
                    score += 2.0
                elif entity_type == "COURT" and any(w in context_lower for w in ["court", "tribunal", "bench"]):
                    score += 2.0
                elif entity_type == "CASE_CITATION" and " v. " in context_lower:
                    score += 2.0
            
            scores[entity_type] = score
        
        # Return highest scoring type, or first if all zero
        if scores:
            best_type = max(scores, key=scores.get)
            if scores[best_type] > 0:
                return best_type
        
        # Default to first possible type
        return possible_types[0] if possible_types else bert_type
    
    def _validate_entity_with_patterns(self, entity: NEREntity, text: str) -> bool:
        """
        Validate an entity against PatternLoader patterns.
        Returns True if entity matches any pattern for its type.
        """
        if not self.pattern_loader:
            return True  # Skip validation if PatternLoader not available
        
        try:
            # Get patterns for this entity type
            pattern_groups = self.pattern_loader.get_pattern_groups()
            entity_text_lower = entity.text.lower()
            
            for group_name, group in pattern_groups.items():
                if hasattr(group, 'patterns'):
                    for pattern_name, pattern in group.patterns.items():
                        # Check if pattern is for this entity type
                        if hasattr(pattern, 'entity_type'):
                            # Map pattern entity type to our entity type
                            mapped_type = self.entity_type_mappings.get(
                                pattern.entity_type.lower(),
                                pattern.entity_type
                            )
                            
                            if mapped_type == entity.entity_type:
                                # Try to match the pattern
                                if hasattr(pattern, 'compiled_regex'):
                                    import re
                                    if pattern.compiled_regex.search(entity.text):
                                        return True
            
            # Also validate against examples
            if entity.entity_type in self.entity_examples:
                examples = self.entity_examples[entity.entity_type]
                # Check for exact or partial matches
                for example in examples:
                    if entity_text_lower == example:
                        return True
                    # Check if entity is part of an example
                    if entity_text_lower in example:
                        return True
                    # Check if example is part of entity (for abbreviated forms)
                    if len(example) > 3 and example in entity_text_lower:
                        return True
            
            # For person names (JUDGE, ATTORNEY, etc.), be more lenient
            person_types = ['JUDGE', 'ATTORNEY', 'PARTY', 'PLAINTIFF', 'DEFENDANT', 
                          'WITNESS', 'EXPERT', 'MAGISTRATE', 'JUSTICE']
            if entity.entity_type in person_types:
                # Check if it looks like a name (capitalized words)
                import re
                name_pattern = r'^[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*$'
                if re.match(name_pattern, entity.text):
                    return True
            
            # Default: accept if confidence is high enough
            return entity.confidence > 0.85
            
        except Exception as e:
            logger.warning(f"Pattern validation error: {e}")
            return True  # Accept on error
    
    def _is_fragment_or_noise(self, entity: NEREntity, text: str) -> bool:
        """
        Detect if an entity is a fragment, noise, or invalid extraction.
        Returns True if entity should be filtered out.
        """
        entity_text = entity.text.strip()
        
        # Basic length checks
        if len(entity_text) < 2:  # Single characters are likely noise
            return True
        
        if len(entity_text) > 100:  # Extremely long entities are likely errors
            return True
        
        # Check for fragment patterns (common issues we saw)
        fragment_patterns = [
            # Starts or ends with punctuation (except legal abbreviations)
            r'^[.,;:!?"\'\-\(\)\[\]]+',
            r'[.,;:!?"\'\-\(\)\[\]]+$',
            # Starts with lowercase (except specific legal terms)
            r'^[a-z]',
            # Contains only numbers and punctuation
            r'^[\d\s\.,;:\-\(\)\[\]]+$',
            # Partial words (ends with incomplete patterns)
            r'^[A-Za-z]*[a-z]$',  # Single lowercase ending
            # Common fragment patterns we observed
            r'^[a-z]+$',  # All lowercase
            r'^\s*[a-z]+\s*$',  # All lowercase with spaces
            # Specific problematic patterns
            r'^[.,]\s*at\s+\d+',  # ". at 19"
            r'^[a-z]+\s*$',  # "ustice", "mendme", etc.
            r'^\s*[a-z]\'s\s+\w+',  # "s's power"
            r'^\s*[a-z]+\s+in\s+\w+',  # "s in Dome"
        ]
        
        import re
        try:
            for pattern in fragment_patterns:
                if re.match(pattern, entity_text):
                    # Exception for known legal terms
                    legal_exceptions = [
                        'v.', 'vs.', 'etc.', 'inc.', 'llc', 'corp.', 'ltd.',
                        'esq.', 'j.', 'c.j.', 'hon.', 'mag.', 'adm.', 'id.',
                        'cf.', 'see', 'at', 'p.', 'pp.', 'n.', 'nn.', 'f.',
                        'ff.', 'supp.', 'app.'
                    ]
                    
                    if entity_text.lower() not in legal_exceptions:
                        return True
        except re.error:
            # Skip pattern matching if regex fails
            pass
        
        # Check for incomplete words (word fragments)
        # Words that don't form complete legal terms
        if len(entity_text) <= 8:  # Short entities need extra validation
            # Check if it's a complete word
            if not re.match(r'^[A-Z][a-z]*$', entity_text) and not re.match(r'^[A-Z][A-Z\.]+$', entity_text):
                # Not a proper name or acronym pattern
                if not any(term in entity_text.lower() for term in [
                    'court', 'judge', 'law', 'act', 'sec', 'rule', 'code'
                ]):
                    return True
        
        # Context-based fragment detection
        if entity.start_pos is not None and entity.end_pos is not None and len(text) > 0:
            try:
                # Check if entity breaks mid-word
                before_char = text[entity.start_pos - 1] if entity.start_pos > 0 else ' '
                after_char = text[entity.end_pos] if entity.end_pos < len(text) else ' '
                
                # Entity starts or ends mid-word (not at word boundary)
                if before_char.isalpha() or after_char.isalpha():
                    # Unless it's a known compound legal term
                    if not any(compound in entity_text.lower() for compound in [
                        'anti-', 'pre-', 'post-', 'non-', 'ex-', 'co-', 'sub-'
                    ]):
                        return True
            except (IndexError, TypeError):
                # Skip context check if positions are invalid
                pass
        
        # Legal entity validation - ensure it makes sense in legal context
        legal_entity_types = [
            'JUDGE', 'ATTORNEY', 'COURT', 'CASE_CITATION', 'STATUTE_CITATION',
            'PARTY', 'JURISDICTION', 'LAW_FIRM', 'GOVERNMENT_ENTITY'
        ]
        
        if entity.entity_type in legal_entity_types:
            # Additional validation for legal entities
            if len(entity_text) < 3 and entity_text.lower() not in [
                'v.', 'vs', 'id', 'cf', 'at', 'in', 'ex', 're'
            ]:
                return True
        
        # Statistical validation - very low confidence for fragments
        if entity.confidence < 0.7 and len(entity_text) < 6:
            return True
        
        return False
    
    def _filter_entities_aggressively(self, entities: List[NEREntity], text: str) -> List[NEREntity]:
        """
        Apply aggressive filtering to remove fragments and noise.
        """
        filtered_entities = []
        
        for entity in entities:
            try:
                # Apply fragment detection
                if self._is_fragment_or_noise(entity, text):
                    logger.debug(f"Filtered fragment/noise: '{entity.text}' ({entity.entity_type}, conf={entity.confidence:.3f})")
                    continue
                
                # Apply additional validation against patterns
                if not self._validate_entity_with_patterns(entity, text):
                    logger.debug(f"Filtered invalid pattern: '{entity.text}' ({entity.entity_type})")
                    continue
                
                filtered_entities.append(entity)
                
            except Exception as e:
                logger.warning(f"Error filtering entity '{entity.text}': {e}")
                # Include entity if filtering fails to avoid losing data
                filtered_entities.append(entity)
        
        return filtered_entities
    
    def chunk_text(self, text: str, max_length: int = 512, stride: int = 50) -> List[Tuple[int, str]]:
        """
        Smart chunk text preserving legal entity boundaries.
        
        Args:
            text: Text to chunk
            max_length: Maximum chunk length in tokens
            stride: Overlap between chunks
        """
        # Get legal entity boundary patterns from PatternLoader
        legal_patterns = self._get_boundary_patterns()
        
        # Tokenize to get accurate chunking
        tokens = self.tokenizer.tokenize(text)
        chunks = []
        
        for i in range(0, len(tokens), max_length - stride):
            chunk_end = min(i + max_length, len(tokens))
            chunk_tokens = tokens[i:chunk_end]
            chunk_text = self.tokenizer.convert_tokens_to_string(chunk_tokens)
            
            # Try to avoid splitting legal entities
            if chunk_end < len(tokens):  # Not the last chunk
                # Look for legal entity patterns near the boundary
                boundary_text = self.tokenizer.convert_tokens_to_string(tokens[max(0, chunk_end-10):min(len(tokens), chunk_end+10)])
                
                import re
                for pattern in legal_patterns:
                    matches = list(re.finditer(pattern, boundary_text, re.IGNORECASE))
                    for match in matches:
                        # If a legal entity spans the boundary, adjust chunk end
                        match_start = boundary_text[:match.start()].count(' ')
                        match_end = boundary_text[:match.end()].count(' ')
                        
                        # Rough token position estimate
                        boundary_token_pos = chunk_end - 10
                        if boundary_token_pos <= chunk_end <= boundary_token_pos + match_end:
                            # Extend chunk to include complete entity
                            new_end = min(len(tokens), chunk_end + 5)
                            chunk_tokens = tokens[i:new_end]
                            chunk_text = self.tokenizer.convert_tokens_to_string(chunk_tokens)
                            break
            
            # Calculate character offset more accurately
            if i == 0:
                char_offset = 0
            else:
                prefix_text = self.tokenizer.convert_tokens_to_string(tokens[:i])
                char_offset = len(prefix_text)
            
            chunks.append((char_offset, chunk_text))
        
        return chunks
    
    def extract(self, text: str) -> List[NEREntity]:
        """
        Extract entities from text using DistilBERT-NER.
        
        Args:
            text: Text to extract entities from
        """
        entities = []
        seen_entities = set()
        
        # Process in chunks for long text
        if len(text) > 2000:
            chunks = self.chunk_text(text)
            
            for offset, chunk in chunks:
                chunk_entities = self.pipeline(chunk)
                
                for ent in chunk_entities:
                    # Adjust positions
                    start = ent['start'] + offset
                    end = ent['end'] + offset
                    
                    # Deduplicate
                    entity_key = (ent['word'], start, end)
                    if entity_key not in seen_entities:
                        # Get context around entity for better classification
                        context_start = max(0, start - 50)
                        context_end = min(len(text), end + 50)
                        context = text[context_start:context_end]
                        
                        # Use context-aware classification with PatternLoader
                        legal_type = self._classify_entity_with_context(
                            ent['word'], 
                            ent['entity_group'],
                            context
                        )
                        
                        entity = NEREntity(
                            text=ent['word'],
                            entity_type=legal_type,
                            start_pos=start,
                            end_pos=end,
                            confidence=ent['score'],
                            extraction_method="distilbert_ner"
                        )
                        entities.append(entity)
                        seen_entities.add(entity_key)
        else:
            # Process entire text at once for short documents
            ner_results = self.pipeline(text)
            
            for ent in ner_results:
                # Get context for better classification
                context_start = max(0, ent['start'] - 50)
                context_end = min(len(text), ent['end'] + 50)
                context = text[context_start:context_end]
                
                # Use context-aware classification
                legal_type = self._classify_entity_with_context(
                    ent['word'],
                    ent['entity_group'],
                    context
                )
                
                entity = NEREntity(
                    text=ent['word'],
                    entity_type=legal_type,
                    start_pos=ent['start'],
                    end_pos=ent['end'],
                    confidence=ent['score'],
                    extraction_method="distilbert_ner"
                )
                entities.append(entity)
        
        # Apply smart entity merging to fix fragmentation
        merged_entities = self._merge_fragmented_entities(entities, text)
        
        # Apply aggressive filtering to remove fragments and noise
        clean_entities = self._filter_entities_aggressively(merged_entities, text)
        
        logger.info(f"DistilBERT extracted {len(clean_entities)} clean entities (from {len(entities)} raw, {len(merged_entities)} merged)")
        return clean_entities
    
    def _get_boundary_patterns(self) -> List[str]:
        """
        Get legal entity boundary patterns from PatternLoader to avoid hardcoding.
        """
        try:
            # Import PatternLoader dynamically to avoid circular imports
            from ...utils.pattern_loader import PatternLoader
            
            # Create temporary PatternLoader instance
            pattern_loader = PatternLoader()
            pattern_loader.load_all_patterns()
            
            # Get comprehensive patterns and filter for multi-word entities
            pattern_groups = pattern_loader.get_pattern_groups()
            boundary_patterns = []
            
            # Filter patterns that are likely to be multi-word entities prone to fragmentation
            target_entity_types = {
                'JUDGE', 'JUSTICE', 'COURT', 'CASE_CITATION', 'CASE_PARTIES',
                'STATUTE_CITATION', 'LAW_FIRM', 'GOVERNMENT_ENTITY', 'DOCKET_NUMBER'
            }
            
            for group_name, group in pattern_groups.items():
                if hasattr(group, 'patterns'):
                    for pattern_name, pattern in group.patterns.items():
                        if hasattr(pattern, 'entity_type') and pattern.entity_type in target_entity_types:
                            # Extract the core regex pattern
                            if hasattr(pattern, 'compiled_regex'):
                                pattern_str = pattern.compiled_regex.pattern
                                # Simplify pattern for boundary detection (remove complex groups)
                                simplified = self._simplify_pattern_for_boundaries(pattern_str)
                                if simplified and len(simplified) > 10:  # Skip very short patterns
                                    boundary_patterns.append(simplified)
            
            # Add some essential fallback patterns if none found
            if not boundary_patterns:
                boundary_patterns = [
                    r'\b(?:Chief\s+)?Justice\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
                    r'\b(?:Judge|Hon\.)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
                    r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+v\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
                    r'\b(?:U\.S\.|United\s+States)\s+(?:Supreme\s+Court|Court\s+of\s+Appeals|District\s+Court)',
                    r'\bNo\.\s+\d{2,4}-\d+'
                ]
            
            return boundary_patterns[:20]  # Limit to prevent performance issues
            
        except Exception as e:
            # Fallback to essential patterns if PatternLoader fails
            logger.warning(f"Failed to load boundary patterns from PatternLoader: {e}")
            return [
                r'\b(?:Chief\s+)?Justice\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
                r'\b(?:Judge|Hon\.)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*',
                r'\bNo\.\s+\d{2,4}-\d+'
            ]
    
    def _simplify_pattern_for_boundaries(self, pattern: str) -> str:
        """
        Simplify complex regex patterns for boundary detection.
        """
        # Remove named groups
        import re
        simplified = re.sub(r'\(\?P<[^>]+>', '(', pattern)
        
        # Remove complex quantifiers and keep basic structure
        simplified = re.sub(r'\{\d+,?\d*\}', '+', simplified)
        simplified = re.sub(r'\[\^[^\]]+\]', r'\\S', simplified)
        
        # Keep only patterns that look like multi-word entities
        if r'\s+' in simplified or r'\\s' in simplified:
            return simplified
        else:
            return None
    
    def _merge_fragmented_entities(self, entities: List[NEREntity], text: str) -> List[NEREntity]:
        """
        Merge fragmented entities that should be combined.
        """
        if not entities:
            return entities
        
        # Sort entities by position
        entities.sort(key=lambda e: e.start_pos or 0)
        
        merged = []
        i = 0
        
        while i < len(entities):
            current = entities[i]
            
            # Look for adjacent entities that should be merged
            candidates_to_merge = [current]
            j = i + 1
            
            while j < len(entities):
                next_entity = entities[j]
                
                # Check if entities are adjacent and of same/compatible type
                if (current.end_pos is not None and next_entity.start_pos is not None and
                    next_entity.start_pos - current.end_pos <= 2 and  # Allow 1-2 char gap (space)
                    self._should_merge_entities(current, next_entity, text)):
                    
                    candidates_to_merge.append(next_entity)
                    current = next_entity  # Update current for next iteration
                    j += 1
                else:
                    break
            
            # Merge the candidates or keep original
            if len(candidates_to_merge) > 1:
                merged_entity = self._create_merged_entity(candidates_to_merge, text)
                merged.append(merged_entity)
            else:
                merged.append(current)
            
            i = j if len(candidates_to_merge) > 1 else i + 1
        
        return merged
    
    def _should_merge_entities(self, entity1: NEREntity, entity2: NEREntity, text: str) -> bool:
        """
        Determine if two entities should be merged using improved logic.
        """
        # Check gap between entities
        if entity1.end_pos and entity2.start_pos:
            gap = text[entity1.end_pos:entity2.start_pos]
            gap_stripped = gap.strip()
            
            # Don't merge if gap is too large
            if len(gap) > 3:
                return False
            
            # Don't merge if gap contains sentence-ending punctuation
            if any(punct in gap for punct in ['.', '!', '?', ';']):
                return False
        
        # Same entity type - likely fragments
        if entity1.entity_type == entity2.entity_type:
            return True
        
        # Compatible legal entity types that often appear together
        compatible_groups = [
            # Person-related merges
            {'JUDGE', 'MAGISTRATE', 'JUSTICE', 'ATTORNEY', 'PARTY', 
             'PLAINTIFF', 'DEFENDANT', 'WITNESS', 'EXPERT'},
            # Organization-related merges
            {'COURT', 'LAW_FIRM', 'CORPORATION', 'AGENCY', 'GOVERNMENT_ENTITY',
             'DEPARTMENT', 'LLC', 'PARTNERSHIP', 'NONPROFIT'},
            # Location-related merges
            {'JURISDICTION', 'VENUE', 'ADDRESS', 'DISTRICT', 'CIRCUIT', 
             'STATE', 'COUNTY', 'CITY'},
            # Citation-related merges
            {'CASE_CITATION', 'STATUTE_CITATION', 'REGULATION_CITATION',
             'USC_CITATION', 'CFR_CITATION', 'DOCKET_NUMBER'}
        ]
        
        # Check if both entities are in the same compatible group
        for group in compatible_groups:
            if entity1.entity_type in group and entity2.entity_type in group:
                return True
        
        # Check context for common legal patterns
        if entity1.end_pos and entity2.start_pos:
            # Get broader context
            context_start = max(0, entity1.start_pos - 20)
            context_end = min(len(text), entity2.end_pos + 20)
            context = text[context_start:context_end].lower()
            
            # Common legal name patterns
            if any(pattern in context for pattern in [
                'justice', 'judge', 'hon.', 'magistrate',
                'attorney', 'counsel', 'esq.',
                ' v. ', ' vs. ', 'versus',
                'court of', 'district court', 'supreme court'
            ]):
                # More likely to be part of same entity
                return True
        
        return False
    
    def _create_merged_entity(self, entities: List[NEREntity], text: str) -> NEREntity:
        """
        Create a merged entity from multiple fragments.
        """
        if not entities:
            return entities[0]
        
        # Sort by position
        entities.sort(key=lambda e: e.start_pos or 0)
        
        # Get full text span
        start_pos = entities[0].start_pos
        end_pos = entities[-1].end_pos
        
        if start_pos is not None and end_pos is not None:
            merged_text = text[start_pos:end_pos]
        else:
            merged_text = ' '.join(e.text for e in entities)
        
        # Use the highest confidence entity type
        best_entity = max(entities, key=lambda e: e.confidence)
        
        # Average confidence
        avg_confidence = sum(e.confidence for e in entities) / len(entities)
        
        return NEREntity(
            text=merged_text.strip(),
            entity_type=best_entity.entity_type,
            start_pos=start_pos,
            end_pos=end_pos,
            confidence=avg_confidence,
            extraction_method=f"distilbert_ner_merged({len(entities)})"
        )
    
    def batch_extract(self, texts: List[str]) -> List[List[NEREntity]]:
        """
        Extract entities from multiple texts in batch.
        
        Args:
            texts: List of texts to process
        """
        all_results = []
        
        # Process in batches
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            batch_results = self.pipeline(batch)
            
            for text_idx, text_entities in enumerate(batch_results):
                entities = []
                for ent in text_entities:
                    legal_types = self.entity_mapping.get(ent['entity_group'], [ent['entity_group']])
                    
                    entity = NEREntity(
                        text=ent['word'],
                        entity_type=legal_types[0] if legal_types else ent['entity_group'],
                        start_pos=ent['start'],
                        end_pos=ent['end'],
                        confidence=ent['score'],
                        extraction_method="distilbert_ner"
                    )
                    entities.append(entity)
                
                all_results.append(entities)
        
        return all_results


class LegalBERTSmallExtractor:
    """
    Legal domain-specific extraction using Legal-BERT-Small.
    ~150MB model, 4x faster than full BERT, trained on legal text.
    """
    
    def __init__(self, device: str = "cuda:1"):
        """
        Initialize Legal-BERT-Small extractor.
        
        Args:
            device: Device to run on
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("Transformers library not installed")
        
        self.device = device
        
        logger.info("Loading Legal-BERT-Small model...")
        
        # Load Legal-BERT-Small
        model_name = "nlpaueb/legal-bert-small-uncased"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        # Load as base model for embeddings and context
        self.model = AutoModel.from_pretrained(model_name)
        
        if "cuda" in device and torch.cuda.is_available():
            self.model = self.model.to(device)
            self.model.eval()
        
        # Legal entity patterns for matching
        self.legal_patterns = {
            "CASE": ["v.", "vs.", "versus", "matter of", "in re", "ex parte"],
            "COURT": ["court", "tribunal", "bench", "judicial"],
            "STATUTE": ["§", "section", "u.s.c.", "c.f.r.", "statute"],
            "LAW_FIRM": ["llp", "llc", "p.c.", "p.a.", "attorneys", "law"],
            "JUDGE": ["judge", "justice", "magistrate", "hon.", "j."],
            "ATTORNEY": ["esq.", "esquire", "attorney", "counsel", "lawyer"]
        }
        
        logger.info("Legal-BERT-Small loaded successfully")
    
    def get_embeddings(self, text: str) -> torch.Tensor:
        """
        Get Legal-BERT embeddings for text.
        
        Args:
            text: Text to embed
        """
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            max_length=512,
            truncation=True,
            padding=True
        )
        
        if "cuda" in self.device:
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            # Use CLS token embedding
            embeddings = outputs.last_hidden_state[:, 0, :]
        
        return embeddings
    
    def extract_legal_entities(self, text: str) -> List[NEREntity]:
        """
        Extract legal-specific entities using Legal-BERT-Small with improved pattern matching.
        
        Args:
            text: Text to extract from
        """
        entities = []
        
        # Enhanced legal patterns with better regex
        enhanced_patterns = {
            "CASE_CITATION": [
                r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+v\.?\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)",  # Party v. Party
                r"\bIn\s+re\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)",  # In re Matter
                r"\bEx\s+parte\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)",  # Ex parte
                r"\bMatter\s+of\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)"  # Matter of
            ],
            "COURT": [
                r"\b(?:Supreme\s+Court|Court\s+of\s+Appeals|District\s+Court|Superior\s+Court|Appellate\s+Court|Circuit\s+Court|Municipal\s+Court)(?:\s+of\s+[A-Z][a-z]+)*",
                r"\b(?:U\.S\.|United\s+States)\s+(?:Supreme\s+Court|Court\s+of\s+Appeals|District\s+Court)",
                r"\b[A-Z][a-z]+\s+(?:Supreme\s+Court|Court\s+of\s+Appeals|Superior\s+Court)"
            ],
            "JUDGE": [
                r"\b(?:Chief\s+)?Justice\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*",
                r"\b(?:Judge|Hon\.)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*",
                r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*,\s+J\.",
                r"\bMagistrate\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*"
            ],
            "STATUTE": [
                r"\b\d+\s+U\.S\.C\.?\s*§?\s*\d+(?:\.\d+)?",  # U.S.C.
                r"\b\d+\s+C\.F\.R\.?\s*§?\s*\d+(?:\.\d+)?",  # C.F.R.
                r"\bSection\s+\d+(?:\.\d+)?",
                r"\b§\s*\d+(?:\.\d+)?"
            ],
            "DOCKET_NUMBER": [
                r"\bNo\.\s+\d{2,4}-\d+",  # No. 22-915
                r"\bCase\s+No\.\s+\d+:\d+-\w+-\d+",  # Case No. 1:23-cv-1234
                r"\bCivil\s+Action\s+No\.\s+\d+-\d+"
            ],
            "LAW_FIRM": [
                r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+&\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)*\s+(?:LLP|LLC|P\.C\.|P\.A\.)",
                r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+Law\s+(?:Firm|Group|Offices?)"
            ],
            "MONETARY_AMOUNT": [
                r"\$[\d,]+(?:\.\d{2})?",  # $1,000.00
                r"\$\d+(?:,\d{3})*(?:\.\d{2})?"  # $1,000
            ]
        }
        
        # Apply enhanced patterns
        for entity_type, patterns in enhanced_patterns.items():
            for pattern in patterns:
                import re
                try:
                    matches = re.finditer(pattern, text, re.IGNORECASE)
                    for match in matches:
                        entity_text = match.group(0).strip()
                        
                        # Skip very short matches
                        if len(entity_text) < 3:
                            continue
                            
                        # Calculate confidence based on pattern quality
                        confidence = self._calculate_pattern_confidence(entity_type, entity_text)
                        
                        entity = NEREntity(
                            text=entity_text,
                            entity_type=entity_type,
                            start_pos=match.start(),
                            end_pos=match.end(),
                            confidence=confidence,
                            extraction_method="legal_bert_small"
                        )
                        entities.append(entity)
                        
                except re.error as e:
                    logger.warning(f"Invalid regex pattern for {entity_type}: {e}")
                    continue
        
        # Deduplicate
        unique_entities = []
        seen = set()
        for entity in entities:
            key = (entity.text, entity.entity_type)
            if key not in seen:
                unique_entities.append(entity)
                seen.add(key)
        
        logger.info(f"Legal-BERT extracted {len(unique_entities)} entities")
        return unique_entities
    
    def _calculate_pattern_confidence(self, entity_type: str, text: str) -> float:
        """Calculate confidence score based on entity type and text quality"""
        base_confidence = 0.75
        
        # Boost confidence for well-formed patterns
        if entity_type == "CASE_CITATION" and " v. " in text:
            return min(0.95, base_confidence + 0.2)
        elif entity_type == "COURT" and any(word in text.lower() for word in ["supreme", "district", "appeals"]):
            return min(0.90, base_confidence + 0.15)
        elif entity_type == "JUDGE" and any(word in text for word in ["Justice", "Judge", "Hon."]):
            return min(0.90, base_confidence + 0.15)
        elif entity_type == "STATUTE" and any(symbol in text for symbol in ["U.S.C.", "C.F.R.", "§"]):
            return min(0.90, base_confidence + 0.15)
        elif entity_type == "DOCKET_NUMBER" and "No." in text:
            return min(0.95, base_confidence + 0.2)
        elif entity_type == "MONETARY_AMOUNT" and "$" in text:
            return min(0.95, base_confidence + 0.2)
        
        return base_confidence
    
    def extract_entity_around_pattern(self, text: str, pattern: str) -> Optional[str]:
        """
        Extract entity text around a pattern.
        
        Args:
            text: Text containing the pattern
            pattern: Pattern to extract around
        """
        import re
        
        # Find pattern location
        pattern_lower = pattern.lower()
        text_lower = text.lower()
        
        pos = text_lower.find(pattern_lower)
        if pos == -1:
            return None
        
        # Extract surrounding context
        start = max(0, pos - 50)
        end = min(len(text), pos + len(pattern) + 50)
        context = text[start:end]
        
        # Try to extract complete entity
        # For cases like "Smith v. Jones"
        if pattern in ["v.", "vs.", "versus"]:
            case_pattern = r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+v\.?\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)"
            match = re.search(case_pattern, context)
            if match:
                return match.group(0)
        
        # For other patterns, extract noun phrases
        words = context.split()
        for i, word in enumerate(words):
            if pattern_lower in word.lower():
                # Get surrounding words
                start_idx = max(0, i - 2)
                end_idx = min(len(words), i + 3)
                return " ".join(words[start_idx:end_idx])
        
        return None


class ZeroShotEntityExtractor:
    """
    Zero-shot classification for unpatterned entity types.
    Uses DeBERTa-v3-small for efficient classification.
    """
    
    def __init__(self, device: str = "cuda:1"):
        """
        Initialize zero-shot classifier.
        
        Args:
            device: Device to run on
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("Transformers library not installed")
        
        self.device = device
        
        logger.info("Loading DeBERTa-v3-small for zero-shot classification...")
        
        # Use smaller DeBERTa model for efficiency
        self.classifier = pipeline(
            "zero-shot-classification",
            model="microsoft/deberta-v3-small",  # 140M params
            device=0 if device == "cuda:0" else 1,
            multi_label=True
        )
        
        logger.info("Zero-shot classifier loaded successfully")
    
    def detect_unpatterned_entities(self, 
                                    text: str,
                                    entity_types: List[str],
                                    threshold: float = 0.7) -> List[NEREntity]:
        """
        Detect entities without regex patterns using zero-shot classification.
        
        Args:
            text: Text to analyze
            entity_types: List of entity types to detect (150 unpatterned types)
            threshold: Confidence threshold
        """
        entities = []
        
        # Process in sliding windows
        window_size = 256
        stride = 128
        windows = []
        
        # Create windows
        sentences = text.split('. ')
        current_window = []
        current_length = 0
        
        for sentence in sentences:
            if current_length + len(sentence) > window_size:
                if current_window:
                    windows.append('. '.join(current_window))
                current_window = [sentence]
                current_length = len(sentence)
            else:
                current_window.append(sentence)
                current_length += len(sentence)
        
        if current_window:
            windows.append('. '.join(current_window))
        
        logger.info(f"Processing {len(windows)} windows for zero-shot classification")
        
        # Process each window
        for window in windows[:10]:  # Limit to first 10 windows for performance
            # Create hypothesis template
            hypothesis_template = "This text contains a legal {}."
            
            # Classify with top entity types
            result = self.classifier(
                window,
                candidate_labels=entity_types[:20],  # Limit types for performance
                hypothesis_template=hypothesis_template
            )
            
            # Extract high-confidence entities
            for label, score in zip(result['labels'], result['scores']):
                if score > threshold:
                    # Extract relevant text span
                    entity_text = self.extract_relevant_span(window, label)
                    
                    if entity_text:
                        start_pos = text.find(entity_text)
                        if start_pos != -1:
                            entity = NEREntity(
                                text=entity_text,
                                entity_type=label,
                                start_pos=start_pos,
                                end_pos=start_pos + len(entity_text),
                                confidence=score,
                                extraction_method="zero_shot"
                            )
                            entities.append(entity)
        
        logger.info(f"Zero-shot detected {len(entities)} unpatterned entities")
        return entities
    
    def extract_relevant_span(self, text: str, entity_type: str) -> Optional[str]:
        """
        Extract the relevant text span for an entity type.
        
        Args:
            text: Text containing the entity
            entity_type: Type of entity to extract
        """
        # Simple heuristic: extract noun phrases
        import re
        
        # Pattern for capitalized phrases (likely entities)
        pattern = r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b'
        matches = re.findall(pattern, text)
        
        if matches:
            # Return longest match as most likely entity
            return max(matches, key=len)
        
        return None


class HybridNERExtractor:
    """
    Combines all NER extractors for comprehensive entity extraction.
    """
    
    def __init__(self, device: str = "cuda:1"):
        """
        Initialize all NER extractors.
        
        Args:
            device: Device to run models on
        """
        self.device = device
        
        # Initialize extractors
        self.distilbert = DistilBERTNERExtractor(device)
        self.legal_bert = LegalBERTSmallExtractor(device)
        self.zero_shot = ZeroShotEntityExtractor(device)
        
        logger.info("Hybrid NER extractor initialized")
    
    def extract_all(self, 
                    text: str,
                    unpatterned_types: Optional[List[str]] = None) -> List[NEREntity]:
        """
        Extract entities using all available methods.
        
        Args:
            text: Text to extract from
            unpatterned_types: Entity types without patterns
        """
        all_entities = []
        
        # DistilBERT for general entities
        distilbert_entities = self.distilbert.extract(text)
        all_entities.extend(distilbert_entities)
        
        # Legal-BERT for legal-specific entities
        legal_entities = self.legal_bert.extract_legal_entities(text)
        all_entities.extend(legal_entities)
        
        # Zero-shot for unpatterned types
        if unpatterned_types:
            zero_shot_entities = self.zero_shot.detect_unpatterned_entities(
                text, unpatterned_types[:20]  # Limit for performance
            )
            all_entities.extend(zero_shot_entities)
        
        # Deduplicate and merge
        return self.deduplicate_entities(all_entities)
    
    def deduplicate_entities(self, entities: List[NEREntity]) -> List[NEREntity]:
        """
        Deduplicate and merge overlapping entities.
        
        Args:
            entities: List of entities to deduplicate
        """
        if not entities:
            return []
        
        # Sort by position
        entities.sort(key=lambda x: (x.start_pos or 0, x.end_pos or 0))
        
        # Merge overlapping entities
        merged = []
        current = entities[0]
        
        for entity in entities[1:]:
            # Check for overlap
            if (entity.start_pos and current.end_pos and 
                entity.start_pos < current.end_pos):
                # Merge if same type or keep higher confidence
                if entity.entity_type == current.entity_type:
                    current.confidence = max(current.confidence, entity.confidence)
                elif entity.confidence > current.confidence:
                    current = entity
            else:
                merged.append(current)
                current = entity
        
        merged.append(current)
        
        return merged