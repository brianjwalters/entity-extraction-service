"""
Relationship Extraction for CALES

Extracts relationships between legal entities using SpaCy dependency parsing
and pattern matching. Optimized for legal documents.
"""

import logging
from typing import List, Dict, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from itertools import combinations
import spacy
from spacy.tokens import Doc, Span, Token
import torch

from .hybrid_extraction_pipeline import UnifiedEntity
from .pattern_context_resolver import ResolvedContext, EntityRole

logger = logging.getLogger(__name__)


class RelationshipType(Enum):
    """Types of legal relationships"""
    # Representation relationships
    REPRESENTS = "represents"
    FORMERLY_REPRESENTED = "formerly_represented"
    CO_COUNSEL = "co_counsel"
    OPPOSING_COUNSEL = "opposing_counsel"
    
    # Party relationships
    SUES = "sues"
    SUED_BY = "sued_by"
    APPEALS_AGAINST = "appeals_against"
    SETTLES_WITH = "settles_with"
    CONTRACTS_WITH = "contracts_with"
    
    # Judicial relationships
    PRESIDES_OVER = "presides_over"
    RULED_ON = "ruled_on"
    SENTENCED = "sentenced"
    GRANTED = "granted"
    DENIED = "denied"
    
    # Citation relationships
    CITES = "cites"
    CITED_BY = "cited_by"
    OVERRULES = "overrules"
    OVERRULED_BY = "overruled_by"
    DISTINGUISHES = "distinguishes"
    FOLLOWS = "follows"
    
    # Temporal relationships
    FILED_ON = "filed_on"
    OCCURRED_ON = "occurred_on"
    EFFECTIVE_ON = "effective_on"
    EXPIRES_ON = "expires_on"
    
    # Financial relationships
    AWARDED_TO = "awarded_to"
    PAID_TO = "paid_to"
    OWES_TO = "owes_to"
    FINED = "fined"
    
    # Location relationships
    LOCATED_IN = "located_in"
    VENUE_FOR = "venue_for"
    JURISDICTION_OVER = "jurisdiction_over"
    
    # Generic
    RELATED_TO = "related_to"
    ASSOCIATED_WITH = "associated_with"


@dataclass
class LegalRelationship:
    """A relationship between two legal entities"""
    source_entity: UnifiedEntity
    target_entity: UnifiedEntity
    relationship_type: RelationshipType
    confidence: float
    evidence: str  # Text evidence for the relationship
    dependency_path: Optional[List[str]] = None
    sentence: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RelationshipPattern:
    """Pattern for relationship detection"""
    relationship_type: RelationshipType
    source_types: List[str]  # Entity types that can be source
    target_types: List[str]  # Entity types that can be target
    indicators: List[str]  # Keywords/phrases indicating relationship
    dependency_patterns: List[str] = field(default_factory=list)
    confidence_boost: float = 0.1
    directional: bool = True  # If False, relationship is bidirectional


class RelationshipExtractor:
    """
    Extracts relationships between legal entities using SpaCy and patterns.
    """
    
    def __init__(self, device: str = "cuda:1", model_name: str = "en_core_web_sm"):
        """
        Initialize relationship extractor.
        
        Args:
            device: Device to run SpaCy on
            model_name: SpaCy model to use
        """
        self.device = device
        
        # Load SpaCy model
        logger.info(f"Loading SpaCy model: {model_name}")
        try:
            self.nlp = spacy.load(model_name)
            # Move to GPU if available
            if "cuda" in device and spacy.prefer_gpu():
                logger.info("SpaCy using GPU acceleration")
        except OSError:
            # Fallback to smaller model
            logger.warning(f"Model {model_name} not found, using en_core_web_sm")
            self.nlp = spacy.load("en_core_web_sm")
        
        # Initialize relationship patterns
        self.relationship_patterns = self._initialize_patterns()
        
        # Cache for dependency parsing
        self.doc_cache = {}
        
        logger.info("Relationship extractor initialized")
    
    def _initialize_patterns(self) -> List[RelationshipPattern]:
        """Initialize legal relationship patterns"""
        patterns = [
            # Representation relationships
            RelationshipPattern(
                RelationshipType.REPRESENTS,
                source_types=["LAW_FIRM", "ATTORNEY"],
                target_types=["PARTY", "COMPANY", "PERSON"],
                indicators=["representing", "represents", "counsel for", "attorney for",
                           "on behalf of", "appears for", "retained by"],
                dependency_patterns=["nsubj->ROOT->prep->pobj", "nsubj->ROOT->dobj"],
                confidence_boost=0.3
            ),
            RelationshipPattern(
                RelationshipType.FORMERLY_REPRESENTED,
                source_types=["LAW_FIRM", "ATTORNEY"],
                target_types=["PARTY", "COMPANY", "PERSON"],
                indicators=["formerly represented", "withdrew as counsel", "former counsel",
                           "previously represented", "no longer represents"],
                confidence_boost=0.25
            ),
            RelationshipPattern(
                RelationshipType.OPPOSING_COUNSEL,
                source_types=["LAW_FIRM", "ATTORNEY"],
                target_types=["LAW_FIRM", "ATTORNEY"],
                indicators=["opposing counsel", "adverse party", "opponent", "versus",
                           "against", "defending against"],
                confidence_boost=0.2,
                directional=False
            ),
            
            # Party relationships
            RelationshipPattern(
                RelationshipType.SUES,
                source_types=["PARTY", "COMPANY", "PERSON"],
                target_types=["PARTY", "COMPANY", "PERSON"],
                indicators=["sues", "filed suit against", "brings action against",
                           "plaintiff", "commenced action", "alleges against"],
                confidence_boost=0.3
            ),
            RelationshipPattern(
                RelationshipType.APPEALS_AGAINST,
                source_types=["PARTY", "COMPANY", "PERSON"],
                target_types=["PARTY", "COMPANY", "PERSON"],
                indicators=["appeals", "appellant", "challenges", "seeks review",
                           "appeals from", "appealing"],
                confidence_boost=0.25
            ),
            RelationshipPattern(
                RelationshipType.SETTLES_WITH,
                source_types=["PARTY", "COMPANY", "PERSON"],
                target_types=["PARTY", "COMPANY", "PERSON"],
                indicators=["settles with", "settlement between", "agreed to settle",
                           "settlement agreement", "resolved claims"],
                confidence_boost=0.25,
                directional=False
            ),
            
            # Judicial relationships
            RelationshipPattern(
                RelationshipType.PRESIDES_OVER,
                source_types=["JUDGE"],
                target_types=["CASE", "HEARING", "TRIAL"],
                indicators=["presiding", "presides over", "before judge", "assigned to",
                           "the honorable", "sitting judge"],
                confidence_boost=0.3
            ),
            RelationshipPattern(
                RelationshipType.RULED_ON,
                source_types=["JUDGE", "COURT"],
                target_types=["MOTION", "CASE", "CLAIM"],
                indicators=["ruled", "held", "found", "determined", "decided",
                           "judgment", "order", "opinion"],
                confidence_boost=0.25
            ),
            RelationshipPattern(
                RelationshipType.GRANTED,
                source_types=["JUDGE", "COURT"],
                target_types=["MOTION", "PETITION", "REQUEST"],
                indicators=["granted", "grants", "approved", "allows", "sustains"],
                confidence_boost=0.25
            ),
            RelationshipPattern(
                RelationshipType.DENIED,
                source_types=["JUDGE", "COURT"],
                target_types=["MOTION", "PETITION", "REQUEST"],
                indicators=["denied", "denies", "rejected", "overruled", "dismissed"],
                confidence_boost=0.25
            ),
            
            # Citation relationships
            RelationshipPattern(
                RelationshipType.CITES,
                source_types=["CASE", "OPINION", "BRIEF"],
                target_types=["CASE", "STATUTE", "REGULATION"],
                indicators=["cites", "citing", "references", "relies on", "pursuant to",
                           "under", "according to"],
                confidence_boost=0.2
            ),
            RelationshipPattern(
                RelationshipType.OVERRULES,
                source_types=["CASE", "COURT"],
                target_types=["CASE"],
                indicators=["overrules", "overruling", "abrogates", "supersedes",
                           "reverses", "vacates"],
                confidence_boost=0.3
            ),
            
            # Temporal relationships
            RelationshipPattern(
                RelationshipType.FILED_ON,
                source_types=["DOCUMENT", "MOTION", "COMPLAINT", "BRIEF"],
                target_types=["DATE"],
                indicators=["filed on", "filed", "submitted on", "dated", "as of"],
                confidence_boost=0.2
            ),
            
            # Financial relationships
            RelationshipPattern(
                RelationshipType.AWARDED_TO,
                source_types=["MONETARY_AMOUNT"],
                target_types=["PARTY", "PERSON"],
                indicators=["awarded to", "granted to", "entitled to", "damages to",
                           "judgment for", "in favor of"],
                confidence_boost=0.25
            ),
            RelationshipPattern(
                RelationshipType.FINED,
                source_types=["COURT", "AGENCY"],
                target_types=["PARTY", "PERSON", "COMPANY"],
                indicators=["fined", "imposed fine", "penalty", "assessed", "sanctioned"],
                confidence_boost=0.25
            ),
            
            # Location relationships
            RelationshipPattern(
                RelationshipType.VENUE_FOR,
                source_types=["COURT", "JURISDICTION"],
                target_types=["CASE", "TRIAL", "HEARING"],
                indicators=["venue", "in the", "before the", "transferred to",
                           "proper venue", "jurisdiction of"],
                confidence_boost=0.2
            ),
        ]
        
        return patterns
    
    def extract_relationships(self,
                            entities: List[UnifiedEntity],
                            document: str,
                            contexts: Optional[List[ResolvedContext]] = None) -> List[LegalRelationship]:
        """
        Extract relationships between entities.
        
        Args:
            entities: List of entities to find relationships between
            document: Full document text
            contexts: Optional resolved contexts for entities
        """
        relationships = []
        
        # Parse document with SpaCy
        doc = self._parse_document(document)
        
        # Group entities by sentence
        sentence_entities = self._group_entities_by_sentence(entities, doc)
        
        # Extract relationships within each sentence
        for sent_idx, (sent, sent_entities) in enumerate(sentence_entities.items()):
            if len(sent_entities) < 2:
                continue
            
            # Check each pair of entities
            for entity1, entity2 in combinations(sent_entities, 2):
                # Find relationships using patterns
                pattern_rels = self._find_pattern_relationships(
                    entity1, entity2, sent.text
                )
                relationships.extend(pattern_rels)
                
                # Find relationships using dependency parsing
                dep_rels = self._find_dependency_relationships(
                    entity1, entity2, sent, doc
                )
                relationships.extend(dep_rels)
        
        # Find cross-sentence relationships (coreference)
        cross_rels = self._find_cross_sentence_relationships(entities, doc)
        relationships.extend(cross_rels)
        
        # Use context information to enhance relationships
        if contexts:
            relationships = self._enhance_with_context(relationships, contexts)
        
        # Deduplicate and filter
        relationships = self._deduplicate_relationships(relationships)
        
        return relationships
    
    def _parse_document(self, document: str) -> Doc:
        """Parse document with SpaCy (with caching)"""
        # Check cache
        doc_hash = hash(document[:1000])  # Hash first 1000 chars
        if doc_hash in self.doc_cache:
            return self.doc_cache[doc_hash]
        
        # Parse document
        doc = self.nlp(document[:50000])  # Limit document size
        
        # Cache result
        self.doc_cache[doc_hash] = doc
        
        return doc
    
    def _group_entities_by_sentence(self,
                                   entities: List[UnifiedEntity],
                                   doc: Doc) -> Dict[Span, List[UnifiedEntity]]:
        """Group entities by the sentences they appear in"""
        sentence_entities = {}
        
        for sent in doc.sents:
            sent_entities = []
            sent_start = sent.start_char
            sent_end = sent.end_char
            
            for entity in entities:
                if entity.start_pos is not None and entity.end_pos is not None:
                    # Check if entity is in this sentence
                    if (entity.start_pos >= sent_start and 
                        entity.end_pos <= sent_end):
                        sent_entities.append(entity)
                else:
                    # Fallback: check if entity text is in sentence
                    if entity.text in sent.text:
                        sent_entities.append(entity)
            
            if sent_entities:
                sentence_entities[sent] = sent_entities
        
        return sentence_entities
    
    def _find_pattern_relationships(self,
                                   entity1: UnifiedEntity,
                                   entity2: UnifiedEntity,
                                   sentence: str) -> List[LegalRelationship]:
        """Find relationships using pattern matching"""
        relationships = []
        
        for pattern in self.relationship_patterns:
            # Check if entity types match
            if (entity1.entity_type in pattern.source_types and
                entity2.entity_type in pattern.target_types):
                
                # Check for indicator phrases
                for indicator in pattern.indicators:
                    if indicator.lower() in sentence.lower():
                        # Check proximity
                        if self._check_proximity(entity1.text, entity2.text, sentence, indicator):
                            rel = LegalRelationship(
                                source_entity=entity1,
                                target_entity=entity2,
                                relationship_type=pattern.relationship_type,
                                confidence=0.6 + pattern.confidence_boost,
                                evidence=indicator,
                                sentence=sentence
                            )
                            relationships.append(rel)
                            break
            
            # Check reverse direction if not directional
            if not pattern.directional:
                if (entity2.entity_type in pattern.source_types and
                    entity1.entity_type in pattern.target_types):
                    
                    for indicator in pattern.indicators:
                        if indicator.lower() in sentence.lower():
                            if self._check_proximity(entity2.text, entity1.text, sentence, indicator):
                                rel = LegalRelationship(
                                    source_entity=entity2,
                                    target_entity=entity1,
                                    relationship_type=pattern.relationship_type,
                                    confidence=0.6 + pattern.confidence_boost,
                                    evidence=indicator,
                                    sentence=sentence
                                )
                                relationships.append(rel)
                                break
        
        return relationships
    
    def _find_dependency_relationships(self,
                                      entity1: UnifiedEntity,
                                      entity2: UnifiedEntity,
                                      sent: Span,
                                      doc: Doc) -> List[LegalRelationship]:
        """Find relationships using dependency parsing"""
        relationships = []
        
        # Find tokens for entities
        entity1_tokens = self._find_entity_tokens(entity1, sent)
        entity2_tokens = self._find_entity_tokens(entity2, sent)
        
        if not entity1_tokens or not entity2_tokens:
            return relationships
        
        # Get dependency path between entities
        for token1 in entity1_tokens:
            for token2 in entity2_tokens:
                path = self._get_dependency_path(token1, token2)
                
                if path and len(path) <= 5:  # Short path indicates relationship
                    # Analyze path to determine relationship type
                    rel_type = self._analyze_dependency_path(path, token1, token2)
                    
                    if rel_type:
                        rel = LegalRelationship(
                            source_entity=entity1,
                            target_entity=entity2,
                            relationship_type=rel_type,
                            confidence=0.7,
                            evidence=f"Dependency path: {' -> '.join([t.dep_ for t in path])}",
                            dependency_path=[t.dep_ for t in path],
                            sentence=sent.text
                        )
                        relationships.append(rel)
        
        return relationships
    
    def _find_entity_tokens(self, entity: UnifiedEntity, sent: Span) -> List[Token]:
        """Find tokens corresponding to an entity in a sentence"""
        tokens = []
        
        for token in sent:
            if entity.text.lower() in token.text.lower():
                tokens.append(token)
            elif token.text.lower() in entity.text.lower():
                tokens.append(token)
        
        return tokens
    
    def _get_dependency_path(self, token1: Token, token2: Token) -> List[Token]:
        """Get dependency path between two tokens"""
        # Find common ancestor
        ancestors1 = list(token1.ancestors)
        ancestors2 = list(token2.ancestors)
        
        common = None
        for anc in ancestors1:
            if anc in ancestors2:
                common = anc
                break
        
        if not common:
            # Check if one is ancestor of other
            if token1 in ancestors2:
                common = token1
            elif token2 in ancestors1:
                common = token2
            else:
                return []
        
        # Build path
        path1 = [token1]
        current = token1
        while current != common:
            current = current.head
            path1.append(current)
        
        path2 = []
        current = token2
        while current != common:
            current = current.head
            path2.append(current)
        
        # Combine paths
        path = path1 + list(reversed(path2))
        
        return path
    
    def _analyze_dependency_path(self, 
                                path: List[Token],
                                token1: Token,
                                token2: Token) -> Optional[RelationshipType]:
        """Analyze dependency path to determine relationship type"""
        # Look for key dependency relations
        deps = [t.dep_ for t in path]
        lemmas = [t.lemma_ for t in path]
        
        # Representation relationships
        if "represent" in lemmas or "counsel" in lemmas:
            return RelationshipType.REPRESENTS
        
        # Sue relationships
        if "sue" in lemmas or "plaintiff" in lemmas:
            return RelationshipType.SUES
        
        # Judicial relationships
        if "rule" in lemmas or "hold" in lemmas or "find" in lemmas:
            return RelationshipType.RULED_ON
        
        if "grant" in lemmas:
            return RelationshipType.GRANTED
        
        if "deny" in lemmas or "dismiss" in lemmas:
            return RelationshipType.DENIED
        
        # Default to related if short path
        if len(path) <= 3:
            return RelationshipType.RELATED_TO
        
        return None
    
    def _check_proximity(self, 
                        text1: str,
                        text2: str,
                        sentence: str,
                        indicator: str) -> bool:
        """Check if entities and indicator are in proximity"""
        pos1 = sentence.lower().find(text1.lower())
        pos2 = sentence.lower().find(text2.lower())
        pos_ind = sentence.lower().find(indicator.lower())
        
        if pos1 == -1 or pos2 == -1 or pos_ind == -1:
            return False
        
        # Check if indicator is between entities
        if min(pos1, pos2) < pos_ind < max(pos1, pos2):
            return True
        
        # Check if all within reasonable distance
        max_distance = 100  # characters
        if (abs(pos1 - pos_ind) < max_distance and 
            abs(pos2 - pos_ind) < max_distance):
            return True
        
        return False
    
    def _find_cross_sentence_relationships(self,
                                          entities: List[UnifiedEntity],
                                          doc: Doc) -> List[LegalRelationship]:
        """Find relationships across sentences (e.g., coreference)"""
        relationships = []
        
        # Simple coreference: look for pronouns referring to entities
        # This is simplified - full coreference resolution would be more complex
        
        return relationships
    
    def _enhance_with_context(self,
                            relationships: List[LegalRelationship],
                            contexts: List[ResolvedContext]) -> List[LegalRelationship]:
        """Enhance relationships using context information"""
        # Create context lookup
        context_map = {ctx.entity.text: ctx for ctx in contexts}
        
        for rel in relationships:
            # Check source context
            if rel.source_entity.text in context_map:
                source_ctx = context_map[rel.source_entity.text]
                
                # Boost confidence if context supports relationship
                if source_ctx.primary_role == EntityRole.PLAINTIFF_COUNSEL:
                    if rel.relationship_type == RelationshipType.REPRESENTS:
                        rel.confidence = min(0.95, rel.confidence + 0.1)
            
            # Check target context
            if rel.target_entity.text in context_map:
                target_ctx = context_map[rel.target_entity.text]
                
                if target_ctx.primary_role == EntityRole.PLAINTIFF:
                    if rel.relationship_type == RelationshipType.REPRESENTS:
                        rel.confidence = min(0.95, rel.confidence + 0.1)
        
        return relationships
    
    def _deduplicate_relationships(self,
                                  relationships: List[LegalRelationship]) -> List[LegalRelationship]:
        """Deduplicate and merge similar relationships"""
        unique = []
        seen = set()
        
        for rel in relationships:
            # Create unique key
            key = (
                rel.source_entity.text,
                rel.target_entity.text,
                rel.relationship_type.value
            )
            
            if key not in seen:
                seen.add(key)
                unique.append(rel)
            else:
                # Merge confidence if duplicate
                for existing in unique:
                    if (existing.source_entity.text == rel.source_entity.text and
                        existing.target_entity.text == rel.target_entity.text and
                        existing.relationship_type == rel.relationship_type):
                        existing.confidence = max(existing.confidence, rel.confidence)
                        if rel.evidence and rel.evidence not in existing.evidence:
                            existing.evidence += f"; {rel.evidence}"
        
        return unique