"""
CALES - Context-Aware Legal Entity Service

This package provides context-aware entity extraction capabilities for legal documents,
including dynamic model loading, relationship extraction, and unpatterned entity detection.
"""

from .cales_service import (
    ContextAwareExtractionService,
    CALESConfig,
    CALESExtractionResult
)

from .entity_registry import (
    DynamicEntityTypeRegistry,
    EntityTypeInfo,
    PatternInfo,
    RegistryStats
)

__version__ = "1.0.0"
__author__ = "Luris Platform Team"

__all__ = [
    "ContextAwareExtractionService",
    "CALESConfig", 
    "CALESExtractionResult",
    "DynamicEntityTypeRegistry",
    "EntityTypeInfo",
    "PatternInfo",
    "RegistryStats"
]