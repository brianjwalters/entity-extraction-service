"""
Dynamic Entity Type Registry for CALES Entity Extraction Service

This registry loads entity types dynamically from API endpoints, providing
comprehensive entity type information without hardcoding. Integrates with
the 272 entity types and pattern system.
"""

import asyncio
import aiohttp
import logging
import json
import time
from typing import Dict, List, Optional, Any, Set, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import os
from collections import defaultdict

# Configure logging
logger = logging.getLogger(__name__)


class RegistryStatus(Enum):
    """Registry status states"""
    UNINITIALIZED = "uninitialized"
    LOADING = "loading"
    LOADED = "loaded"
    ERROR = "error"
    REFRESHING = "refreshing"


@dataclass
class EntityTypeInfo:
    """Complete information about an entity type"""
    type_name: str
    category: str
    description: str
    patterns: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    confidence_threshold: float = 0.7
    context_hints: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    last_updated: Optional[datetime] = None


@dataclass
class PatternInfo:
    """Information about extraction patterns"""
    pattern_id: str
    pattern_text: str
    entity_type: str
    confidence_weight: float
    is_active: bool
    validation_status: str
    examples: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RegistryStats:
    """Registry statistics and health info"""
    total_entity_types: int
    active_entity_types: int
    total_patterns: int
    active_patterns: int
    last_refresh: Optional[datetime]
    refresh_count: int
    error_count: int
    cache_hit_rate: float
    avg_response_time_ms: float


class DynamicEntityTypeRegistry:
    """
    Dynamic registry that loads entity types and patterns from API endpoints.
    Provides caching, refresh capabilities, and comprehensive entity type management.
    """
    
    def __init__(self,
                 base_url: str = "http://localhost:8007",
                 refresh_interval_minutes: int = 60,
                 enable_caching: bool = True,
                 cache_ttl_minutes: int = 30,
                 max_retries: int = 3):
        """
        Initialize the dynamic entity registry.
        
        Args:
            base_url: Base URL for entity extraction service API
            refresh_interval_minutes: How often to refresh from API
            enable_caching: Whether to cache responses
            cache_ttl_minutes: Cache time-to-live in minutes
            max_retries: Maximum retry attempts for API calls
        """
        self.base_url = base_url.rstrip('/')
        self.refresh_interval = timedelta(minutes=refresh_interval_minutes)
        self.enable_caching = enable_caching
        self.cache_ttl = timedelta(minutes=cache_ttl_minutes)
        self.max_retries = max_retries
        
        # Registry data
        self.entity_types: Dict[str, EntityTypeInfo] = {}
        self.patterns: Dict[str, PatternInfo] = {}
        self.categories: Dict[str, List[str]] = defaultdict(list)
        
        # Registry state
        self.status = RegistryStatus.UNINITIALIZED
        self.last_refresh: Optional[datetime] = None
        self.refresh_count = 0
        self.error_count = 0
        
        # Caching
        self._cache: Dict[str, Tuple[Any, datetime]] = {}
        self._api_response_times: List[float] = []
        
        # Session for HTTP requests
        self._session: Optional[aiohttp.ClientSession] = None
        
        logger.info(f"Dynamic Entity Registry initialized with base URL: {self.base_url}")
    
    async def initialize(self) -> bool:
        """
        Initialize the registry by loading entity types and patterns.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.status = RegistryStatus.LOADING
            logger.info("Initializing Dynamic Entity Registry...")
            
            # Create HTTP session
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={'User-Agent': 'CALES-EntityRegistry/1.0'}
            )
            
            # Load entity types and patterns
            await self._load_entity_types()
            await self._load_patterns()
            
            # Organize data
            self._organize_by_categories()
            
            self.status = RegistryStatus.LOADED
            self.last_refresh = datetime.now()
            self.refresh_count = 1
            
            logger.info(f"✅ Registry initialized: {len(self.entity_types)} entity types, "
                       f"{len(self.patterns)} patterns")
            
            # Schedule periodic refresh
            asyncio.create_task(self._periodic_refresh())
            
            return True
            
        except Exception as e:
            self.status = RegistryStatus.ERROR
            self.error_count += 1
            logger.error(f"Failed to initialize entity registry: {e}")
            return False
    
    async def _load_entity_types(self):
        """Load entity types from /entity-types endpoint"""
        endpoint = f"{self.base_url}/api/v1/entity-types"
        
        try:
            response_data = await self._make_api_call(endpoint)
            
            if not response_data or 'entity_types' not in response_data:
                logger.warning(f"No entity types found in response from {endpoint}")
                return
            
            entity_types_data = response_data['entity_types']
            logger.info(f"Loading {len(entity_types_data)} entity types from API...")
            
            for type_data in entity_types_data:
                try:
                    entity_info = EntityTypeInfo(
                        type_name=type_data.get('name', type_data.get('type', 'unknown')),
                        category=type_data.get('category', 'general'),
                        description=type_data.get('description', ''),
                        examples=type_data.get('examples', []),
                        confidence_threshold=type_data.get('confidence_threshold', 0.7),
                        context_hints=type_data.get('context_hints', []),
                        metadata=type_data.get('metadata', {}),
                        is_active=type_data.get('is_active', True),
                        last_updated=datetime.now()
                    )
                    
                    self.entity_types[entity_info.type_name] = entity_info
                    
                except Exception as e:
                    logger.warning(f"Failed to process entity type {type_data}: {e}")
            
            logger.info(f"✅ Loaded {len(self.entity_types)} entity types")
            
        except Exception as e:
            logger.error(f"Failed to load entity types: {e}")
            raise
    
    async def _load_patterns(self):
        """Load patterns from /patterns endpoint"""
        endpoint = f"{self.base_url}/api/v1/patterns"
        
        try:
            response_data = await self._make_api_call(endpoint)
            
            if not response_data:
                logger.warning(f"No patterns found in response from {endpoint}")
                return
            
            # Handle different response formats
            patterns_data = []
            if 'patterns' in response_data:
                patterns_data = response_data['patterns']
            elif 'pattern_groups' in response_data:
                # Flatten pattern groups
                for group in response_data['pattern_groups']:
                    if 'patterns' in group:
                        for pattern in group['patterns']:
                            pattern['entity_type'] = group.get('entity_type', 'unknown')
                            patterns_data.append(pattern)
            
            logger.info(f"Loading {len(patterns_data)} patterns from API...")
            
            for pattern_data in patterns_data:
                try:
                    pattern_info = PatternInfo(
                        pattern_id=pattern_data.get('id', f"pattern_{len(self.patterns)}"),
                        pattern_text=pattern_data.get('pattern', pattern_data.get('regex', '')),
                        entity_type=pattern_data.get('entity_type', 'unknown'),
                        confidence_weight=pattern_data.get('confidence', 1.0),
                        is_active=pattern_data.get('is_active', True),
                        validation_status=pattern_data.get('status', 'unknown'),
                        examples=pattern_data.get('examples', []),
                        metadata=pattern_data.get('metadata', {})
                    )
                    
                    self.patterns[pattern_info.pattern_id] = pattern_info
                    
                    # Link pattern to entity type
                    if pattern_info.entity_type in self.entity_types:
                        entity_info = self.entity_types[pattern_info.entity_type]
                        if pattern_info.pattern_text not in entity_info.patterns:
                            entity_info.patterns.append(pattern_info.pattern_text)
                    
                except Exception as e:
                    logger.warning(f"Failed to process pattern {pattern_data}: {e}")
            
            logger.info(f"✅ Loaded {len(self.patterns)} patterns")
            
        except Exception as e:
            logger.error(f"Failed to load patterns: {e}")
            # Don't raise here - patterns are optional for entity registry
    
    async def _make_api_call(self, endpoint: str) -> Optional[Dict[str, Any]]:
        """
        Make HTTP API call with retries and caching.
        
        Args:
            endpoint: API endpoint URL
            
        Returns:
            Response data or None
        """
        # Check cache first
        if self.enable_caching and endpoint in self._cache:
            cached_data, cached_time = self._cache[endpoint]
            if datetime.now() - cached_time < self.cache_ttl:
                logger.debug(f"Cache hit for {endpoint}")
                return cached_data
        
        # Make API call with retries
        for attempt in range(self.max_retries):
            try:
                start_time = time.time()
                
                async with self._session.get(endpoint) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Record response time
                        response_time = (time.time() - start_time) * 1000
                        self._api_response_times.append(response_time)
                        if len(self._api_response_times) > 100:
                            self._api_response_times = self._api_response_times[-100:]
                        
                        # Cache response
                        if self.enable_caching:
                            self._cache[endpoint] = (data, datetime.now())
                        
                        logger.debug(f"API call successful: {endpoint} ({response_time:.1f}ms)")
                        return data
                    
                    elif response.status == 404:
                        logger.warning(f"Endpoint not found: {endpoint}")
                        return None
                    
                    else:
                        logger.warning(f"API call failed: {endpoint} - Status {response.status}")
                        if attempt == self.max_retries - 1:
                            raise aiohttp.ClientError(f"HTTP {response.status}")
            
            except Exception as e:
                if attempt == self.max_retries - 1:
                    logger.error(f"API call failed after {self.max_retries} attempts: {endpoint} - {e}")
                    raise
                else:
                    logger.warning(f"API call attempt {attempt + 1} failed: {endpoint} - {e}")
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        return None
    
    def _organize_by_categories(self):
        """Organize entity types by categories"""
        self.categories.clear()
        
        for entity_type, info in self.entity_types.items():
            if info.is_active:
                self.categories[info.category].append(entity_type)
        
        logger.info(f"Organized entity types into {len(self.categories)} categories")
    
    async def _periodic_refresh(self):
        """Periodically refresh registry data"""
        while True:
            try:
                await asyncio.sleep(self.refresh_interval.total_seconds())
                
                if self.status not in [RegistryStatus.ERROR, RegistryStatus.UNINITIALIZED]:
                    await self.refresh()
                    
            except Exception as e:
                logger.error(f"Error in periodic refresh: {e}")
    
    async def refresh(self) -> bool:
        """
        Refresh registry data from API endpoints.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            self.status = RegistryStatus.REFRESHING
            logger.info("Refreshing entity registry from API...")
            
            # Clear cache
            self._cache.clear()
            
            # Reload data
            await self._load_entity_types()
            await self._load_patterns()
            self._organize_by_categories()
            
            self.status = RegistryStatus.LOADED
            self.last_refresh = datetime.now()
            self.refresh_count += 1
            
            logger.info(f"✅ Registry refreshed: {len(self.entity_types)} entity types, "
                       f"{len(self.patterns)} patterns")
            
            return True
            
        except Exception as e:
            self.status = RegistryStatus.ERROR
            self.error_count += 1
            logger.error(f"Failed to refresh registry: {e}")
            return False
    
    def get_entity_type(self, type_name: str) -> Optional[EntityTypeInfo]:
        """Get information about a specific entity type"""
        return self.entity_types.get(type_name)
    
    def get_entity_types_by_category(self, category: str) -> List[EntityTypeInfo]:
        """Get all entity types in a specific category"""
        entity_names = self.categories.get(category, [])
        return [self.entity_types[name] for name in entity_names if name in self.entity_types]
    
    def get_all_entity_types(self, active_only: bool = True) -> List[EntityTypeInfo]:
        """Get all entity types"""
        if active_only:
            return [info for info in self.entity_types.values() if info.is_active]
        return list(self.entity_types.values())
    
    def get_entity_type_names(self, active_only: bool = True) -> List[str]:
        """Get list of entity type names"""
        if active_only:
            return [name for name, info in self.entity_types.items() if info.is_active]
        return list(self.entity_types.keys())
    
    def get_patterns_for_entity_type(self, entity_type: str) -> List[PatternInfo]:
        """Get all patterns for a specific entity type"""
        return [pattern for pattern in self.patterns.values() 
                if pattern.entity_type == entity_type and pattern.is_active]
    
    def get_categories(self) -> List[str]:
        """Get all entity type categories"""
        return list(self.categories.keys())
    
    def search_entity_types(self, query: str) -> List[EntityTypeInfo]:
        """Search entity types by name or description"""
        query = query.lower()
        results = []
        
        for info in self.entity_types.values():
            if not info.is_active:
                continue
                
            if (query in info.type_name.lower() or 
                query in info.description.lower() or
                any(query in example.lower() for example in info.examples)):
                results.append(info)
        
        return results
    
    def get_registry_stats(self) -> RegistryStats:
        """Get registry statistics and health information"""
        active_entity_types = sum(1 for info in self.entity_types.values() if info.is_active)
        active_patterns = sum(1 for pattern in self.patterns.values() if pattern.is_active)
        
        # Calculate cache hit rate
        cache_hit_rate = 0.0
        if self._api_response_times:
            # Simplified cache hit rate calculation
            cache_hit_rate = 0.8  # Would implement proper tracking
        
        # Calculate average response time
        avg_response_time = 0.0
        if self._api_response_times:
            avg_response_time = sum(self._api_response_times) / len(self._api_response_times)
        
        return RegistryStats(
            total_entity_types=len(self.entity_types),
            active_entity_types=active_entity_types,
            total_patterns=len(self.patterns),
            active_patterns=active_patterns,
            last_refresh=self.last_refresh,
            refresh_count=self.refresh_count,
            error_count=self.error_count,
            cache_hit_rate=cache_hit_rate,
            avg_response_time_ms=avg_response_time
        )
    
    def is_entity_type_valid(self, entity_type: str) -> bool:
        """Check if an entity type is valid and active"""
        info = self.get_entity_type(entity_type)
        return info is not None and info.is_active
    
    def get_confidence_threshold(self, entity_type: str) -> float:
        """Get confidence threshold for a specific entity type"""
        info = self.get_entity_type(entity_type)
        return info.confidence_threshold if info else 0.7
    
    def get_context_hints(self, entity_type: str) -> List[str]:
        """Get context hints for a specific entity type"""
        info = self.get_entity_type(entity_type)
        return info.context_hints if info else []
    
    async def cleanup(self):
        """Cleanup registry resources"""
        logger.info("Cleaning up entity registry...")
        
        if self._session:
            await self._session.close()
            self._session = None
        
        self._cache.clear()
        self.status = RegistryStatus.UNINITIALIZED
        
        logger.info("Entity registry cleanup completed")
    
    def __repr__(self) -> str:
        return (f"DynamicEntityTypeRegistry(status={self.status.value}, "
                f"entity_types={len(self.entity_types)}, "
                f"patterns={len(self.patterns)})")


# Helper function for standalone usage
async def create_entity_registry(base_url: str = "http://localhost:8007") -> DynamicEntityTypeRegistry:
    """
    Create and initialize an entity registry.
    
    Args:
        base_url: Base URL for the entity extraction service
        
    Returns:
        Initialized entity registry
    """
    registry = DynamicEntityTypeRegistry(base_url=base_url)
    success = await registry.initialize()
    
    if not success:
        raise RuntimeError("Failed to initialize entity registry")
    
    return registry


# CLI interface for testing
if __name__ == "__main__":
    import argparse
    import asyncio
    
    async def main():
        parser = argparse.ArgumentParser(description="Dynamic Entity Registry")
        parser.add_argument("--base-url", default="http://localhost:8007", help="Base URL for API")
        parser.add_argument("--list-types", action="store_true", help="List all entity types")
        parser.add_argument("--list-categories", action="store_true", help="List all categories")
        parser.add_argument("--search", help="Search entity types")
        parser.add_argument("--stats", action="store_true", help="Show registry statistics")
        parser.add_argument("--refresh", action="store_true", help="Force refresh from API")
        
        args = parser.parse_args()
        
        try:
            registry = await create_entity_registry(base_url=args.base_url)
            
            if args.list_types:
                types = registry.get_all_entity_types()
                print(f"Entity Types ({len(types)}):")
                for entity_type in types:
                    print(f"  - {entity_type.type_name} ({entity_type.category}): {entity_type.description}")
            
            if args.list_categories:
                categories = registry.get_categories()
                print(f"Categories ({len(categories)}):")
                for category in categories:
                    types = registry.get_entity_types_by_category(category)
                    print(f"  - {category}: {len(types)} types")
            
            if args.search:
                results = registry.search_entity_types(args.search)
                print(f"Search Results for '{args.search}' ({len(results)}):")
                for result in results:
                    print(f"  - {result.type_name}: {result.description}")
            
            if args.stats:
                stats = registry.get_registry_stats()
                print("Registry Statistics:")
                print(f"  - Total Entity Types: {stats.total_entity_types}")
                print(f"  - Active Entity Types: {stats.active_entity_types}")
                print(f"  - Total Patterns: {stats.total_patterns}")
                print(f"  - Active Patterns: {stats.active_patterns}")
                print(f"  - Last Refresh: {stats.last_refresh}")
                print(f"  - Refresh Count: {stats.refresh_count}")
                print(f"  - Error Count: {stats.error_count}")
                print(f"  - Avg Response Time: {stats.avg_response_time_ms:.1f}ms")
            
            if args.refresh:
                success = await registry.refresh()
                print(f"Registry refresh: {'successful' if success else 'failed'}")
            
            await registry.cleanup()
            
        except Exception as e:
            print(f"Error: {e}")
            return 1
        
        return 0
    
    exit(asyncio.run(main()))