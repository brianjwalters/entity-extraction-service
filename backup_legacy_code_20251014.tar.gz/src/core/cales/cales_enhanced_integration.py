"""
CALES Enhanced Integration

This module integrates the enhanced CALES system with pattern-guided prompts
into the existing CALES service architecture, providing hybrid extraction
with dynamic prompt building.
"""

import asyncio
import logging
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from .cales_service import ContextAwareExtractionService, CALESConfig, CALESExtractionResult
from .enhanced_cales_service import EnhancedCALESService
from .enhanced_cales_config import EnhancedCALESConfig, ExtractionMode, ExtractionStrategy
from ..context.context_window_extractor import ExtractedEntity

logger = logging.getLogger(__name__)


@dataclass
class HybridCALESConfig:
    """Configuration for hybrid CALES operation"""
    # Enhanced extraction settings
    use_enhanced_prompts: bool = True
    extraction_mode: ExtractionMode = ExtractionMode.HYBRID
    extraction_strategy: ExtractionStrategy = ExtractionStrategy.AUTO
    
    # Pattern integration
    enable_pattern_examples: bool = True
    pattern_service_url: str = "http://10.10.0.87:8007"
    max_examples_per_entity: int = 3
    pattern_confidence_boost: float = 0.15
    
    # Fallback settings
    fallback_to_legacy: bool = True
    enable_legacy_components: bool = True
    
    # Performance settings
    processing_timeout_seconds: int = 300
    enable_parallel_processing: bool = True


class HybridCALESService:
    """
    Hybrid CALES service that combines the enhanced pattern-guided extraction
    with the existing CALES context and relationship extraction capabilities.
    """
    
    def __init__(self, 
                 config: Optional[HybridCALESConfig] = None,
                 vllm_client: Optional[Any] = None,
                 supabase_client: Optional[Any] = None):
        """Initialize the hybrid CALES service."""
        self.config = config or HybridCALESConfig()
        self.vllm_client = vllm_client
        self.supabase_client = supabase_client
        
        # Initialize both services
        self.enhanced_service = None
        self.legacy_service = None
        self._initialized = False
        
        logger.info("Hybrid CALES service initialized")
    
    async def initialize(self) -> bool:
        """Initialize both enhanced and legacy CALES services."""
        try:
            logger.info("Initializing hybrid CALES services...")
            
            # Initialize enhanced service if enabled
            if self.config.use_enhanced_prompts:
                try:
                    enhanced_config = EnhancedCALESConfig(
                        extraction_mode=self.config.extraction_mode,
                        extraction_strategy=self.config.extraction_strategy,
                        enable_pattern_examples=self.config.enable_pattern_examples,
                        pattern_service_url=self.config.pattern_service_url,
                        max_examples_per_entity=self.config.max_examples_per_entity,
                        pattern_confidence_boost=self.config.pattern_confidence_boost,
                        processing_timeout_seconds=self.config.processing_timeout_seconds,
                        enable_parallel_processing=self.config.enable_parallel_processing
                    )
                    
                    self.enhanced_service = EnhancedCALESService(
                        config=enhanced_config,
                        vllm_client=self.vllm_client,
                        supabase_client=self.supabase_client
                    )
                    await self.enhanced_service.initialize()
                    logger.info("✅ Enhanced CALES service initialized")
                except Exception as e:
                    logger.error(f"Failed to initialize enhanced CALES service: {e}")
                    if not self.config.fallback_to_legacy:
                        raise
                    self.enhanced_service = None
            
            # Initialize legacy service if enabled or as fallback
            if self.config.enable_legacy_components or self.enhanced_service is None:
                try:
                    legacy_config = CALESConfig(
                        enable_dynamic_models=True,
                        enable_context_resolution=True,
                        enable_relationship_extraction=True,
                        enable_unpatterned_handling=True,
                        context_confidence_threshold=0.6,
                        relationship_confidence_threshold=0.5,
                        batch_size=10,
                        max_concurrent_extractions=5
                    )
                    
                    self.legacy_service = ContextAwareExtractionService(
                        config=legacy_config,
                        vllm_client=self.vllm_client,
                        supabase_client=self.supabase_client
                    )
                    await self.legacy_service.initialize()
                    logger.info("✅ Legacy CALES service initialized")
                except Exception as e:
                    logger.error(f"Failed to initialize legacy CALES service: {e}")
                    if self.enhanced_service is None:
                        raise
                    self.legacy_service = None
            
            self._initialized = True
            logger.info("🚀 Hybrid CALES service fully initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize hybrid CALES service: {e}")
            return False
    
    async def extract_with_hybrid_approach(self,
                                         document_id: str,
                                         content: str,
                                         entity_types: Optional[List[str]] = None,
                                         extraction_strategy: Optional[str] = None,
                                         enable_context: bool = True,
                                         enable_relationships: bool = True) -> Dict[str, Any]:
        """
        Perform extraction using the optimal approach based on configuration.
        
        Args:
            document_id: Unique document identifier
            content: Document content
            entity_types: Specific entity types to extract
            extraction_strategy: Override extraction strategy ('unified' or 'multipass')
            enable_context: Enable context resolution
            enable_relationships: Enable relationship extraction
        
        Returns:
            Comprehensive extraction result combining both approaches
        """
        if not self._initialized:
            raise RuntimeError("Hybrid CALES service not initialized")
        
        start_time = time.time()
        logger.info(f"Starting hybrid extraction for document {document_id}")
        
        try:
            # Primary extraction with enhanced service
            enhanced_result = None
            if self.enhanced_service:
                try:
                    logger.info("Using enhanced CALES service for primary extraction")
                    enhanced_result = await self.enhanced_service.extract_entities_enhanced(
                        content=content,
                        entity_types=entity_types,
                        extraction_strategy=extraction_strategy or "auto"
                    )
                    logger.info(f"Enhanced extraction found {len(enhanced_result.get('entities', []))} entities")
                except Exception as e:
                    logger.warning(f"Enhanced extraction failed, falling back: {e}")
                    enhanced_result = None
            
            # Legacy extraction for context and relationships
            legacy_result = None
            if self.legacy_service and (enable_context or enable_relationships):
                try:
                    logger.info("Using legacy CALES service for context and relationships")
                    
                    # Extract entities if enhanced failed
                    entities = []
                    if enhanced_result and enhanced_result.get('entities'):
                        # Convert enhanced entities to ExtractedEntity format
                        for entity_data in enhanced_result['entities']:
                            entity = ExtractedEntity(
                                text=entity_data.get('text', ''),
                                type=entity_data.get('entity_type', ''),
                                entity_type=entity_data.get('entity_type', ''),
                                start_pos=entity_data.get('start_pos', 0),
                                end_pos=entity_data.get('end_pos', 0),
                                confidence=entity_data.get('confidence', 0.0),
                                extraction_method=entity_data.get('extraction_method', 'enhanced'),
                                metadata=entity_data.get('metadata', {})
                            )
                            entities.append(entity)
                    
                    # Use legacy service for context and relationships
                    if entities:
                        legacy_result = await self.legacy_service.extract_with_context(
                            document_id=document_id,
                            content=content,
                            enable_context=enable_context,
                            enable_relationships=enable_relationships,
                            enable_unpatterned=False,  # Already handled by enhanced
                            existing_entities=entities
                        )
                    else:
                        # Full extraction if enhanced failed
                        legacy_result = await self.legacy_service.extract_with_context(
                            document_id=document_id,
                            content=content,
                            entity_types=entity_types,
                            enable_context=enable_context,
                            enable_relationships=enable_relationships,
                            enable_unpatterned=True
                        )
                        
                    logger.info(f"Legacy extraction added context and relationships")
                except Exception as e:
                    logger.warning(f"Legacy extraction failed: {e}")
                    legacy_result = None
            
            # Combine results
            processing_time = (time.time() - start_time) * 1000
            combined_result = self._combine_extraction_results(
                enhanced_result, legacy_result, document_id, processing_time
            )
            
            logger.info(f"Hybrid extraction completed in {processing_time:.2f}ms")
            return combined_result
            
        except Exception as e:
            logger.error(f"Hybrid extraction failed: {e}")
            processing_time = (time.time() - start_time) * 1000
            return {
                "document_id": document_id,
                "extraction_time": time.time(),
                "processing_time_ms": processing_time,
                "entities": [],
                "contexts": [],
                "relationships": [],
                "extraction_method": "hybrid_failed",
                "success": False,
                "error": str(e)
            }
    
    def _combine_extraction_results(self,
                                  enhanced_result: Optional[Dict[str, Any]],
                                  legacy_result: Optional[CALESExtractionResult],
                                  document_id: str,
                                  processing_time: float) -> Dict[str, Any]:
        """Combine results from enhanced and legacy extraction."""
        
        # Use enhanced entities if available, otherwise legacy
        entities = []
        if enhanced_result and enhanced_result.get('entities'):
            entities = enhanced_result['entities']
        elif legacy_result:
            # Convert legacy entities to dict format
            for entity in legacy_result.entities:
                entities.append({
                    'text': entity.text,
                    'entity_type': entity.entity_type or entity.type,
                    'start_pos': entity.start_pos,
                    'end_pos': entity.end_pos,
                    'confidence': getattr(entity, 'confidence', 0.0),
                    'extraction_method': getattr(entity, 'extraction_method', 'legacy'),
                    'metadata': getattr(entity, 'metadata', {})
                })
        
        # Use legacy context and relationships if available
        contexts = []
        relationships = []
        if legacy_result:
            # Convert legacy contexts to dict format
            for context in legacy_result.resolved_contexts:
                contexts.append({
                    'entity_text': context.entity_text,
                    'context': context.context,
                    'confidence': context.confidence,
                    'context_type': context.context_type
                })
            relationships = legacy_result.relationships
        
        # Determine extraction methods used
        methods_used = []
        if enhanced_result:
            methods_used.append('enhanced_prompts')
            if enhanced_result.get('extraction_strategy'):
                methods_used.append(enhanced_result['extraction_strategy'])
        if legacy_result:
            methods_used.append('legacy_cales')
            methods_used.extend(legacy_result.processing_stages)
        
        return {
            "document_id": document_id,
            "extraction_time": time.time(),
            "processing_time_ms": processing_time,
            "entities": entities,
            "contexts": contexts,
            "relationships": relationships,
            "total_entities": len(entities),
            "extraction_methods": methods_used,
            "enhanced_extraction_success": enhanced_result is not None,
            "legacy_extraction_success": legacy_result is not None,
            "overall_confidence": self._calculate_combined_confidence(entities, contexts),
            "success": len(entities) > 0 or len(contexts) > 0
        }
    
    def _calculate_combined_confidence(self, entities: List[Dict], contexts: List[Dict]) -> float:
        """Calculate overall confidence from combined results."""
        scores = []
        
        # Entity confidence
        if entities:
            entity_scores = [e.get('confidence', 0.0) for e in entities if e.get('confidence', 0.0) > 0]
            if entity_scores:
                scores.append(sum(entity_scores) / len(entity_scores))
        
        # Context confidence
        if contexts:
            context_scores = [c.get('confidence', 0.0) for c in contexts if c.get('confidence', 0.0) > 0]
            if context_scores:
                scores.append(sum(context_scores) / len(context_scores))
        
        return sum(scores) / len(scores) if scores else 0.0
    
    def get_service_status(self) -> Dict[str, Any]:
        """Get status of both services."""
        return {
            "initialized": self._initialized,
            "enhanced_service_available": self.enhanced_service is not None,
            "legacy_service_available": self.legacy_service is not None,
            "configuration": {
                "use_enhanced_prompts": self.config.use_enhanced_prompts,
                "extraction_mode": self.config.extraction_mode.value if self.config.extraction_mode else None,
                "extraction_strategy": self.config.extraction_strategy.value if self.config.extraction_strategy else None,
                "enable_pattern_examples": self.config.enable_pattern_examples,
                "fallback_to_legacy": self.config.fallback_to_legacy
            }
        }
    
    async def cleanup(self):
        """Cleanup both services."""
        logger.info("Cleaning up hybrid CALES services...")
        
        if self.enhanced_service:
            await self.enhanced_service.cleanup()
        
        if self.legacy_service:
            await self.legacy_service.cleanup()
        
        logger.info("Hybrid CALES cleanup completed")


# Factory function for easy instantiation
async def create_hybrid_cales_service(vllm_client=None, supabase_client=None) -> HybridCALESService:
    """Create and initialize a hybrid CALES service with optimal configuration."""
    config = HybridCALESConfig(
        use_enhanced_prompts=True,
        extraction_mode=ExtractionMode.HYBRID,
        extraction_strategy=ExtractionStrategy.AUTO,
        enable_pattern_examples=True,
        pattern_confidence_boost=0.15,
        fallback_to_legacy=True,
        enable_legacy_components=True
    )
    
    service = HybridCALESService(config, vllm_client, supabase_client)
    await service.initialize()
    return service