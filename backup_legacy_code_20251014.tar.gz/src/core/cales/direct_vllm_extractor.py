"""
Direct vLLM Extractor for CALES

This module provides direct vLLM instantiation for entity extraction,
avoiding the HTTP overhead of using port 8080.
Uses Phi-3-mini for efficient inference on GPU 1.
"""

import logging
import json
import re
from typing import List, Dict, Any, Optional, Tuple
import torch

try:
    from vllm import LLM, SamplingParams
    VLLM_AVAILABLE = True
except ImportError:
    VLLM_AVAILABLE = False
    logging.warning("vLLM not available - install with: pip install vllm")

logger = logging.getLogger(__name__)


# Import the shared ExtractedEntity from context_window_extractor
from ..context.context_window_extractor import ExtractedEntity


class DirectVLLMExtractor:
    """
    Direct vLLM instantiation for entity extraction.
    Uses Phi-3-mini-4k-instruct for efficient inference.
    """
    
    def __init__(self, 
                 model_name: str = "microsoft/Phi-3-mini-4k-instruct",
                 gpu_memory_fraction: float = 0.3,
                 max_model_len: int = 4096,
                 device: str = "cuda:1"):
        """
        Initialize direct vLLM extractor.
        
        Args:
            model_name: Model to use for extraction
            gpu_memory_fraction: Fraction of GPU memory to use
            max_model_len: Maximum model context length
            device: Device to use (cuda:1 for GPU 1)
        """
        if not VLLM_AVAILABLE:
            raise ImportError("vLLM is not installed. Install with: pip install vllm")
        
        self.model_name = model_name
        self.device = device
        
        logger.info(f"Initializing vLLM with {model_name} on {device}")
        
        # Initialize vLLM engine directly
        self.llm = LLM(
            model=model_name,
            tensor_parallel_size=1,
            gpu_memory_utilization=gpu_memory_fraction,
            max_model_len=max_model_len,
            trust_remote_code=True,  # Required for Phi-3
            dtype="float16",  # Use fp16 for efficiency
            device=device
        )
        
        # Default sampling parameters for entity extraction
        self.sampling_params = SamplingParams(
            temperature=0.1,  # Low temperature for consistent extraction
            top_p=0.9,
            max_tokens=1024,
            stop=["</entities>", "\n\n", "---"]
        )
        
        logger.info("vLLM extractor initialized successfully")
    
    def create_extraction_prompt(self, 
                                  text: str, 
                                  entity_types: List[str],
                                  include_context: bool = True) -> str:
        """
        Create a prompt for entity extraction.
        
        Args:
            text: Text to extract entities from
            entity_types: List of entity types to extract
            include_context: Whether to extract context/role information
        """
        # Limit text to avoid exceeding context length
        max_text_length = 3000
        if len(text) > max_text_length:
            text = text[:max_text_length] + "..."
        
        # Build entity type description
        entity_desc = ", ".join(entity_types[:20])  # Limit to 20 types
        if len(entity_types) > 20:
            entity_desc += f", and {len(entity_types) - 20} more types"
        
        prompt = f"""You are a legal entity extraction system. Extract all legal entities from the following text.

Entity types to extract: {entity_desc}

Instructions:
1. Extract the exact text of each entity
2. Identify the entity type from the list above
3. If possible, identify the context or role (e.g., plaintiff's counsel, defendant)
4. Be precise and extract only relevant entities

Text to analyze:
{text}

Format your response as a list of entities:
<entities>
- Type: ENTITY_TYPE, Text: "exact extracted text", Context: "role or context if applicable"
</entities>

Extract entities now:
<entities>"""
        
        return prompt
    
    def parse_entities(self, 
                       llm_output: str, 
                       original_text: str) -> List[ExtractedEntity]:
        """
        Parse entities from LLM output.
        
        Args:
            llm_output: Raw output from the LLM
            original_text: Original text for position finding
        """
        entities = []
        
        # Try to parse structured output
        entity_pattern = r'- Type:\s*([A-Z_]+),\s*Text:\s*"([^"]+)"(?:,\s*Context:\s*"([^"]+)")?'
        
        matches = re.finditer(entity_pattern, llm_output)
        
        for match in matches:
            entity_type = match.group(1)
            entity_text = match.group(2)
            context = match.group(3) if match.group(3) else None
            
            # Find position in original text
            start_pos = original_text.find(entity_text)
            end_pos = start_pos + len(entity_text) if start_pos != -1 else None
            
            entity = ExtractedEntity(
                text=entity_text,
                type=entity_type,  # Use 'type' as the primary field
                confidence=0.8,  # Default confidence for vLLM extraction
                start_pos=start_pos if start_pos != -1 else 0,
                end_pos=end_pos if end_pos else 0,
                extraction_method="vllm_direct",
                metadata={"context": context} if context else None  # Store context in metadata
            )
            
            entities.append(entity)
        
        return entities
    
    async def extract_entities(self, 
                               text: str, 
                               entity_types: List[str],
                               batch_size: int = 1) -> List[ExtractedEntity]:
        """
        Extract entities using direct vLLM inference.
        
        Args:
            text: Text to extract from
            entity_types: Entity types to extract
            batch_size: Batch size for processing
        """
        try:
            # Create extraction prompt
            prompt = self.create_extraction_prompt(text, entity_types)
            
            # Generate using vLLM
            outputs = self.llm.generate([prompt], self.sampling_params)
            
            # Parse the output
            llm_output = outputs[0].outputs[0].text
            entities = self.parse_entities(llm_output, text)
            
            logger.info(f"Extracted {len(entities)} entities using vLLM")
            
            return entities
            
        except Exception as e:
            logger.error(f"Error in vLLM extraction: {e}")
            return []
    
    def extract_entities_chunked(self, 
                                 text: str, 
                                 entity_types: List[str],
                                 chunk_size: int = 2000,
                                 overlap: int = 200) -> List[ExtractedEntity]:
        """
        Extract entities from long text by chunking.
        
        Args:
            text: Long text to process
            entity_types: Entity types to extract
            chunk_size: Size of each chunk
            overlap: Overlap between chunks
        """
        entities = []
        seen_entities = set()
        
        # Create overlapping chunks
        chunks = []
        for i in range(0, len(text), chunk_size - overlap):
            chunk = text[i:i + chunk_size]
            chunks.append((i, chunk))
        
        logger.info(f"Processing {len(chunks)} chunks")
        
        # Process each chunk
        for offset, chunk in chunks:
            chunk_entities = self.extract_entities_sync(chunk, entity_types)
            
            for entity in chunk_entities:
                # Adjust positions
                if entity.start_pos is not None:
                    entity.start_pos += offset
                    entity.end_pos += offset
                
                # Deduplicate
                entity_key = (entity.text, entity.entity_type)
                if entity_key not in seen_entities:
                    entities.append(entity)
                    seen_entities.add(entity_key)
        
        return entities
    
    def extract_entities_sync(self, 
                              text: str, 
                              entity_types: List[str]) -> List[ExtractedEntity]:
        """
        Synchronous version of entity extraction.
        
        Args:
            text: Text to extract from
            entity_types: Entity types to extract
        """
        prompt = self.create_extraction_prompt(text, entity_types)
        outputs = self.llm.generate([prompt], self.sampling_params)
        llm_output = outputs[0].outputs[0].text
        return self.parse_entities(llm_output, text)
    
    def extract_unpatterned_entities(self, 
                                     text: str,
                                     unpatterned_types: List[str]) -> List[ExtractedEntity]:
        """
        Extract entities that don't have regex patterns.
        
        Args:
            text: Text to extract from
            unpatterned_types: Entity types without patterns (150 types)
        """
        # Use zero-shot approach for unpatterned entities
        prompt = f"""Identify the following legal entity types in the text:

Entity types (no patterns available):
{', '.join(unpatterned_types[:30])}

Text:
{text[:2000]}

List each entity found with its type:
<entities>"""
        
        outputs = self.llm.generate([prompt], self.sampling_params)
        return self.parse_entities(outputs[0].outputs[0].text, text)
    
    def validate_entities(self, 
                          entities: List[Dict], 
                          text: str) -> List[ExtractedEntity]:
        """
        Validate and enhance entities extracted by other methods.
        
        Args:
            entities: Entities to validate
            text: Original text for context
        """
        if not entities:
            return []
        
        # Create validation prompt
        entity_list = "\n".join([f"- {e.get('text', '')}: {e.get('type', '')}" 
                                 for e in entities[:20]])
        
        prompt = f"""Validate and enhance these extracted legal entities:

{entity_list}

Original text:
{text[:1000]}

For each entity, confirm if it's correct and add context if available:
<entities>"""
        
        outputs = self.llm.generate([prompt], self.sampling_params)
        return self.parse_entities(outputs[0].outputs[0].text, text)
    
    def cleanup(self):
        """Clean up vLLM resources"""
        if hasattr(self, 'llm'):
            del self.llm
            torch.cuda.empty_cache()
            logger.info("vLLM resources cleaned up")


# Lightweight alternative using smaller model
class MiniVLLMExtractor(DirectVLLMExtractor):
    """
    Lightweight vLLM extractor using smaller models for faster inference.
    """
    
    def __init__(self):
        # Use smaller model for faster inference
        super().__init__(
            model_name="microsoft/Phi-3-mini-4k-instruct",  # 3.8B params
            gpu_memory_fraction=0.2,  # Less memory
            max_model_len=2048,  # Shorter context
            device="cuda:1"
        )
        
        # Faster sampling for quick extraction
        self.sampling_params = SamplingParams(
            temperature=0.0,  # Deterministic
            top_p=1.0,
            max_tokens=512,  # Fewer tokens
            stop=["</entities>"]
        )