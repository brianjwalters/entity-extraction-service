"""
Pattern-Based Context Resolution for CALES

Resolves entity context using pattern matching and lightweight semantic analysis
without relying on Blackstone. Uses Legal-BERT-Small for embeddings when needed.
"""

import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import torch
from collections import defaultdict

try:
    from transformers import AutoTokenizer, AutoModel
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

from .hybrid_extraction_pipeline import UnifiedEntity

logger = logging.getLogger(__name__)


class EntityRole(Enum):
    """Legal roles for entities"""
    # Law firm roles
    PLAINTIFF_COUNSEL = "plaintiff_counsel"
    DEFENDANT_COUNSEL = "defendant_counsel"
    APPELLANT_COUNSEL = "appellant_counsel"
    APPELLEE_COUNSEL = "appellee_counsel"
    AMICUS_COUNSEL = "amicus_counsel"
    LOCAL_COUNSEL = "local_counsel"
    FORMER_COUNSEL = "former_counsel"
    
    # Party roles
    PLAINTIFF = "plaintiff"
    DEFENDANT = "defendant"
    APPELLANT = "appellant"
    APPELLEE = "appellee"
    PETITIONER = "petitioner"
    RESPONDENT = "respondent"
    INTERVENOR = "intervenor"
    THIRD_PARTY = "third_party"
    
    # Judge roles
    PRESIDING_JUDGE = "presiding_judge"
    TRIAL_JUDGE = "trial_judge"
    APPELLATE_JUDGE = "appellate_judge"
    MAGISTRATE = "magistrate"
    
    # Date contexts
    FILING_DATE = "filing_date"
    HEARING_DATE = "hearing_date"
    SENTENCING_DATE = "sentencing_date"
    EFFECTIVE_DATE = "effective_date"
    DEADLINE = "deadline"
    
    # Monetary contexts
    DAMAGES = "damages"
    SETTLEMENT = "settlement"
    FINE = "fine"
    BAIL = "bail"
    JUDGMENT = "judgment"
    LEGAL_FEES = "legal_fees"
    
    # Default
    UNKNOWN = "unknown"


@dataclass
class ContextPattern:
    """Pattern for context identification"""
    role: EntityRole
    patterns: List[str]
    confidence_boost: float = 0.1
    requires_proximity: bool = True
    max_distance: int = 50  # Characters


@dataclass
class ResolvedContext:
    """Resolved context for an entity"""
    entity: UnifiedEntity
    primary_role: EntityRole
    confidence: float
    alternative_roles: List[Tuple[EntityRole, float]] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)
    context_window: Optional[str] = None


class PatternContextResolver:
    """
    Resolves entity context using pattern matching without Blackstone.
    Uses Legal-BERT-Small for semantic understanding when needed.
    """
    
    def __init__(self, device: str = "cuda:1", use_embeddings: bool = True):
        """
        Initialize context resolver.
        
        Args:
            device: Device for Legal-BERT embeddings
            use_embeddings: Whether to use Legal-BERT for semantic analysis
        """
        self.device = device
        self.use_embeddings = use_embeddings
        
        # Initialize context patterns
        self.context_patterns = self._initialize_patterns()
        
        # Initialize Legal-BERT for embeddings (optional)
        self.legal_bert = None
        self.tokenizer = None
        if use_embeddings and TRANSFORMERS_AVAILABLE:
            self._initialize_legal_bert()
        
        logger.info("Pattern context resolver initialized")
    
    def _initialize_patterns(self) -> Dict[str, List[ContextPattern]]:
        """Initialize context identification patterns"""
        patterns = {
            "LAW_FIRM": [
                ContextPattern(
                    EntityRole.PLAINTIFF_COUNSEL,
                    ["for plaintiff", "representing plaintiff", "on behalf of plaintiff",
                     "plaintiff's counsel", "attorneys for plaintiff", "counsel for petitioner",
                     "plaintiff's attorneys", "petitioner's counsel"],
                    confidence_boost=0.3
                ),
                ContextPattern(
                    EntityRole.DEFENDANT_COUNSEL,
                    ["for defendant", "representing defendant", "on behalf of defendant",
                     "defendant's counsel", "attorneys for defendant", "defending",
                     "counsel for respondent", "defendant's attorneys", "respondent's counsel"],
                    confidence_boost=0.3
                ),
                ContextPattern(
                    EntityRole.APPELLANT_COUNSEL,
                    ["for appellant", "representing appellant", "appellant's counsel",
                     "attorneys for appellant", "on appeal"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.APPELLEE_COUNSEL,
                    ["for appellee", "representing appellee", "appellee's counsel",
                     "attorneys for appellee", "responding on appeal"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.AMICUS_COUNSEL,
                    ["amicus curiae", "as amicus", "friend of the court",
                     "amicus brief", "in support of"],
                    confidence_boost=0.2
                ),
                ContextPattern(
                    EntityRole.FORMER_COUNSEL,
                    ["formerly represented", "withdrew as counsel", "former counsel",
                     "previously represented", "no longer representing"],
                    confidence_boost=0.2
                ),
            ],
            "PARTY": [
                ContextPattern(
                    EntityRole.PLAINTIFF,
                    ["plaintiff", "petitioner", "claimant", "complainant",
                     "filed suit", "brings this action", "commenced this action"],
                    confidence_boost=0.3
                ),
                ContextPattern(
                    EntityRole.DEFENDANT,
                    ["defendant", "respondent", "defending party", "accused",
                     "named as defendant", "sued by", "action against"],
                    confidence_boost=0.3
                ),
                ContextPattern(
                    EntityRole.APPELLANT,
                    ["appellant", "appealing party", "appeals from", "challenging"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.APPELLEE,
                    ["appellee", "responding party", "upholds", "defends judgment"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.INTERVENOR,
                    ["intervenor", "intervening party", "motion to intervene",
                     "granted intervention", "seeks to intervene"],
                    confidence_boost=0.2
                ),
                ContextPattern(
                    EntityRole.THIRD_PARTY,
                    ["third party", "third-party defendant", "third-party plaintiff",
                     "impleaded", "joined as"],
                    confidence_boost=0.2
                ),
            ],
            "JUDGE": [
                ContextPattern(
                    EntityRole.PRESIDING_JUDGE,
                    ["presiding", "chief judge", "senior judge", "presiding justice",
                     "panel chair", "before the honorable"],
                    confidence_boost=0.3
                ),
                ContextPattern(
                    EntityRole.TRIAL_JUDGE,
                    ["trial judge", "district judge", "trial court", "lower court",
                     "ruled", "ordered", "granted", "denied"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.APPELLATE_JUDGE,
                    ["appellate judge", "circuit judge", "appeals court", "panel member",
                     "affirmed", "reversed", "remanded", "opinion by"],
                    confidence_boost=0.25
                ),
                ContextPattern(
                    EntityRole.MAGISTRATE,
                    ["magistrate", "magistrate judge", "referred to magistrate",
                     "report and recommendation", "special master"],
                    confidence_boost=0.2
                ),
            ],
            "DATE": [
                ContextPattern(
                    EntityRole.FILING_DATE,
                    ["filed on", "filing date", "date of filing", "submitted on",
                     "lodged on", "entered on", "docketed", "commenced on"],
                    confidence_boost=0.3,
                    max_distance=30
                ),
                ContextPattern(
                    EntityRole.HEARING_DATE,
                    ["hearing on", "hearing date", "scheduled for hearing",
                     "oral argument", "court hearing", "motion hearing"],
                    confidence_boost=0.25,
                    max_distance=30
                ),
                ContextPattern(
                    EntityRole.SENTENCING_DATE,
                    ["sentenced on", "sentencing date", "judgment entered",
                     "sentence imposed", "sentencing hearing"],
                    confidence_boost=0.25,
                    max_distance=30
                ),
                ContextPattern(
                    EntityRole.DEADLINE,
                    ["deadline", "due by", "must file by", "response due",
                     "expires on", "no later than", "within", "days from"],
                    confidence_boost=0.2,
                    max_distance=30
                ),
            ],
            "MONETARY_AMOUNT": [
                ContextPattern(
                    EntityRole.DAMAGES,
                    ["in damages", "compensatory damages", "punitive damages",
                     "actual damages", "statutory damages", "treble damages",
                     "damage award", "awarded damages"],
                    confidence_boost=0.3,
                    max_distance=40
                ),
                ContextPattern(
                    EntityRole.SETTLEMENT,
                    ["settlement", "settled for", "settlement amount", "agreed to pay",
                     "settlement agreement", "resolve claims for"],
                    confidence_boost=0.25,
                    max_distance=40
                ),
                ContextPattern(
                    EntityRole.FINE,
                    ["fine", "fined", "penalty", "civil penalty", "criminal fine",
                     "monetary penalty", "assessed a fine"],
                    confidence_boost=0.25,
                    max_distance=40
                ),
                ContextPattern(
                    EntityRole.BAIL,
                    ["bail", "bail amount", "bond", "cash bail", "bail set at",
                     "posted bail", "release on bail", "surety"],
                    confidence_boost=0.25,
                    max_distance=40
                ),
                ContextPattern(
                    EntityRole.JUDGMENT,
                    ["judgment", "judgment amount", "judgment for", "entered judgment",
                     "money judgment", "default judgment"],
                    confidence_boost=0.2,
                    max_distance=40
                ),
            ],
        }
        
        return patterns
    
    def _initialize_legal_bert(self):
        """Initialize Legal-BERT-Small for embeddings"""
        try:
            model_name = "nlpaueb/legal-bert-small-uncased"
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            self.legal_bert = AutoModel.from_pretrained(model_name)
            
            if "cuda" in self.device and torch.cuda.is_available():
                self.legal_bert = self.legal_bert.to(self.device)
                self.legal_bert.eval()
            
            logger.info("Legal-BERT-Small loaded for context embeddings")
        except Exception as e:
            logger.warning(f"Could not load Legal-BERT: {e}")
            self.legal_bert = None
            self.use_embeddings = False
    
    def extract_context_window(self, 
                               entity: UnifiedEntity,
                               document: str,
                               window_size: int = 3) -> str:
        """
        Extract context window around entity.
        
        Args:
            entity: Entity to get context for
            document: Full document text
            window_size: Number of sentences before/after
        """
        if entity.start_pos is None or entity.end_pos is None:
            # If no position, search for entity in text
            entity_pos = document.find(entity.text)
            if entity_pos == -1:
                return ""
            entity.start_pos = entity_pos
            entity.end_pos = entity_pos + len(entity.text)
        
        # Find sentence boundaries
        sentences = re.split(r'[.!?]\s+', document)
        
        # Find which sentence contains the entity
        char_count = 0
        entity_sentence_idx = 0
        
        for i, sentence in enumerate(sentences):
            if char_count <= entity.start_pos < char_count + len(sentence):
                entity_sentence_idx = i
                break
            char_count += len(sentence) + 2  # Account for sentence separator
        
        # Extract window
        start_idx = max(0, entity_sentence_idx - window_size)
        end_idx = min(len(sentences), entity_sentence_idx + window_size + 1)
        
        context_sentences = sentences[start_idx:end_idx]
        context_window = '. '.join(context_sentences)
        
        return context_window
    
    def resolve_context(self, 
                       entity: UnifiedEntity,
                       document: str,
                       context_window: Optional[str] = None) -> ResolvedContext:
        """
        Resolve context for a single entity.
        
        Args:
            entity: Entity to resolve context for
            document: Full document text
            context_window: Pre-extracted context window
        """
        # Extract context window if not provided
        if context_window is None:
            context_window = self.extract_context_window(entity, document)
        
        # Get patterns for entity type
        entity_patterns = self.context_patterns.get(entity.entity_type, [])
        
        if not entity_patterns:
            # No patterns for this entity type
            return ResolvedContext(
                entity=entity,
                primary_role=EntityRole.UNKNOWN,
                confidence=0.5,
                context_window=context_window
            )
        
        # Score each possible role
        role_scores = {}
        role_evidence = defaultdict(list)
        
        for pattern in entity_patterns:
            score = 0.0
            matches = []
            
            # Check each pattern string
            for pattern_str in pattern.patterns:
                if pattern_str.lower() in context_window.lower():
                    # Check proximity if required
                    if pattern.requires_proximity:
                        distance = self._calculate_pattern_distance(
                            entity.text, pattern_str, context_window
                        )
                        if distance <= pattern.max_distance:
                            score += 1.0 + pattern.confidence_boost
                            matches.append(pattern_str)
                    else:
                        score += 1.0 + pattern.confidence_boost
                        matches.append(pattern_str)
            
            if score > 0:
                role_scores[pattern.role] = score
                role_evidence[pattern.role] = matches
        
        # Determine primary role
        if role_scores:
            # Sort by score
            sorted_roles = sorted(role_scores.items(), key=lambda x: x[1], reverse=True)
            primary_role = sorted_roles[0][0]
            primary_confidence = min(0.95, sorted_roles[0][1] / len(entity_patterns[0].patterns))
            
            # Get alternative roles
            alternatives = [(role, score / len(entity_patterns[0].patterns)) 
                          for role, score in sorted_roles[1:3]]
            
            # Get evidence
            evidence = role_evidence[primary_role]
        else:
            primary_role = EntityRole.UNKNOWN
            primary_confidence = 0.3
            alternatives = []
            evidence = []
        
        # Optional: Use embeddings for semantic similarity
        if self.use_embeddings and self.legal_bert and primary_confidence < 0.7:
            semantic_role, semantic_confidence = self._semantic_context_analysis(
                entity, context_window
            )
            if semantic_confidence > primary_confidence:
                primary_role = semantic_role
                primary_confidence = semantic_confidence
        
        return ResolvedContext(
            entity=entity,
            primary_role=primary_role,
            confidence=primary_confidence,
            alternative_roles=alternatives,
            evidence=evidence,
            context_window=context_window
        )
    
    def _calculate_pattern_distance(self, 
                                   entity_text: str,
                                   pattern_text: str,
                                   context: str) -> int:
        """Calculate distance between entity and pattern in context"""
        entity_pos = context.lower().find(entity_text.lower())
        pattern_pos = context.lower().find(pattern_text.lower())
        
        if entity_pos == -1 or pattern_pos == -1:
            return 999  # Large distance if not found
        
        return abs(entity_pos - pattern_pos)
    
    def _semantic_context_analysis(self, 
                                  entity: UnifiedEntity,
                                  context_window: str) -> Tuple[EntityRole, float]:
        """
        Use Legal-BERT embeddings for semantic context analysis.
        
        Args:
            entity: Entity to analyze
            context_window: Context window text
        """
        if not self.legal_bert or not self.tokenizer:
            return EntityRole.UNKNOWN, 0.0
        
        try:
            # Encode context
            inputs = self.tokenizer(
                context_window,
                return_tensors="pt",
                max_length=512,
                truncation=True,
                padding=True
            )
            
            if "cuda" in self.device:
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            with torch.no_grad():
                outputs = self.legal_bert(**inputs)
                # Use CLS token embedding
                context_embedding = outputs.last_hidden_state[:, 0, :]
            
            # Compare with role prototypes (simplified)
            # In production, you'd have pre-computed role embeddings
            role_keywords = {
                EntityRole.PLAINTIFF_COUNSEL: "attorney representing plaintiff",
                EntityRole.DEFENDANT_COUNSEL: "attorney representing defendant",
                EntityRole.PLAINTIFF: "plaintiff party filing lawsuit",
                EntityRole.DEFENDANT: "defendant party being sued",
            }
            
            best_role = EntityRole.UNKNOWN
            best_score = 0.0
            
            for role, keywords in role_keywords.items():
                # Encode role keywords
                role_inputs = self.tokenizer(
                    keywords,
                    return_tensors="pt",
                    max_length=512,
                    truncation=True,
                    padding=True
                )
                
                if "cuda" in self.device:
                    role_inputs = {k: v.to(self.device) for k, v in role_inputs.items()}
                
                with torch.no_grad():
                    role_outputs = self.legal_bert(**role_inputs)
                    role_embedding = role_outputs.last_hidden_state[:, 0, :]
                
                # Calculate cosine similarity
                similarity = torch.cosine_similarity(
                    context_embedding, role_embedding
                ).item()
                
                if similarity > best_score:
                    best_score = similarity
                    best_role = role
            
            # Convert similarity to confidence
            confidence = (best_score + 1) / 2  # Normalize to 0-1
            
            return best_role, confidence
            
        except Exception as e:
            logger.error(f"Semantic analysis failed: {e}")
            return EntityRole.UNKNOWN, 0.0
    
    def resolve_all_contexts(self, 
                            entities: List[UnifiedEntity],
                            document: str) -> List[ResolvedContext]:
        """
        Resolve context for all entities.
        
        Args:
            entities: List of entities to resolve
            document: Full document text
        """
        resolved_contexts = []
        
        for entity in entities:
            context = self.resolve_context(entity, document)
            resolved_contexts.append(context)
        
        # Post-process to ensure consistency
        resolved_contexts = self._ensure_consistency(resolved_contexts)
        
        return resolved_contexts
    
    def _ensure_consistency(self, 
                           contexts: List[ResolvedContext]) -> List[ResolvedContext]:
        """Ensure role assignments are consistent"""
        # Group by entity type
        by_type = defaultdict(list)
        for ctx in contexts:
            by_type[ctx.entity.entity_type].append(ctx)
        
        # Check for conflicts (e.g., multiple plaintiff counsels)
        for entity_type, type_contexts in by_type.items():
            if entity_type == "LAW_FIRM":
                # Check for multiple firms with same role
                role_counts = defaultdict(int)
                for ctx in type_contexts:
                    if ctx.primary_role != EntityRole.UNKNOWN:
                        role_counts[ctx.primary_role] += 1
                
                # If conflicts, reduce confidence for duplicates
                for role, count in role_counts.items():
                    if count > 1:
                        # Reduce confidence for all but highest scoring
                        role_contexts = [c for c in type_contexts if c.primary_role == role]
                        role_contexts.sort(key=lambda x: x.confidence, reverse=True)
                        
                        for i, ctx in enumerate(role_contexts[1:], 1):
                            ctx.confidence *= (0.9 ** i)  # Reduce confidence
        
        return contexts