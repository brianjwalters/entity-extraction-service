"""
Enhanced CALES Service with Pattern-Guided Extraction

This service extends the base CALES functionality with enhanced prompts
that leverage examples from the 75 YAML pattern files.
"""

import asyncio
import logging
import time
import uuid
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .enhanced_cales_config import EnhancedCALESConfig, ExtractionMode, ExtractionStrategy
from ..prompts.template_processor import EnhancedPromptService, PromptConfiguration
from .cales_service import ContextAwareExtractionService, CALESConfig, CALESExtractionResult

logger = logging.getLogger(__name__)


@dataclass
class EnhancedExtractionRequest:
    """Enhanced extraction request with pattern integration."""
    document_id: str
    content: str
    extraction_mode: ExtractionMode = ExtractionMode.HYBRID
    extraction_strategy: ExtractionStrategy = ExtractionStrategy.AUTO
    confidence_threshold: float = 0.7
    entity_types: Optional[List[str]] = None
    enable_relationships: bool = True
    enable_pattern_examples: bool = True
    max_entities: Optional[int] = None
    context_window: int = 500
    previous_results: Optional[List[Dict]] = None  # For multipass


@dataclass
class EnhancedExtractionResult:
    """Enhanced extraction result with pattern validation metrics."""
    extraction_id: str
    document_id: str
    strategy_used: str
    mode_used: str
    processing_time_ms: float
    entities: List[Dict[str, Any]]
    citations: List[Dict[str, Any]]
    relationships: List[Dict[str, Any]]
    pattern_matches: List[Dict[str, Any]]
    confidence_distribution: Dict[str, float]
    extraction_metadata: Dict[str, Any]
    quality_metrics: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class EnhancedCALESService:
    """
    Enhanced CALES service that integrates pattern examples with AI extraction.
    """
    
    def __init__(self, config: EnhancedCALESConfig = None):
        self.config = config or EnhancedCALESConfig.for_production()
        
        # Initialize prompt service with production IP
        prompt_config = PromptConfiguration(
            entity_extraction_service_url=self.config.pattern_service_url,
            examples_per_type=self.config.max_examples_per_entity,
            confidence_threshold=self.config.ai_enhancement_threshold
        )
        
        self.prompt_service = EnhancedPromptService(prompt_config)
        
        # Initialize base CALES service for backward compatibility
        base_cales_config = CALESConfig(
            enable_dynamic_models=self.config.enable_dynamic_models,
            enable_context_resolution=self.config.enable_context_resolution,
            enable_relationship_extraction=self.config.enable_relationship_extraction,
            context_confidence_threshold=self.config.context_confidence_threshold,
            relationship_confidence_threshold=self.config.relationship_confidence_threshold,
            batch_size=self.config.batch_size,
            max_concurrent_extractions=self.config.max_concurrent_extractions,
            cache_contexts=self.config.cache_contexts,
            cache_relationships=self.config.cache_relationships,
            cache_ttl_seconds=self.config.cache_ttl_seconds,
            fallback_to_base_models=self.config.fallback_to_base_models,
            enable_caching=self.config.enable_caching
        )
        
        try:
            self.base_cales = ContextAwareExtractionService(base_cales_config)
        except Exception as e:
            logger.warning(f"Base CALES service initialization failed: {e}")
            self.base_cales = None
        
        # Performance tracking
        self.extraction_stats = {
            "total_extractions": 0,
            "pattern_enhanced_count": 0,
            "hybrid_mode_count": 0,
            "multipass_count": 0,
            "unified_count": 0,
            "avg_processing_time": 0.0,
            "avg_confidence": 0.0,
            "pattern_match_rate": 0.0
        }
        
        logger.info(f"Enhanced CALES service initialized with mode: {self.config.extraction_mode.value}")
    
    async def extract_entities_enhanced(
        self, 
        request: EnhancedExtractionRequest
    ) -> EnhancedExtractionResult:
        """
        Main extraction method using enhanced prompts with pattern examples.
        
        Args:
            request: Enhanced extraction request
            
        Returns:
            Enhanced extraction result with pattern validation
        """
        start_time = time.time()
        extraction_id = f"enhanced_{int(time.time() * 1000)}"
        
        try:
            # Select optimal strategy if auto mode
            if request.extraction_strategy == ExtractionStrategy.AUTO:
                strategy = self._select_optimal_strategy(request.content)
            else:
                strategy = request.extraction_strategy
            
            # Execute extraction based on strategy
            if strategy == ExtractionStrategy.MULTIPASS:
                result = await self._execute_multipass_enhanced(request, extraction_id)
            else:
                result = await self._execute_unified_enhanced(request, extraction_id)
            
            # Calculate processing time
            processing_time = (time.time() - start_time) * 1000
            
            # Apply pattern validation if enabled
            if self.config.enable_pattern_validation:
                result = await self._apply_pattern_validation(result, request)
            
            # Calculate quality metrics
            quality_metrics = self._calculate_enhanced_quality_metrics(result)
            
            # Create enhanced result
            enhanced_result = EnhancedExtractionResult(
                extraction_id=extraction_id,
                document_id=request.document_id,
                strategy_used=strategy.value,
                mode_used=request.extraction_mode.value,
                processing_time_ms=processing_time,
                entities=result.get("entities", []),
                citations=result.get("citations", []),
                relationships=result.get("relationships", []),
                pattern_matches=result.get("pattern_matches", []),
                confidence_distribution=self._calculate_confidence_distribution(result),
                extraction_metadata={
                    "total_entities": len(result.get("entities", [])),
                    "total_citations": len(result.get("citations", [])),
                    "pattern_enhanced": request.enable_pattern_examples,
                    "confidence_threshold": request.confidence_threshold,
                    "extraction_mode": request.extraction_mode.value,
                    "strategy": strategy.value,
                    "prompt_enhanced": True,
                    **result.get("extraction_metadata", {})
                },
                quality_metrics=quality_metrics,
                warnings=result.get("warnings", []),
                errors=result.get("errors", [])
            )
            
            # Update statistics
            self._update_extraction_stats(enhanced_result)
            
            logger.info(
                f"Enhanced extraction completed: {extraction_id}, "
                f"strategy: {strategy.value}, mode: {request.extraction_mode.value}, "
                f"entities: {len(result.get('entities', []))}, "
                f"time: {processing_time:.2f}ms"
            )
            
            return enhanced_result
            
        except Exception as e:
            logger.error(f"Enhanced extraction failed: {e}")
            return EnhancedExtractionResult(
                extraction_id=extraction_id,
                document_id=request.document_id,
                strategy_used="error",
                mode_used=request.extraction_mode.value,
                processing_time_ms=(time.time() - start_time) * 1000,
                entities=[],
                citations=[],
                relationships=[],
                pattern_matches=[],
                confidence_distribution={},
                extraction_metadata={"error": str(e)},
                quality_metrics={},
                errors=[str(e)]
            )
    
    async def _execute_unified_enhanced(
        self, 
        request: EnhancedExtractionRequest, 
        extraction_id: str
    ) -> Dict[str, Any]:
        """
        Execute unified extraction with enhanced prompts.
        """
        try:
            # Create enhanced prompt with pattern examples
            enhanced_prompt = await self.prompt_service.create_extraction_prompt(
                document_text=request.content,
                strategy="unified",
                target_entities=request.entity_types,
                confidence_threshold=request.confidence_threshold
            )
            
            # Log prompt generation if enabled
            if self.config.log_prompt_generation:
                logger.debug(f"Generated enhanced prompt for {extraction_id}: {len(enhanced_prompt)} chars")
            
            # Execute extraction based on mode
            if request.extraction_mode == ExtractionMode.HYBRID:
                # Use both pattern matching and AI with enhanced prompts
                result = await self._execute_hybrid_extraction(enhanced_prompt, request)
            elif request.extraction_mode == ExtractionMode.PATTERN_GUIDED:
                # Use AI guided by pattern examples
                result = await self._execute_pattern_guided_extraction(enhanced_prompt, request)
            elif request.extraction_mode == ExtractionMode.AI_ENHANCED:
                # Use AI with enhanced prompts
                result = await self._execute_ai_enhanced_extraction(enhanced_prompt, request)
            else:
                # Fallback to base CALES if available
                if self.base_cales:
                    base_result = await self.base_cales.extract_entities(
                        document_text=request.content,
                        confidence_threshold=request.confidence_threshold,
                        enable_relationships=request.enable_relationships
                    )
                    result = self._convert_base_result(base_result)
                else:
                    result = {"entities": [], "citations": [], "relationships": []}
            
            # Add unified-specific metadata
            result["extraction_metadata"] = result.get("extraction_metadata", {})
            result["extraction_metadata"].update({
                "strategy": "unified",
                "passes": 1,
                "prompt_enhanced": True,
                "prompt_length": len(enhanced_prompt),
                "pattern_examples_used": request.enable_pattern_examples
            })
            
            return result
            
        except Exception as e:
            logger.error(f"Unified enhanced extraction failed: {e}")
            return {
                "entities": [],
                "citations": [],
                "relationships": [],
                "extraction_metadata": {"error": str(e)},
                "errors": [str(e)]
            }
    
    async def _execute_multipass_enhanced(
        self, 
        request: EnhancedExtractionRequest, 
        extraction_id: str
    ) -> Dict[str, Any]:
        """
        Execute multipass extraction with enhanced prompts for each pass.
        """
        try:
            all_entities = []
            all_citations = []
            all_relationships = []
            all_pattern_matches = []
            pass_results = []
            
            # Execute each configured pass
            for pass_config in self.config.multipass_passes:
                pass_number = pass_config["pass_number"]
                pass_name = pass_config["name"]
                target_entities = pass_config["entity_types"]
                pass_confidence = pass_config["confidence_threshold"]
                
                logger.debug(f"Executing pass {pass_number}: {pass_name}")
                
                # Create enhanced prompt for this pass
                enhanced_prompt = await self.prompt_service.create_extraction_prompt(
                    document_text=request.content,
                    strategy="multipass",
                    pass_number=pass_number,
                    previous_results=all_entities,
                    confidence_threshold=pass_confidence
                )
                
                # Execute pass
                pass_request = EnhancedExtractionRequest(
                    document_id=request.document_id,
                    content=request.content,
                    extraction_mode=request.extraction_mode,
                    extraction_strategy=ExtractionStrategy.UNIFIED,  # Each pass is unified
                    confidence_threshold=pass_confidence,
                    entity_types=target_entities,
                    enable_relationships=request.enable_relationships,
                    enable_pattern_examples=request.enable_pattern_examples,
                    previous_results=all_entities
                )
                
                pass_result = await self._execute_single_pass_enhanced(
                    enhanced_prompt, pass_request, pass_number
                )
                
                # Aggregate results
                pass_entities = pass_result.get("entities", [])
                pass_citations = pass_result.get("citations", [])
                pass_relationships = pass_result.get("relationships", [])
                pass_patterns = pass_result.get("pattern_matches", [])
                
                all_entities.extend(pass_entities)
                all_citations.extend(pass_citations)
                all_relationships.extend(pass_relationships)
                all_pattern_matches.extend(pass_patterns)
                
                # Track pass results
                pass_results.append({
                    "pass_number": pass_number,
                    "pass_name": pass_name,
                    "entities_found": len(pass_entities),
                    "citations_found": len(pass_citations),
                    "relationships_found": len(pass_relationships),
                    "pattern_matches": len(pass_patterns),
                    "confidence_threshold": pass_confidence,
                    "target_entities": target_entities
                })
                
                logger.info(f"Pass {pass_number} completed: {len(pass_entities)} entities")
            
            # Deduplicate results
            final_entities = self._deduplicate_entities(all_entities)
            final_citations = self._deduplicate_entities(all_citations)
            final_relationships = self._deduplicate_relationships(all_relationships)
            
            return {
                "entities": final_entities,
                "citations": final_citations,
                "relationships": final_relationships,
                "pattern_matches": all_pattern_matches,
                "extraction_metadata": {
                    "strategy": "multipass",
                    "passes": len(self.config.multipass_passes),
                    "pass_results": pass_results,
                    "prompt_enhanced": True,
                    "pattern_examples_used": request.enable_pattern_examples,
                    "deduplication_applied": True,
                    "original_entity_count": len(all_entities),
                    "final_entity_count": len(final_entities)
                }
            }
            
        except Exception as e:
            logger.error(f"Multipass enhanced extraction failed: {e}")
            return {
                "entities": [],
                "citations": [],
                "relationships": [],
                "pattern_matches": [],
                "extraction_metadata": {"error": str(e)},
                "errors": [str(e)]
            }
    
    async def _execute_hybrid_extraction(
        self, 
        enhanced_prompt: str, 
        request: EnhancedExtractionRequest
    ) -> Dict[str, Any]:
        """
        Execute hybrid extraction using both patterns and AI with enhanced prompts.
        """
        try:
            # This would integrate with the existing extraction infrastructure
            # For now, return a structured placeholder that maintains compatibility
            
            logger.info(f"Executing hybrid extraction with enhanced prompt ({len(enhanced_prompt)} chars)")
            
            # Placeholder for hybrid extraction
            # In real implementation, this would:
            # 1. Run pattern-based extraction first
            # 2. Use enhanced prompts with AI for validation and enhancement
            # 3. Combine results with confidence scoring
            
            return {
                "entities": [],
                "citations": [],
                "relationships": [],
                "pattern_matches": [],
                "extraction_metadata": {
                    "mode": "hybrid",
                    "prompt_enhanced": True,
                    "prompt_length": len(enhanced_prompt),
                    "note": "Placeholder - needs integration with existing extraction"
                }
            }
            
        except Exception as e:
            logger.error(f"Hybrid extraction failed: {e}")
            return {"entities": [], "citations": [], "relationships": [], "errors": [str(e)]}
    
    async def _execute_pattern_guided_extraction(
        self, 
        enhanced_prompt: str, 
        request: EnhancedExtractionRequest
    ) -> Dict[str, Any]:
        """
        Execute pattern-guided extraction using AI guided by pattern examples.
        """
        # Similar implementation to hybrid but with different weighting
        return await self._execute_hybrid_extraction(enhanced_prompt, request)
    
    async def _execute_ai_enhanced_extraction(
        self, 
        enhanced_prompt: str, 
        request: EnhancedExtractionRequest
    ) -> Dict[str, Any]:
        """
        Execute AI-enhanced extraction with enhanced prompts.
        """
        # Similar implementation focusing on AI with prompt enhancement
        return await self._execute_hybrid_extraction(enhanced_prompt, request)
    
    async def _execute_single_pass_enhanced(
        self, 
        enhanced_prompt: str, 
        request: EnhancedExtractionRequest, 
        pass_number: int
    ) -> Dict[str, Any]:
        """
        Execute a single multipass pass with enhanced prompt.
        """
        try:
            result = await self._execute_hybrid_extraction(enhanced_prompt, request)
            result["pass_number"] = pass_number
            return result
            
        except Exception as e:
            logger.error(f"Pass {pass_number} execution failed: {e}")
            return {"entities": [], "citations": [], "relationships": [], "errors": [str(e)]}
    
    def _select_optimal_strategy(self, content: str) -> ExtractionStrategy:
        """
        Select optimal extraction strategy based on document characteristics.
        """
        content_length = len(content)
        
        # Count legal indicators
        legal_indicators = [
            "citation", "statute", "regulation", "court", "case", "plaintiff", "defendant",
            "motion", "brief", "opinion", "holding", "ruling", "judgment", "appeal",
            "contract", "agreement", "clause", "section", "paragraph"
        ]
        
        complexity_score = sum(1 for indicator in legal_indicators if indicator in content.lower())
        entity_density = complexity_score / max(content_length / 1000, 1)
        
        # Strategy selection logic
        if content_length > 15000 and complexity_score > 20:
            return ExtractionStrategy.MULTIPASS
        elif entity_density > 0.8 or complexity_score > 15:
            return ExtractionStrategy.MULTIPASS
        else:
            return ExtractionStrategy.UNIFIED
    
    async def _apply_pattern_validation(
        self, 
        result: Dict[str, Any], 
        request: EnhancedExtractionRequest
    ) -> Dict[str, Any]:
        """
        Apply pattern-based validation to extraction results.
        """
        # Placeholder for pattern validation
        # Would validate extracted entities against known patterns
        return result
    
    def _calculate_enhanced_quality_metrics(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculate enhanced quality metrics including pattern validation.
        """
        entities = result.get("entities", [])
        citations = result.get("citations", [])
        pattern_matches = result.get("pattern_matches", [])
        
        total_extractions = len(entities) + len(citations)
        
        if total_extractions == 0:
            return {"extraction_quality": 0.0}
        
        # Calculate confidence metrics
        all_confidences = []
        for entity in entities:
            conf = entity.get("confidence", 0.0)
            if isinstance(conf, (int, float)):
                all_confidences.append(conf)
        
        avg_confidence = sum(all_confidences) / len(all_confidences) if all_confidences else 0.0
        high_confidence_count = sum(1 for c in all_confidences if c >= 0.8)
        pattern_enhanced_count = len(pattern_matches)
        
        return {
            "extraction_quality": avg_confidence,
            "average_confidence": avg_confidence,
            "high_confidence_percentage": high_confidence_count / max(total_extractions, 1),
            "pattern_match_rate": pattern_enhanced_count / max(total_extractions, 1),
            "total_extractions": total_extractions,
            "entity_count": len(entities),
            "citation_count": len(citations),
            "relationship_count": len(result.get("relationships", [])),
            "pattern_enhancements": pattern_enhanced_count,
            "confidence_distribution": self._calculate_confidence_distribution(result)
        }
    
    def _calculate_confidence_distribution(self, result: Dict[str, Any]) -> Dict[str, float]:
        """Calculate confidence score distribution."""
        all_confidences = []
        
        for entity in result.get("entities", []):
            conf = entity.get("confidence", 0.0)
            if isinstance(conf, (int, float)):
                all_confidences.append(conf)
        
        if not all_confidences:
            return {}
        
        return {
            "very_low": sum(1 for c in all_confidences if c < 0.5) / len(all_confidences),
            "low": sum(1 for c in all_confidences if 0.5 <= c < 0.7) / len(all_confidences),
            "medium": sum(1 for c in all_confidences if 0.7 <= c < 0.8) / len(all_confidences),
            "high": sum(1 for c in all_confidences if 0.8 <= c < 0.9) / len(all_confidences),
            "very_high": sum(1 for c in all_confidences if c >= 0.9) / len(all_confidences)
        }
    
    def _deduplicate_entities(self, entities: List[Dict]) -> List[Dict]:
        """Remove duplicate entities based on text and position."""
        if not entities:
            return []
        
        unique_entities = []
        seen_combinations = set()
        
        for entity in entities:
            text = entity.get("text", "").strip().lower()
            entity_type = entity.get("entity_type", entity.get("type", ""))
            start = entity.get("start_position", entity.get("start", 0))
            
            key = f"{text}:{entity_type}:{start}"
            
            if key not in seen_combinations:
                seen_combinations.add(key)
                unique_entities.append(entity)
        
        return unique_entities
    
    def _deduplicate_relationships(self, relationships: List[Dict]) -> List[Dict]:
        """Remove duplicate relationships."""
        if not relationships:
            return []
        
        unique_relationships = []
        seen_relationships = set()
        
        for rel in relationships:
            key = f"{rel.get('source', '')}:{rel.get('target', '')}:{rel.get('relationship_type', '')}"
            if key not in seen_relationships:
                seen_relationships.add(key)
                unique_relationships.append(rel)
        
        return unique_relationships
    
    def _convert_base_result(self, base_result: Any) -> Dict[str, Any]:
        """Convert base CALES result to enhanced format."""
        # Convert base CALES result to our enhanced format
        return {
            "entities": [],
            "citations": [],
            "relationships": [],
            "pattern_matches": [],
            "extraction_metadata": {"converted_from_base": True}
        }
    
    def _update_extraction_stats(self, result: EnhancedExtractionResult):
        """Update internal extraction statistics."""
        self.extraction_stats["total_extractions"] += 1
        
        if result.extraction_metadata.get("prompt_enhanced"):
            self.extraction_stats["pattern_enhanced_count"] += 1
        
        if result.mode_used == "hybrid":
            self.extraction_stats["hybrid_mode_count"] += 1
        
        if result.strategy_used == "multipass":
            self.extraction_stats["multipass_count"] += 1
        else:
            self.extraction_stats["unified_count"] += 1
        
        # Update averages
        total = self.extraction_stats["total_extractions"]
        current_time_avg = self.extraction_stats["avg_processing_time"]
        current_conf_avg = self.extraction_stats["avg_confidence"]
        
        self.extraction_stats["avg_processing_time"] = (
            (current_time_avg * (total - 1) + result.processing_time_ms) / total
        )
        
        if result.quality_metrics.get("average_confidence"):
            self.extraction_stats["avg_confidence"] = (
                (current_conf_avg * (total - 1) + result.quality_metrics["average_confidence"]) / total
            )
        
        if result.quality_metrics.get("pattern_match_rate"):
            current_pattern_avg = self.extraction_stats["pattern_match_rate"]
            self.extraction_stats["pattern_match_rate"] = (
                (current_pattern_avg * (total - 1) + result.quality_metrics["pattern_match_rate"]) / total
            )
    
    def get_extraction_statistics(self) -> Dict[str, Any]:
        """Get current extraction statistics."""
        return self.extraction_stats.copy()
    
    def get_configuration(self) -> Dict[str, Any]:
        """Get current service configuration."""
        return self.config.to_dict()