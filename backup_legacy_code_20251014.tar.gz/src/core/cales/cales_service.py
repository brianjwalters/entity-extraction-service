"""
CALES (Context-Aware Legal Entity Service) - Core Integration Service

This service orchestrates all CALES components to provide context-aware entity extraction
with dynamic model loading, relationship extraction, and comprehensive entity handling.
"""

import asyncio
import logging
import time
import uuid
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from ..model_management.dynamic_model_loader import DynamicModelLoader, LoadedModel
from ..context.context_resolver import ContextResolver, ResolvedContext
from .relationship_extractor import RelationshipExtractor  # Use local CALES version
from ..context.context_window_extractor import ExtractedEntity
from .entity_registry import DynamicEntityTypeRegistry

# Import unpatterned handler conditionally to avoid circular imports
try:
    from ..unpatterned.unpatterned_entity_handler import UnpatternedEntityHandler
except ImportError:
    UnpatternedEntityHandler = None

# Configure logging
logger = logging.getLogger(__name__)


@dataclass
class CALESConfig:
    """Configuration for CALES service"""
    # Model configuration
    enable_dynamic_models: bool = True
    enable_context_resolution: bool = True
    enable_relationship_extraction: bool = True
    enable_unpatterned_handling: bool = True
    
    # Performance settings
    context_confidence_threshold: float = 0.6
    relationship_confidence_threshold: float = 0.5
    unpatterned_confidence_threshold: float = 0.4
    batch_size: int = 10
    max_concurrent_extractions: int = 5
    
    # Cache settings
    cache_contexts: bool = True
    cache_relationships: bool = True
    cache_ttl_seconds: int = 3600
    
    # Integration settings
    fallback_to_base_models: bool = True
    backward_compatibility: bool = True
    enable_caching: bool = True


@dataclass
class CALESExtractionResult:
    """Complete CALES extraction result"""
    # Basic extraction info
    extraction_id: str
    document_id: str
    extraction_time: datetime
    processing_time_ms: float
    
    # Extracted entities with context
    entities: List[ExtractedEntity]
    resolved_contexts: List[ResolvedContext]
    relationships: List[Dict[str, Any]]
    unpatterned_entities: List[Dict[str, Any]]
    
    # Quality metrics
    total_entities: int
    context_resolution_rate: float
    relationship_extraction_rate: float
    unpatterned_detection_rate: float
    overall_confidence: float
    
    # Processing metadata
    models_used: Dict[str, str]
    processing_stages: List[str]
    performance_metrics: Dict[str, Any]
    
    # Error handling
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class ContextAwareExtractionService:
    """
    Main CALES service that orchestrates all components for context-aware
    entity extraction with dynamic model loading and backward compatibility.
    """
    
    def __init__(self, 
                 config: Optional[CALESConfig] = None,
                 vllm_client: Optional[Any] = None,
                 supabase_client: Optional[Any] = None):
        """
        Initialize the CALES service.
        
        Args:
            config: CALES configuration
            vllm_client: vLLM client for AI processing
            supabase_client: Supabase client for storage
        """
        self.config = config or CALESConfig()
        self.vllm_client = vllm_client
        self.supabase_client = supabase_client
        
        # Core components - initialized during startup
        self.dynamic_model_loader = None
        self.entity_registry = None
        self.context_resolver = None
        self.relationship_extractor = None
        self.unpatterned_handler = None
        
        # Processing state
        self._initialized = False
        self._extraction_stats = {
            "total_extractions": 0,
            "total_entities": 0,
            "total_contexts": 0,
            "total_relationships": 0,
            "average_processing_time": 0.0
        }
        
        # Cache for contexts and relationships if enabled
        self._context_cache = {} if self.config.cache_contexts else None
        self._relationship_cache = {} if self.config.cache_relationships else None
        
        logger.info("CALES service initialized with configuration")
    
    async def initialize(self) -> bool:
        """
        Initialize all CALES components.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info("Initializing CALES components...")
            
            # Initialize dynamic model loader if enabled
            if self.config.enable_dynamic_models:
                try:
                    self.dynamic_model_loader = DynamicModelLoader(
                        config_path="/srv/luris/be/entity-extraction-service/config/models_config.yaml",
                        cache_size=5,
                        max_memory_gb=8.0
                    )
                    logger.info("✅ Dynamic model loader initialized")
                except Exception as e:
                    if not self.config.fallback_to_base_models:
                        raise
                    logger.warning(f"Dynamic model loader failed, continuing without it: {e}")
            
            # Initialize entity registry
            try:
                self.entity_registry = DynamicEntityTypeRegistry()
                await self.entity_registry.initialize()
                logger.info("✅ Dynamic entity registry initialized")
            except Exception as e:
                logger.error(f"Failed to initialize entity registry: {e}")
                if not self.config.backward_compatibility:
                    raise
            
            # Initialize context resolver if enabled
            if self.config.enable_context_resolution:
                try:
                    self.context_resolver = ContextResolver(
                        dynamic_model_loader=self.dynamic_model_loader,
                        use_semantic_analysis=True,
                        use_dependency_parsing=True,
                        confidence_threshold=self.config.context_confidence_threshold
                    )
                    logger.info("✅ Context resolver initialized")
                except Exception as e:
                    logger.warning(f"Context resolver failed: {e}")
                    if not self.config.fallback_to_base_models:
                        self.context_resolver = None
            
            # Initialize relationship extractor if enabled
            if self.config.enable_relationship_extraction:
                try:
                    self.relationship_extractor = RelationshipExtractor(
                        dynamic_model_loader=self.dynamic_model_loader,
                        vllm_client=self.vllm_client,
                        confidence_threshold=self.config.relationship_confidence_threshold
                    )
                    logger.info("✅ Relationship extractor initialized")
                except Exception as e:
                    logger.warning(f"Relationship extractor failed: {e}")
                    self.relationship_extractor = None
            
            # Initialize unpatterned entity handler if enabled
            if self.config.enable_unpatterned_handling and UnpatternedEntityHandler is not None:
                try:
                    self.unpatterned_handler = UnpatternedEntityHandler(
                        dynamic_model_loader=self.dynamic_model_loader,
                        vllm_client=self.vllm_client,
                        entity_registry=self.entity_registry,
                        confidence_threshold=self.config.unpatterned_confidence_threshold
                    )
                    logger.info("✅ Unpatterned entity handler initialized")
                except Exception as e:
                    logger.warning(f"Unpatterned entity handler failed: {e}")
                    self.unpatterned_handler = None
            else:
                if self.config.enable_unpatterned_handling:
                    logger.warning("Unpatterned entity handler not available due to circular imports")
                self.unpatterned_handler = None
            
            self._initialized = True
            logger.info("🚀 CALES service fully initialized and ready")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize CALES service: {e}")
            return False
    
    async def extract_with_context(self, 
                                  document_id: str,
                                  content: str,
                                  entity_types: Optional[List[str]] = None,
                                  enable_context: bool = True,
                                  enable_relationships: bool = True,
                                  enable_unpatterned: bool = True,
                                  existing_entities: Optional[List[ExtractedEntity]] = None) -> CALESExtractionResult:
        """
        Perform context-aware entity extraction using CALES components.
        
        Args:
            document_id: Unique document identifier
            content: Document content
            entity_types: Specific entity types to extract (optional)
            enable_context: Enable context resolution
            enable_relationships: Enable relationship extraction
            enable_unpatterned: Enable unpatterned entity detection
            existing_entities: Pre-extracted entities (for enhancement only)
        
        Returns:
            Complete CALES extraction result
        """
        if not self._initialized:
            raise RuntimeError("CALES service not initialized. Call initialize() first.")
        
        start_time = time.time()
        extraction_id = str(uuid.uuid4())
        
        logger.info(f"Starting CALES extraction {extraction_id} for document {document_id}")
        
        try:
            # Stage 1: Basic entity extraction (if not provided)
            if existing_entities is None:
                entities = await self._extract_base_entities(content, entity_types)
                processing_stages = ["base_extraction"]
            else:
                entities = existing_entities
                processing_stages = ["enhancement_only"]
            
            # Stage 2: Context resolution
            resolved_contexts = []
            if enable_context and self.context_resolver:
                try:
                    resolved_contexts = await self._resolve_entity_contexts(content, entities)
                    processing_stages.append("context_resolution")
                except Exception as e:
                    logger.warning(f"Context resolution failed: {e}")
            
            # Stage 3: Relationship extraction
            relationships = []
            if enable_relationships and self.relationship_extractor:
                try:
                    relationships = await self._extract_relationships(content, entities, resolved_contexts)
                    processing_stages.append("relationship_extraction")
                except Exception as e:
                    logger.warning(f"Relationship extraction failed: {e}")
            
            # Stage 4: Unpatterned entity detection
            unpatterned_entities = []
            if enable_unpatterned and self.unpatterned_handler:
                try:
                    unpatterned_entities = await self._detect_unpatterned_entities(
                        content, entities, resolved_contexts
                    )
                    processing_stages.append("unpatterned_detection")
                except Exception as e:
                    logger.warning(f"Unpatterned entity detection failed: {e}")
            
            # Calculate metrics
            processing_time = (time.time() - start_time) * 1000
            context_resolution_rate = len(resolved_contexts) / len(entities) if entities else 0.0
            relationship_extraction_rate = len(relationships) / len(entities) if entities else 0.0
            unpatterned_detection_rate = len(unpatterned_entities) / len(entities) if entities else 0.0
            
            # Calculate overall confidence
            overall_confidence = self._calculate_overall_confidence(
                entities, resolved_contexts, relationships, unpatterned_entities
            )
            
            # Update statistics
            self._update_extraction_stats(entities, resolved_contexts, relationships, processing_time)
            
            # Create result
            result = CALESExtractionResult(
                extraction_id=extraction_id,
                document_id=document_id,
                extraction_time=datetime.now(),
                processing_time_ms=processing_time,
                entities=entities,
                resolved_contexts=resolved_contexts,
                relationships=relationships,
                unpatterned_entities=unpatterned_entities,
                total_entities=len(entities),
                context_resolution_rate=context_resolution_rate,
                relationship_extraction_rate=relationship_extraction_rate,
                unpatterned_detection_rate=unpatterned_detection_rate,
                overall_confidence=overall_confidence,
                models_used=await self._get_models_used(),
                processing_stages=processing_stages,
                performance_metrics=self._get_performance_metrics()
            )
            
            logger.info(f"CALES extraction {extraction_id} completed in {processing_time:.2f}ms")
            return result
            
        except Exception as e:
            logger.error(f"CALES extraction {extraction_id} failed: {e}")
            # Return error result with whatever we managed to extract
            return CALESExtractionResult(
                extraction_id=extraction_id,
                document_id=document_id,
                extraction_time=datetime.now(),
                processing_time_ms=(time.time() - start_time) * 1000,
                entities=[],
                resolved_contexts=[],
                relationships=[],
                unpatterned_entities=[],
                total_entities=0,
                context_resolution_rate=0.0,
                relationship_extraction_rate=0.0,
                unpatterned_detection_rate=0.0,
                overall_confidence=0.0,
                models_used={},
                processing_stages=["error"],
                performance_metrics={},
                errors=[str(e)]
            )
    
    async def _extract_base_entities(self, content: str, entity_types: Optional[List[str]]) -> List[ExtractedEntity]:
        """Extract base entities using available extraction methods"""
        entities = []
        logger.info(f"Starting base entity extraction for {len(content)} characters")
        
        try:
            # Import the hybrid extraction pipeline
            from .hybrid_extraction_pipeline import (
                HybridExtractionPipeline,
                ExtractionConfig,
                ExtractionMode
            )
            
            # Initialize pipeline if not already done
            if not hasattr(self, '_extraction_pipeline') or self._extraction_pipeline is None:
                logger.info("Initializing hybrid extraction pipeline for base extraction")
                from .hybrid_extraction_pipeline import HybridExtractionPipeline
                self._extraction_pipeline = HybridExtractionPipeline(device="cuda:1")
                logger.info(f"Pipeline initialized with pattern loader: {self._extraction_pipeline.pattern_loader is not None}")
            
            # Configure extraction - start with regex only
            config = ExtractionConfig(
                mode=ExtractionMode.REGEX_ONLY,  # Start with regex-only mode
                enable_regex=True,  # Enable pattern-based extraction
                enable_fast_ai=False,  # Disable AI for now
                enable_vllm=False,  # Disable vLLM for now
                entity_types=entity_types,
                confidence_threshold=0.5  # Lower threshold to catch more entities
            )
            
            # Perform extraction
            logger.debug(f"Extracting entities from {len(content)} characters of text")
            extraction_result = await self._extraction_pipeline.extract(content, config)
            
            # Convert unified entities to ExtractedEntity format
            for unified_entity in extraction_result.entities:
                # Map entity_type to type field correctly
                entity = ExtractedEntity(
                    text=unified_entity.text,
                    type=unified_entity.entity_type,  # Map entity_type to type
                    entity_type=unified_entity.entity_type,  # Keep both for compatibility
                    start_pos=unified_entity.start_pos,
                    end_pos=unified_entity.end_pos,
                    confidence=unified_entity.confidence,
                    extraction_method=unified_entity.extraction_method,
                    metadata=unified_entity.metadata
                )
                entities.append(entity)
            
            logger.info(f"Base extraction found {len(entities)} entities using {extraction_result.methods_used}")
            
        except ImportError as e:
            logger.error(f"Failed to import hybrid extraction pipeline: {e}")
            import traceback
            logger.error(f"Import traceback: {traceback.format_exc()}")
            # Don't use fallback - let error surface
            raise
        except Exception as e:
            logger.error(f"Base entity extraction failed: {e}")
            import traceback
            logger.error(f"Extraction traceback: {traceback.format_exc()}")
            # Return empty list rather than raising to allow graceful degradation
        
        return entities
    
    async def _resolve_entity_contexts(self, 
                                      content: str, 
                                      entities: List[ExtractedEntity]) -> List[ResolvedContext]:
        """Resolve contexts for all entities"""
        if not self.context_resolver:
            return []
        
        # Use batch processing for efficiency
        return self.context_resolver.batch_resolve_contexts(
            content, 
            entities, 
            batch_size=self.config.batch_size
        )
    
    async def _extract_relationships(self, 
                                   content: str,
                                   entities: List[ExtractedEntity],
                                   contexts: List[ResolvedContext]) -> List[Dict[str, Any]]:
        """Extract relationships between entities"""
        if not self.relationship_extractor:
            return []
        
        try:
            return await self.relationship_extractor.extract_relationships(
                content, entities, contexts
            )
        except Exception as e:
            logger.warning(f"Relationship extraction failed: {e}")
            return []
    
    async def _detect_unpatterned_entities(self,
                                         content: str,
                                         known_entities: List[ExtractedEntity],
                                         contexts: List[ResolvedContext]) -> List[Dict[str, Any]]:
        """Detect unpatterned entities using AI models"""
        if not self.unpatterned_handler:
            return []
        
        try:
            return await self.unpatterned_handler.detect_unpatterned_entities(
                content, known_entities, contexts
            )
        except Exception as e:
            logger.warning(f"Unpatterned entity detection failed: {e}")
            return []
    
    def _calculate_overall_confidence(self,
                                    entities: List[ExtractedEntity],
                                    contexts: List[ResolvedContext],
                                    relationships: List[Dict[str, Any]],
                                    unpatterned: List[Dict[str, Any]]) -> float:
        """Calculate overall confidence score for the extraction"""
        scores = []
        
        # Entity confidence
        if entities:
            entity_scores = [e.confidence for e in entities if hasattr(e, 'confidence')]
            if entity_scores:
                scores.append(sum(entity_scores) / len(entity_scores))
        
        # Context confidence
        if contexts:
            context_scores = [c.confidence for c in contexts]
            if context_scores:
                scores.append(sum(context_scores) / len(context_scores))
        
        # Relationship confidence
        if relationships:
            rel_scores = [r.get('confidence', 0.5) for r in relationships]
            if rel_scores:
                scores.append(sum(rel_scores) / len(rel_scores))
        
        # Unpatterned confidence
        if unpatterned:
            unp_scores = [u.get('confidence', 0.4) for u in unpatterned]
            if unp_scores:
                scores.append(sum(unp_scores) / len(unp_scores))
        
        return sum(scores) / len(scores) if scores else 0.0
    
    def _update_extraction_stats(self,
                               entities: List[ExtractedEntity],
                               contexts: List[ResolvedContext],
                               relationships: List[Dict[str, Any]],
                               processing_time: float):
        """Update internal extraction statistics"""
        self._extraction_stats["total_extractions"] += 1
        self._extraction_stats["total_entities"] += len(entities)
        self._extraction_stats["total_contexts"] += len(contexts)
        self._extraction_stats["total_relationships"] += len(relationships)
        
        # Update average processing time
        current_avg = self._extraction_stats["average_processing_time"]
        total_extractions = self._extraction_stats["total_extractions"]
        new_avg = ((current_avg * (total_extractions - 1)) + processing_time) / total_extractions
        self._extraction_stats["average_processing_time"] = new_avg
    
    async def _get_models_used(self) -> Dict[str, str]:
        """Get information about models currently in use"""
        models_used = {}
        
        if self.dynamic_model_loader:
            available_models = self.dynamic_model_loader.list_available_models()
            models_used["dynamic_loader"] = "available"
            if available_models.get("deployed_model"):
                models_used["deployed_model"] = available_models["deployed_model"]
        
        if self.context_resolver:
            models_used["context_resolver"] = "active"
            
        if self.relationship_extractor:
            models_used["relationship_extractor"] = "active"
            
        if self.unpatterned_handler:
            models_used["unpatterned_handler"] = "active"
        
        return models_used
    
    def _get_performance_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics"""
        return {
            "total_extractions": self._extraction_stats["total_extractions"],
            "average_processing_time_ms": self._extraction_stats["average_processing_time"],
            "cache_hit_rate": 0.0,  # Would implement with actual cache
            "memory_usage_mb": 0.0,  # Would implement with memory monitoring
        }
    
    async def enhance_existing_extraction(self,
                                        document_id: str,
                                        content: str,
                                        existing_entities: List[ExtractedEntity],
                                        enable_context: bool = True,
                                        enable_relationships: bool = True) -> CALESExtractionResult:
        """
        Enhance existing entity extraction with CALES capabilities.
        Provides backward compatibility with existing extraction pipelines.
        
        Args:
            document_id: Document identifier
            content: Document content
            existing_entities: Previously extracted entities
            enable_context: Enable context resolution
            enable_relationships: Enable relationship extraction
        
        Returns:
            Enhanced extraction result
        """
        return await self.extract_with_context(
            document_id=document_id,
            content=content,
            enable_context=enable_context,
            enable_relationships=enable_relationships,
            enable_unpatterned=False,  # Don't detect new entities, just enhance existing
            existing_entities=existing_entities
        )
    
    def get_service_health(self) -> Dict[str, Any]:
        """Get CALES service health status"""
        return {
            "initialized": self._initialized,
            "components": {
                "dynamic_model_loader": self.dynamic_model_loader is not None,
                "entity_registry": self.entity_registry is not None,
                "context_resolver": self.context_resolver is not None,
                "relationship_extractor": self.relationship_extractor is not None,
                "unpatterned_handler": self.unpatterned_handler is not None
            },
            "statistics": self._extraction_stats.copy(),
            "config": {
                "enable_dynamic_models": self.config.enable_dynamic_models,
                "enable_context_resolution": self.config.enable_context_resolution,
                "enable_relationship_extraction": self.config.enable_relationship_extraction,
                "enable_unpatterned_handling": self.config.enable_unpatterned_handling
            }
        }
    
    async def cleanup(self):
        """Cleanup CALES resources"""
        logger.info("Cleaning up CALES service...")
        
        if self.dynamic_model_loader:
            self.dynamic_model_loader.clear_cache()
        
        # Clear caches
        if self._context_cache:
            self._context_cache.clear()
        if self._relationship_cache:
            self._relationship_cache.clear()
        
        logger.info("CALES service cleanup completed")