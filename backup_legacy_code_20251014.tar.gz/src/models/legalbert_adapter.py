"""
CaseHOLD/LegalBERT with LoRA Adapter Implementation for Entity Extraction.

This module implements a production-ready entity extraction system using
CaseHOLD/LegalBERT as the base model with LoRA adapters for the 31+ entity types.
"""

import torch
import torch.nn as nn
from transformers import (
    AutoModel, 
    AutoTokenizer, 
    AutoConfig,
    TrainingArguments,
    Trainer
)
from peft import (
    LoraConfig,
    TaskType,
    get_peft_model,
    PeftModel
)
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
from dataclasses import dataclass
import json
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


@dataclass
class EntityExtractionConfig:
    """Configuration for LegalBERT entity extraction with LoRA."""
    
    # Model configuration
    model_name: str = "casehold/legalbert"
    max_length: int = 512
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    
    # LoRA configuration
    lora_r: int = 16  # Rank for LoRA matrices
    lora_alpha: int = 32  # Scaling parameter
    lora_dropout: float = 0.1
    target_modules: List[str] = None  # Will be set to ["q_proj", "v_proj"]
    
    # Training configuration
    learning_rate: float = 2e-4
    batch_size: int = 16
    num_epochs: int = 3
    warmup_steps: int = 500
    
    # Entity types from your system
    entity_types: List[str] = None  # Will be populated from EntityType enum
    
    # Optimization settings
    use_8bit: bool = False  # Enable for QLoRA
    gradient_checkpointing: bool = True
    mixed_precision: str = "fp16"  # or "bf16" for newer GPUs
    
    def __post_init__(self):
        if self.target_modules is None:
            self.target_modules = ["query", "value"]  # BERT attention layers
        
        if self.entity_types is None:
            # Import your entity types
            from models.entities import EntityType
            self.entity_types = [e.value for e in EntityType]


class LegalBERTEntityExtractor:
    """
    Production-ready entity extractor using CaseHOLD/LegalBERT with LoRA adapters.
    
    This implementation:
    1. Uses CaseHOLD/LegalBERT as the frozen base model
    2. Adds LoRA adapters for efficient fine-tuning
    3. Supports all 31+ entity types from your system
    4. Integrates with existing regex patterns for training data
    5. Provides sub-100ms inference with optimization
    """
    
    def __init__(self, config: EntityExtractionConfig = None):
        """Initialize the LegalBERT entity extractor."""
        self.config = config or EntityExtractionConfig()
        self.device = torch.device(self.config.device)
        
        # Load base model and tokenizer
        self._load_base_model()
        
        # Initialize LoRA adapters
        self._initialize_lora_adapters()
        
        # Entity type mappings
        self._setup_entity_mappings()
        
        # Pattern integration
        self.pattern_loader = None  # Will be initialized with PatternLoader
        
        logger.info(f"Initialized LegalBERT extractor on {self.device}")
    
    def _load_base_model(self):
        """Load CaseHOLD/LegalBERT base model."""
        logger.info(f"Loading {self.config.model_name}...")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            use_fast=True
        )
        
        # Load model configuration
        model_config = AutoConfig.from_pretrained(self.config.model_name)
        model_config.num_labels = len(self.config.entity_types) + 1  # +1 for O tag
        
        # Load base model
        if self.config.use_8bit:
            # QLoRA: Load in 8-bit for memory efficiency
            from transformers import BitsAndBytesConfig
            
            bnb_config = BitsAndBytesConfig(
                load_in_8bit=True,
                bnb_8bit_compute_dtype=torch.float16
            )
            
            self.base_model = AutoModel.from_pretrained(
                self.config.model_name,
                config=model_config,
                quantization_config=bnb_config,
                device_map="auto"
            )
        else:
            # Standard loading
            self.base_model = AutoModel.from_pretrained(
                self.config.model_name,
                config=model_config
            ).to(self.device)
        
        # Freeze base model parameters
        for param in self.base_model.parameters():
            param.requires_grad = False
        
        # Add classification head for token classification
        self.classifier = nn.Linear(
            model_config.hidden_size,
            model_config.num_labels
        ).to(self.device)
        
        logger.info(f"Base model loaded: {self.base_model.config.architectures[0]}")
    
    def _initialize_lora_adapters(self):
        """Initialize LoRA adapters for efficient fine-tuning."""
        logger.info("Initializing LoRA adapters...")
        
        # LoRA configuration
        lora_config = LoraConfig(
            r=self.config.lora_r,
            lora_alpha=self.config.lora_alpha,
            target_modules=self.config.target_modules,
            lora_dropout=self.config.lora_dropout,
            bias="none",
            task_type=TaskType.TOKEN_CLS,  # Token classification task
        )
        
        # Apply LoRA to the model
        self.model = get_peft_model(self.base_model, lora_config)
        
        # Print trainable parameters
        self.model.print_trainable_parameters()
        
        logger.info(f"LoRA adapters initialized with rank={self.config.lora_r}")
    
    def _setup_entity_mappings(self):
        """Setup entity type mappings and label encodings."""
        # Create label to ID mappings
        self.label2id = {"O": 0}  # Outside any entity
        
        for i, entity_type in enumerate(self.config.entity_types, 1):
            self.label2id[f"B-{entity_type}"] = i * 2 - 1  # Begin tag
            self.label2id[f"I-{entity_type}"] = i * 2      # Inside tag
        
        self.id2label = {v: k for k, v in self.label2id.items()}
        
        logger.info(f"Setup {len(self.config.entity_types)} entity types")
    
    def generate_training_data_from_patterns(
        self,
        pattern_loader,
        documents: List[str],
        max_samples: int = 10000
    ) -> List[Dict[str, Any]]:
        """
        Generate training data from existing regex patterns.
        
        This leverages your 295+ regex patterns to create training data
        for the LoRA adapters without manual annotation.
        """
        self.pattern_loader = pattern_loader
        training_data = []
        
        logger.info("Generating training data from regex patterns...")
        
        for doc in documents[:max_samples]:
            # Tokenize document
            tokens = self.tokenizer.tokenize(doc)
            token_labels = ["O"] * len(tokens)
            
            # Apply regex patterns to find entities
            for entity_type in self.config.entity_types:
                patterns = pattern_loader.get_patterns_for_type(entity_type)
                
                for pattern in patterns:
                    matches = pattern.compiled_regex.finditer(doc)
                    
                    for match in matches:
                        start, end = match.span()
                        
                        # Map character positions to token positions
                        token_start = len(self.tokenizer.tokenize(doc[:start]))
                        token_end = len(self.tokenizer.tokenize(doc[:end]))
                        
                        # Label tokens
                        if token_start < len(token_labels):
                            token_labels[token_start] = f"B-{entity_type}"
                            for i in range(token_start + 1, min(token_end, len(token_labels))):
                                token_labels[i] = f"I-{entity_type}"
            
            training_data.append({
                "tokens": tokens,
                "labels": token_labels,
                "text": doc
            })
        
        logger.info(f"Generated {len(training_data)} training samples")
        return training_data
    
    def train(
        self,
        training_data: List[Dict[str, Any]],
        validation_data: Optional[List[Dict[str, Any]]] = None
    ):
        """
        Train LoRA adapters on the entity extraction task.
        
        This is extremely efficient - only trains ~0.1% of parameters.
        """
        logger.info("Starting LoRA adapter training...")
        
        # Prepare datasets
        train_dataset = EntityDataset(
            training_data,
            self.tokenizer,
            self.label2id,
            max_length=self.config.max_length
        )
        
        val_dataset = None
        if validation_data:
            val_dataset = EntityDataset(
                validation_data,
                self.tokenizer,
                self.label2id,
                max_length=self.config.max_length
            )
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir="./legalbert-lora-adapters",
            learning_rate=self.config.learning_rate,
            per_device_train_batch_size=self.config.batch_size,
            per_device_eval_batch_size=self.config.batch_size,
            num_train_epochs=self.config.num_epochs,
            warmup_steps=self.config.warmup_steps,
            logging_steps=100,
            save_steps=500,
            evaluation_strategy="steps" if val_dataset else "no",
            eval_steps=500 if val_dataset else None,
            save_total_limit=3,
            fp16=self.config.mixed_precision == "fp16",
            bf16=self.config.mixed_precision == "bf16",
            gradient_checkpointing=self.config.gradient_checkpointing,
            load_best_model_at_end=True if val_dataset else False,
            metric_for_best_model="eval_f1" if val_dataset else None,
        )
        
        # Initialize trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            tokenizer=self.tokenizer,
            compute_metrics=self._compute_metrics,
        )
        
        # Train
        trainer.train()
        
        # Save adapters
        self.save_adapters("./legalbert-lora-adapters/final")
        
        logger.info("Training completed!")
    
    def _compute_metrics(self, eval_pred):
        """Compute F1, precision, recall for evaluation."""
        predictions, labels = eval_pred
        predictions = np.argmax(predictions, axis=2)
        
        # Remove padding
        true_labels = []
        true_predictions = []
        
        for pred, label in zip(predictions, labels):
            mask = label != -100
            true_labels.extend(label[mask].tolist())
            true_predictions.extend(pred[mask].tolist())
        
        # Calculate metrics
        from sklearn.metrics import f1_score, precision_score, recall_score
        
        return {
            "f1": f1_score(true_labels, true_predictions, average="weighted"),
            "precision": precision_score(true_labels, true_predictions, average="weighted"),
            "recall": recall_score(true_labels, true_predictions, average="weighted"),
        }
    
    @torch.no_grad()
    def extract_entities(
        self,
        text: str,
        confidence_threshold: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Extract entities from text using the fine-tuned model.
        
        Optimized for <100ms inference on GPU.
        """
        self.model.eval()
        
        # Tokenize input
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            max_length=self.config.max_length,
            truncation=True,
            padding=True
        ).to(self.device)
        
        # Get predictions
        outputs = self.model(**inputs)
        logits = self.classifier(outputs.last_hidden_state)
        
        # Apply softmax and get predictions
        probs = torch.softmax(logits, dim=-1)
        predictions = torch.argmax(probs, dim=-1)
        confidences = torch.max(probs, dim=-1).values
        
        # Decode predictions to entities
        entities = self._decode_predictions(
            text,
            inputs,
            predictions[0],
            confidences[0],
            confidence_threshold
        )
        
        return entities
    
    def _decode_predictions(
        self,
        text: str,
        inputs: Dict,
        predictions: torch.Tensor,
        confidences: torch.Tensor,
        threshold: float
    ) -> List[Dict[str, Any]]:
        """Decode model predictions into entity spans."""
        tokens = self.tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
        
        entities = []
        current_entity = None
        
        for i, (token, pred_id, conf) in enumerate(zip(tokens, predictions, confidences)):
            if conf < threshold:
                if current_entity:
                    entities.append(current_entity)
                    current_entity = None
                continue
            
            label = self.id2label[pred_id.item()]
            
            if label.startswith("B-"):
                # Start of new entity
                if current_entity:
                    entities.append(current_entity)
                
                entity_type = label[2:]
                current_entity = {
                    "entity_type": entity_type,
                    "tokens": [token],
                    "start_idx": i,
                    "end_idx": i,
                    "confidence": conf.item()
                }
            
            elif label.startswith("I-") and current_entity:
                # Continuation of entity
                current_entity["tokens"].append(token)
                current_entity["end_idx"] = i
                current_entity["confidence"] = min(
                    current_entity["confidence"],
                    conf.item()
                )
            
            elif label == "O" and current_entity:
                # End of entity
                entities.append(current_entity)
                current_entity = None
        
        # Don't forget last entity
        if current_entity:
            entities.append(current_entity)
        
        # Convert token indices to character spans
        return self._tokens_to_spans(text, inputs, entities)
    
    def _tokens_to_spans(
        self,
        text: str,
        inputs: Dict,
        entities: List[Dict]
    ) -> List[Dict[str, Any]]:
        """Convert token-based entities to character spans."""
        result = []
        
        for entity in entities:
            # Reconstruct text from tokens
            entity_text = self.tokenizer.convert_tokens_to_string(
                entity["tokens"]
            ).strip()
            
            # Find character positions (approximate)
            start_char = text.find(entity_text)
            if start_char != -1:
                end_char = start_char + len(entity_text)
                
                result.append({
                    "text": entity_text,
                    "entity_type": entity["entity_type"],
                    "start": start_char,
                    "end": end_char,
                    "confidence": entity["confidence"]
                })
        
        return result
    
    def save_adapters(self, path: str):
        """Save LoRA adapters to disk."""
        Path(path).mkdir(parents=True, exist_ok=True)
        self.model.save_pretrained(path)
        logger.info(f"Adapters saved to {path}")
    
    def load_adapters(self, path: str):
        """Load LoRA adapters from disk."""
        self.model = PeftModel.from_pretrained(
            self.base_model,
            path
        )
        logger.info(f"Adapters loaded from {path}")
    
    def merge_and_export(self, output_path: str):
        """
        Merge LoRA adapters with base model for deployment.
        
        This creates a single model file for easier deployment.
        """
        logger.info("Merging adapters with base model...")
        
        # Merge adapters
        merged_model = self.model.merge_and_unload()
        
        # Save merged model
        merged_model.save_pretrained(output_path)
        self.tokenizer.save_pretrained(output_path)
        
        logger.info(f"Merged model saved to {output_path}")


class EntityDataset(torch.utils.data.Dataset):
    """Dataset for entity extraction training."""
    
    def __init__(
        self,
        data: List[Dict],
        tokenizer,
        label2id: Dict,
        max_length: int = 512
    ):
        self.data = data
        self.tokenizer = tokenizer
        self.label2id = label2id
        self.max_length = max_length
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Tokenize
        encoding = self.tokenizer(
            item["text"],
            truncation=True,
            padding="max_length",
            max_length=self.max_length,
            return_tensors="pt"
        )
        
        # Convert labels to IDs
        labels = []
        for label in item["labels"][:self.max_length]:
            labels.append(self.label2id.get(label, 0))
        
        # Pad labels
        labels = labels + [-100] * (self.max_length - len(labels))
        
        return {
            "input_ids": encoding["input_ids"].squeeze(),
            "attention_mask": encoding["attention_mask"].squeeze(),
            "labels": torch.tensor(labels, dtype=torch.long)
        }


def optimize_for_production(model: LegalBERTEntityExtractor):
    """
    Optimize the model for production deployment.
    
    Applies various optimizations for <100ms inference.
    """
    logger.info("Applying production optimizations...")
    
    # 1. Quantization for faster inference
    model.model = torch.quantization.quantize_dynamic(
        model.model,
        {nn.Linear},
        dtype=torch.qint8
    )
    
    # 2. Compile with torch.compile (PyTorch 2.0+)
    if hasattr(torch, 'compile'):
        model.model = torch.compile(model.model, mode="reduce-overhead")
    
    # 3. Enable ONNX export for even faster inference
    # This would be done separately for deployment
    
    logger.info("Production optimizations applied")
    return model