"""
Integration of LegalBERT with vLLM for production deployment.

This module enables serving LegalBERT with LoRA adapters through vLLM
for maximum throughput and minimal latency in production.
"""

import asyncio
import json
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import aiohttp
import torch
from pathlib import Path
import time

logger = logging.getLogger(__name__)


@dataclass
class VLLMConfig:
    """Configuration for vLLM deployment of LegalBERT."""
    
    # vLLM server settings
    server_url: str = "http://10.10.0.87:8080"
    api_key: str = "entity-extraction-service"
    
    # Model settings
    model_path: str = "/srv/luris/be/entity-extraction-service/models/legalbert-merged"
    adapter_path: str = "/srv/luris/be/entity-extraction-service/models/legalbert-lora"
    
    # Performance settings
    max_model_len: int = 2048
    max_num_seqs: int = 256  # High batching for throughput
    max_num_batched_tokens: int = 8192
    gpu_memory_utilization: float = 0.90
    
    # Inference settings
    temperature: float = 0.01  # Near-deterministic for NER
    top_p: float = 0.95
    max_tokens: int = 512
    
    # Optimization
    use_async: bool = True
    batch_size: int = 32
    timeout: float = 10.0


class LegalBERTVLLMServer:
    """
    vLLM server wrapper for LegalBERT with LoRA adapters.
    
    This class handles:
    1. Model deployment to vLLM
    2. Request batching and optimization
    3. Async processing for high throughput
    4. Integration with existing entity extraction pipeline
    """
    
    def __init__(self, config: VLLMConfig = None):
        self.config = config or VLLMConfig()
        self.session = None
        self.is_ready = False
        
    async def initialize(self):
        """Initialize vLLM server connection."""
        self.session = aiohttp.ClientSession()
        
        # Check if model is loaded
        if await self.health_check():
            logger.info("vLLM server is ready")
            self.is_ready = True
        else:
            logger.warning("vLLM server not responding, attempting to load model...")
            await self.load_model()
    
    async def health_check(self) -> bool:
        """Check if vLLM server is healthy."""
        try:
            async with self.session.get(
                f"{self.config.server_url}/health",
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return response.status == 200
        except:
            return False
    
    async def load_model(self):
        """Load LegalBERT model with LoRA adapters into vLLM."""
        logger.info("Loading LegalBERT into vLLM server...")
        
        # This would typically be done via vLLM CLI:
        # vllm serve /path/to/legalbert-merged \
        #   --lora-modules legalbert=/path/to/lora-adapter \
        #   --max-model-len 2048 \
        #   --max-num-seqs 256 \
        #   --gpu-memory-utilization 0.90
        
        load_config = {
            "model": self.config.model_path,
            "lora_modules": {
                "legalbert": self.config.adapter_path
            },
            "max_model_len": self.config.max_model_len,
            "max_num_seqs": self.config.max_num_seqs,
            "gpu_memory_utilization": self.config.gpu_memory_utilization,
            "dtype": "float16",
            "enforce_eager": False,  # Use CUDA graphs for speed
        }
        
        # Send load request
        async with self.session.post(
            f"{self.config.server_url}/v1/models/load",
            json=load_config,
            headers={"Authorization": f"Bearer {self.config.api_key}"}
        ) as response:
            if response.status == 200:
                logger.info("Model loaded successfully")
                self.is_ready = True
            else:
                error = await response.text()
                raise RuntimeError(f"Failed to load model: {error}")
    
    async def extract_entities_batch(
        self,
        texts: List[str],
        confidence_threshold: float = 0.7
    ) -> List[List[Dict[str, Any]]]:
        """
        Extract entities from multiple texts in batch.
        
        Optimized for high throughput with vLLM's dynamic batching.
        """
        if not self.is_ready:
            await self.initialize()
        
        # Prepare prompts for NER task
        prompts = [self._create_ner_prompt(text) for text in texts]
        
        # Create batch request
        request_data = {
            "prompts": prompts,
            "use_beam_search": False,
            "temperature": self.config.temperature,
            "top_p": self.config.top_p,
            "max_tokens": self.config.max_tokens,
            "stream": False,
            "lora_request": {
                "lora_name": "legalbert",
                "lora_int_id": 1
            }
        }
        
        # Send batch request
        start_time = time.time()
        
        async with self.session.post(
            f"{self.config.server_url}/v1/completions",
            json=request_data,
            headers={"Authorization": f"Bearer {self.config.api_key}"},
            timeout=aiohttp.ClientTimeout(total=self.config.timeout)
        ) as response:
            if response.status != 200:
                error = await response.text()
                raise RuntimeError(f"vLLM request failed: {error}")
            
            result = await response.json()
        
        elapsed_ms = (time.time() - start_time) * 1000
        logger.info(f"Batch of {len(texts)} processed in {elapsed_ms:.2f}ms "
                   f"({elapsed_ms/len(texts):.2f}ms per doc)")
        
        # Parse results
        entities_batch = []
        for i, choice in enumerate(result["choices"]):
            entities = self._parse_ner_output(
                texts[i],
                choice["text"],
                confidence_threshold
            )
            entities_batch.append(entities)
        
        return entities_batch
    
    async def extract_entities(
        self,
        text: str,
        confidence_threshold: float = 0.7
    ) -> List[Dict[str, Any]]:
        """Extract entities from a single text."""
        results = await self.extract_entities_batch(
            [text],
            confidence_threshold
        )
        return results[0] if results else []
    
    def _create_ner_prompt(self, text: str) -> str:
        """
        Create NER prompt for LegalBERT.
        
        This formats the input for token classification task.
        """
        # For BERT models fine-tuned on NER, we typically use special tokens
        prompt = f"[CLS] {text} [SEP]"
        
        # Add instruction if using instruction-tuned variant
        # prompt = (
        #     "Extract legal entities from the following text. "
        #     "Return entities in BIO format.\n\n"
        #     f"Text: {text}\n\n"
        #     "Entities:"
        # )
        
        return prompt
    
    def _parse_ner_output(
        self,
        original_text: str,
        model_output: str,
        confidence_threshold: float
    ) -> List[Dict[str, Any]]:
        """Parse NER model output into entity list."""
        entities = []
        
        try:
            # Parse BIO tags or structured output
            # This depends on how you format the output during training
            
            # Example: If output is JSON
            if model_output.strip().startswith("{"):
                result = json.loads(model_output)
                for entity in result.get("entities", []):
                    if entity.get("confidence", 1.0) >= confidence_threshold:
                        entities.append(entity)
            
            # Example: If output is BIO format
            else:
                lines = model_output.strip().split("\n")
                current_entity = None
                
                for line in lines:
                    parts = line.split("\t")
                    if len(parts) >= 2:
                        token, tag = parts[0], parts[1]
                        
                        if tag.startswith("B-"):
                            if current_entity:
                                entities.append(current_entity)
                            
                            entity_type = tag[2:]
                            current_entity = {
                                "text": token,
                                "entity_type": entity_type,
                                "confidence": float(parts[2]) if len(parts) > 2 else 1.0
                            }
                        
                        elif tag.startswith("I-") and current_entity:
                            current_entity["text"] += " " + token
                        
                        elif tag == "O" and current_entity:
                            entities.append(current_entity)
                            current_entity = None
                
                if current_entity:
                    entities.append(current_entity)
        
        except Exception as e:
            logger.error(f"Failed to parse NER output: {e}")
        
        # Add position information
        for entity in entities:
            start = original_text.find(entity["text"])
            if start != -1:
                entity["start"] = start
                entity["end"] = start + len(entity["text"])
        
        return entities
    
    async def benchmark(
        self,
        test_documents: List[str],
        iterations: int = 10
    ) -> Dict[str, Any]:
        """
        Benchmark vLLM performance with LegalBERT.
        
        Returns metrics for latency, throughput, and accuracy.
        """
        logger.info(f"Starting benchmark with {len(test_documents)} documents...")
        
        metrics = {
            "total_documents": len(test_documents) * iterations,
            "batch_size": self.config.batch_size,
            "iterations": iterations,
            "latencies_ms": [],
            "throughput_rps": [],
            "entities_extracted": 0
        }
        
        for i in range(iterations):
            start_time = time.time()
            
            # Process in batches
            for j in range(0, len(test_documents), self.config.batch_size):
                batch = test_documents[j:j + self.config.batch_size]
                entities_batch = await self.extract_entities_batch(batch)
                
                for entities in entities_batch:
                    metrics["entities_extracted"] += len(entities)
            
            elapsed = time.time() - start_time
            metrics["latencies_ms"].append(elapsed * 1000)
            metrics["throughput_rps"].append(len(test_documents) / elapsed)
        
        # Calculate statistics
        import numpy as np
        metrics["avg_latency_ms"] = np.mean(metrics["latencies_ms"])
        metrics["p50_latency_ms"] = np.percentile(metrics["latencies_ms"], 50)
        metrics["p95_latency_ms"] = np.percentile(metrics["latencies_ms"], 95)
        metrics["p99_latency_ms"] = np.percentile(metrics["latencies_ms"], 99)
        metrics["avg_throughput_rps"] = np.mean(metrics["throughput_rps"])
        metrics["avg_entities_per_doc"] = (
            metrics["entities_extracted"] / metrics["total_documents"]
        )
        
        logger.info(f"Benchmark Results:")
        logger.info(f"  Avg Latency: {metrics['avg_latency_ms']:.2f}ms")
        logger.info(f"  P95 Latency: {metrics['p95_latency_ms']:.2f}ms")
        logger.info(f"  Throughput: {metrics['avg_throughput_rps']:.2f} docs/sec")
        logger.info(f"  Entities/Doc: {metrics['avg_entities_per_doc']:.2f}")
        
        return metrics
    
    async def close(self):
        """Close the session."""
        if self.session:
            await self.session.close()


class LegalBERTEntityExtractorVLLM:
    """
    High-level entity extractor using LegalBERT through vLLM.
    
    This integrates with your existing entity extraction service.
    """
    
    def __init__(self):
        self.vllm_server = LegalBERTVLLMServer()
        self.is_initialized = False
    
    async def initialize(self):
        """Initialize the vLLM server."""
        await self.vllm_server.initialize()
        self.is_initialized = True
    
    async def extract(
        self,
        document_id: str,
        content: str,
        entity_types: Optional[List[str]] = None,
        confidence_threshold: float = 0.7
    ) -> Dict[str, Any]:
        """
        Extract entities from document content.
        
        Compatible with your existing API structure.
        """
        if not self.is_initialized:
            await self.initialize()
        
        start_time = time.time()
        
        # Extract entities
        entities = await self.vllm_server.extract_entities(
            content,
            confidence_threshold
        )
        
        # Filter by entity types if specified
        if entity_types:
            entities = [
                e for e in entities
                if e["entity_type"] in entity_types
            ]
        
        # Format response
        processing_time_ms = (time.time() - start_time) * 1000
        
        return {
            "extraction_id": f"ext_{document_id}_{int(time.time())}",
            "status": "completed",
            "document_id": document_id,
            "extraction_mode": "legalbert_vllm",
            "processing_time_ms": processing_time_ms,
            "entities": entities,
            "processing_stats": {
                "total_entities": len(entities),
                "processing_time_ms": processing_time_ms,
                "model": "casehold/legalbert",
                "backend": "vllm",
                "confidence_threshold": confidence_threshold
            }
        }
    
    async def extract_chunk(
        self,
        chunk_id: str,
        chunk_content: str,
        whole_document: str,
        document_id: str,
        chunk_index: int
    ) -> Dict[str, Any]:
        """
        Extract entities from a chunk with context.
        
        Compatible with your chunking service integration.
        """
        # Use context window around chunk for better accuracy
        context_size = 200
        start_idx = max(0, chunk_content.find(chunk_content[0]) - context_size)
        end_idx = min(len(whole_document), 
                     chunk_content.find(chunk_content[-1]) + context_size)
        
        content_with_context = whole_document[start_idx:end_idx]
        
        # Extract entities
        entities = await self.vllm_server.extract_entities(content_with_context)
        
        # Adjust positions relative to chunk
        chunk_start = whole_document.find(chunk_content)
        for entity in entities:
            if "start" in entity:
                entity["start"] = entity["start"] - start_idx + chunk_start
                entity["end"] = entity["end"] - start_idx + chunk_start
            
            entity["metadata"] = {
                "chunk_id": chunk_id,
                "chunk_index": chunk_index,
                "extraction_method": "legalbert_vllm"
            }
        
        return {
            "chunk_id": chunk_id,
            "document_id": document_id,
            "chunk_index": chunk_index,
            "entities": entities,
            "processing_time_ms": 0,  # Will be set by actual timing
            "confidence_score": 0.9  # Model confidence
        }


# Integration with existing service
async def integrate_with_entity_service():
    """
    Example of how to integrate LegalBERT with your existing service.
    """
    from models.entities import EntityType
    
    # Initialize extractor
    extractor = LegalBERTEntityExtractorVLLM()
    await extractor.initialize()
    
    # Test with sample document
    test_doc = """
    In Brown v. Board of Education, 347 U.S. 483 (1954), Chief Justice Warren
    delivered the opinion of the Court. The case was argued by Thurgood Marshall
    from the NAACP Legal Defense Fund.
    """
    
    # Extract entities
    result = await extractor.extract(
        document_id="test_001",
        content=test_doc,
        entity_types=["CASE_CITATION", "JUDGE", "ATTORNEY", "LAW_FIRM"]
    )
    
    print(f"Extracted {len(result['entities'])} entities:")
    for entity in result["entities"]:
        print(f"  - {entity['text']} ({entity['entity_type']})")
    
    # Benchmark
    test_docs = [test_doc] * 100
    metrics = await extractor.vllm_server.benchmark(test_docs, iterations=3)
    
    print(f"\nPerformance Metrics:")
    print(f"  Latency P95: {metrics['p95_latency_ms']:.2f}ms")
    print(f"  Throughput: {metrics['avg_throughput_rps']:.2f} docs/sec")
    
    await extractor.vllm_server.close()


if __name__ == "__main__":
    # Run integration test
    asyncio.run(integrate_with_entity_service())