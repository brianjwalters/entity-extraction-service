"""
Contextual Entity Extraction Routes for CALES Integration

Provides new /extract/contextual endpoint for context-aware extraction and
enhances existing /extract endpoint with context-aware capabilities while
maintaining backward compatibility.
"""

import asyncio
import json
import logging
import time
import uuid
from typing import Dict, List, Optional, Any, Union
from datetime import datetime

from fastapi import APIRouter, HTTPException, Request, BackgroundTasks, Query, Depends
from pydantic import BaseModel, Field

# Define logger BEFORE any imports that might use it
logger = logging.getLogger(__name__)

# Import ExtractedEntity separately - it's a basic dataclass always needed
ExtractedEntity = None
try:
    from src.core.context.context_window_extractor import ExtractedEntity
except ImportError:
    try:
        from ...core.context.context_window_extractor import ExtractedEntity
    except ImportError:
        logger.warning("ExtractedEntity import failed - contextual extraction may not work")

# Import CALES components (optional)
try:
    from src.core.cales.cales_service import (
        ContextAwareExtractionService,
        CALESConfig,
        CALESExtractionResult
    )
    from src.core.cales.entity_registry import DynamicEntityTypeRegistry
    from src.core.context.context_resolver import ResolvedContext
except ImportError:
    # Try relative imports
    try:
        from ...core.cales.cales_service import (
            ContextAwareExtractionService,
            CALESConfig,
            CALESExtractionResult
        )
        from ...core.cales.entity_registry import DynamicEntityTypeRegistry
        from ...core.context.context_resolver import ResolvedContext
    except ImportError:
        logger.warning("CALES imports not available - using new lightweight implementation")
        ContextAwareExtractionService = None
        CALESConfig = None
        CALESExtractionResult = None

# Import new lightweight CALES implementation
try:
    from src.core.cales.hybrid_extraction_pipeline import (
        HybridExtractionPipeline,
        ExtractionConfig,
        ExtractionMode,
        ExtractionResult,
        UnifiedEntity
    )
    from src.core.cales.pattern_context_resolver import (
        PatternContextResolver,
        ResolvedContext as PatternResolvedContext,
        EntityRole
    )
    from src.core.cales.relationship_extractor import (
        RelationshipExtractor,
        LegalRelationship,
        RelationshipType
    )
    LIGHTWEIGHT_CALES_AVAILABLE = True
except ImportError:
    logger.warning("Lightweight CALES not available")
    LIGHTWEIGHT_CALES_AVAILABLE = False

router = APIRouter()


# Request/Response Models
class ContextualExtractionRequest(BaseModel):
    """Request model for contextual entity extraction"""
    document_id: str = Field(..., description="Unique document identifier")
    content: str = Field(..., description="Document content to extract entities from")
    
    # Context-aware options
    enable_context: bool = Field(
        default=True, 
        description="Enable context resolution for extracted entities"
    )
    enable_relationships: bool = Field(
        default=True, 
        description="Enable relationship extraction between entities"
    )
    enable_unpatterned: bool = Field(
        default=True, 
        description="Enable detection of unpatterned entities using AI"
    )
    
    # Entity filtering
    entity_types: Optional[List[str]] = Field(
        default=None,
        description="Specific entity types to extract (filters results)"
    )
    confidence_threshold: Optional[float] = Field(
        default=0.6,
        description="Minimum confidence threshold for extraction"
    )
    
    # Processing options
    context_window_size: Optional[int] = Field(
        default=3,
        description="Context window size for analysis (sentences)"
    )
    batch_processing: bool = Field(
        default=True,
        description="Enable batch processing for efficiency"
    )
    
    # Compatibility options
    enhance_existing: bool = Field(
        default=False,
        description="Enhance existing extraction results rather than extracting from scratch"
    )
    existing_entities: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Existing entities to enhance (when enhance_existing=True)"
    )


class EntityWithContext(BaseModel):
    """Entity with resolved context information"""
    # Basic entity information
    text: str = Field(..., description="Entity text")
    type: str = Field(..., description="Entity type")
    entity_type: str = Field(..., description="Entity type")
    start_pos: int = Field(..., description="Start position in document")
    end_pos: int = Field(..., description="End position in document")
    confidence: float = Field(..., description="Extraction confidence")
    
    # Context information
    primary_context: Optional[str] = Field(None, description="Primary context type")
    secondary_contexts: List[str] = Field(default_factory=list, description="Secondary context types")
    context_confidence: float = Field(0.0, description="Context resolution confidence")
    context_window: Optional[str] = Field(None, description="Context window text")
    
    # Metadata
    extraction_method: str = Field("cales", description="Extraction method used")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class RelationshipInfo(BaseModel):
    """Relationship between entities"""
    source_entity: str = Field(..., description="Source entity text")
    target_entity: str = Field(..., description="Target entity text")
    relationship_type: str = Field(..., description="Type of relationship")
    confidence: float = Field(..., description="Relationship confidence")
    evidence: Optional[str] = Field(None, description="Evidence text for relationship")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class UnpatternedEntityInfo(BaseModel):
    """Information about unpatterned entities"""
    text: str = Field(..., description="Entity text")
    suggested_type: str = Field(..., description="Suggested entity type")
    confidence: float = Field(..., description="Detection confidence")
    context: Optional[str] = Field(None, description="Context information")
    reasoning: Optional[str] = Field(None, description="AI reasoning for classification")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class ContextualExtractionResponse(BaseModel):
    """Response model for contextual entity extraction"""
    # Basic response info
    extraction_id: str = Field(..., description="Unique extraction identifier")
    document_id: str = Field(..., description="Document identifier")
    extraction_time: datetime = Field(..., description="Time of extraction")
    processing_time_ms: float = Field(..., description="Processing time in milliseconds")
    
    # Extraction results
    entities: List[EntityWithContext] = Field(
        default_factory=list,
        description="Extracted entities with context information"
    )
    relationships: List[RelationshipInfo] = Field(
        default_factory=list,
        description="Relationships between entities"
    )
    unpatterned_entities: List[UnpatternedEntityInfo] = Field(
        default_factory=list,
        description="Detected unpatterned entities"
    )
    
    # Quality metrics
    total_entities: int = Field(..., description="Total number of entities extracted")
    context_resolution_rate: float = Field(..., description="Rate of successful context resolution")
    relationship_extraction_rate: float = Field(..., description="Rate of successful relationship extraction")
    unpatterned_detection_rate: float = Field(..., description="Rate of unpatterned entity detection")
    overall_confidence: float = Field(..., description="Overall extraction confidence")
    
    # Processing information
    models_used: Dict[str, str] = Field(
        default_factory=dict,
        description="Information about models used"
    )
    processing_stages: List[str] = Field(
        default_factory=list,
        description="Processing stages completed"
    )
    performance_metrics: Dict[str, Any] = Field(
        default_factory=dict,
        description="Performance metrics"
    )
    
    # Error handling
    warnings: List[str] = Field(default_factory=list, description="Processing warnings")
    errors: List[str] = Field(default_factory=list, description="Processing errors")
    
    # Backward compatibility
    extraction_mode: str = Field("contextual", description="Extraction mode used")
    extraction_strategy: str = Field("cales", description="Extraction strategy used")


# Dependency to get CALES service
async def get_cales_service(request: Request) -> ContextAwareExtractionService:
    """Get CALES service from app state"""
    if not hasattr(request.app.state, 'cales_service'):
        raise HTTPException(
            status_code=503,
            detail="CALES service not available - contextual extraction disabled"
        )
    
    cales_service = request.app.state.cales_service
    if not cales_service._initialized:
        raise HTTPException(
            status_code=503,
            detail="CALES service not initialized - please wait and try again"
        )
    
    return cales_service


@router.post("/extract/contextual", response_model=ContextualExtractionResponse)
async def contextual_extract(
    request: ContextualExtractionRequest,
    background_tasks: BackgroundTasks,
    cales_service: ContextAwareExtractionService = Depends(get_cales_service)
) -> ContextualExtractionResponse:
    """
    Context-aware entity extraction using CALES system.
    
    This endpoint provides advanced entity extraction with:
    - Context resolution for extracted entities
    - Relationship extraction between entities
    - Unpatterned entity detection using AI
    - Dynamic model loading capabilities
    - Comprehensive quality metrics
    
    Args:
        request: Contextual extraction request
        background_tasks: Background tasks for logging
        cales_service: CALES service dependency
    
    Returns:
        Contextual extraction response with entities, contexts, and relationships
    """
    start_time = time.time()
    extraction_id = str(uuid.uuid4())
    
    logger.info(f"Starting contextual extraction {extraction_id} for document {request.document_id}")
    
    try:
        # Convert existing entities if provided
        existing_entities = None
        if request.enhance_existing and request.existing_entities:
            existing_entities = _convert_to_extracted_entities(request.existing_entities)
        
        # Perform CALES extraction
        cales_result = await cales_service.extract_with_context(
            document_id=request.document_id,
            content=request.content,
            entity_types=request.entity_types,
            enable_context=request.enable_context,
            enable_relationships=request.enable_relationships,
            enable_unpatterned=request.enable_unpatterned,
            existing_entities=existing_entities
        )
        
        # Convert CALES result to API response format
        response = _convert_cales_result_to_response(cales_result)
        
        # Log successful extraction in background
        background_tasks.add_task(
            _log_extraction_success,
            extraction_id,
            request.document_id,
            response.total_entities,
            response.processing_time_ms
        )
        
        logger.info(f"Contextual extraction {extraction_id} completed successfully")
        return response
        
    except Exception as e:
        processing_time = (time.time() - start_time) * 1000
        error_msg = f"Contextual extraction failed: {str(e)}"
        logger.error(f"Extraction {extraction_id} failed: {error_msg}")
        
        # Log error in background
        background_tasks.add_task(
            _log_extraction_error,
            extraction_id,
            request.document_id,
            error_msg,
            processing_time
        )
        
        # Return error response
        return ContextualExtractionResponse(
            extraction_id=extraction_id,
            document_id=request.document_id,
            extraction_time=datetime.now(),
            processing_time_ms=processing_time,
            entities=[],
            relationships=[],
            unpatterned_entities=[],
            total_entities=0,
            context_resolution_rate=0.0,
            relationship_extraction_rate=0.0,
            unpatterned_detection_rate=0.0,
            overall_confidence=0.0,
            models_used={},
            processing_stages=["error"],
            performance_metrics={},
            errors=[error_msg]
        )


@router.post("/extract/enhance", response_model=ContextualExtractionResponse)
async def enhance_extraction(
    request: ContextualExtractionRequest,
    background_tasks: BackgroundTasks,
    cales_service: ContextAwareExtractionService = Depends(get_cales_service)
) -> ContextualExtractionResponse:
    """
    Enhance existing entity extraction with CALES capabilities.
    
    This endpoint provides backward compatibility by enhancing existing
    extraction results with context resolution and relationship extraction
    without re-extracting entities.
    
    Args:
        request: Enhancement request with existing entities
        background_tasks: Background tasks for logging
        cales_service: CALES service dependency
    
    Returns:
        Enhanced extraction response
    """
    if not request.existing_entities:
        raise HTTPException(
            status_code=400,
            detail="existing_entities required for enhancement mode"
        )
    
    # Force enhancement mode
    request.enhance_existing = True
    request.enable_unpatterned = False  # Don't extract new entities
    
    return await contextual_extract(request, background_tasks, cales_service)


@router.get("/extract/contextual/{extraction_id}/status")
async def get_extraction_status(extraction_id: str) -> Dict[str, Any]:
    """
    Get status of a contextual extraction (placeholder for future async processing).
    
    Args:
        extraction_id: Extraction identifier
    
    Returns:
        Status information
    """
    # Placeholder for future async processing status
    return {
        "extraction_id": extraction_id,
        "status": "completed",  # Would track actual status in real implementation
        "message": "Contextual extraction completed",
        "timestamp": datetime.now().isoformat()
    }


@router.get("/extract/contextual/health")
async def contextual_extraction_health(
    request: Request
) -> Dict[str, Any]:
    """
    Health check for contextual extraction capabilities.
    
    Returns:
        Health status and component information
    """
    try:
        if hasattr(request.app.state, 'cales_service'):
            cales_service = request.app.state.cales_service
            health = cales_service.get_service_health()
            
            return {
                "status": "healthy" if health["initialized"] else "initializing",
                "contextual_extraction": "available",
                "components": health["components"],
                "statistics": health["statistics"],
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {
                "status": "unavailable",
                "contextual_extraction": "disabled",
                "message": "CALES service not configured",
                "timestamp": datetime.now().isoformat()
            }
            
    except Exception as e:
        return {
            "status": "error",
            "contextual_extraction": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }


# Helper Functions
def _convert_to_extracted_entities(entities_data: List[Dict[str, Any]]) -> List[ExtractedEntity]:
    """Convert API entity data to ExtractedEntity objects"""
    extracted_entities = []
    
    for entity_data in entities_data:
        try:
            entity = ExtractedEntity(
                text=entity_data.get('text', ''),
                entity_type=entity_data.get('entity_type', entity_data.get('type', 'unknown')),
                start_pos=entity_data.get('start_pos', entity_data.get('start', 0)),
                end_pos=entity_data.get('end_pos', entity_data.get('end', 0)),
                confidence=entity_data.get('confidence', 0.5),
                extraction_method=entity_data.get('extraction_method', 'existing'),
                metadata=entity_data.get('metadata', {})
            )
            extracted_entities.append(entity)
        except Exception as e:
            logger.warning(f"Failed to convert entity data: {entity_data} - {e}")
    
    return extracted_entities


def _convert_cales_result_to_response(cales_result: CALESExtractionResult) -> ContextualExtractionResponse:
    """Convert CALES result to API response format"""
    
    # Convert entities with contexts
    entities_with_context = []
    context_lookup = {ctx.entity.text: ctx for ctx in cales_result.resolved_contexts}
    
    for entity in cales_result.entities:
        resolved_context = context_lookup.get(entity.text)
        
        entity_with_context = EntityWithContext(
            text=entity.text,
            type=entity.entity_type,  # Set both type and entity_type
            entity_type=entity.entity_type,
            start_pos=entity.start_pos,
            end_pos=entity.end_pos,
            confidence=entity.confidence,
            primary_context=resolved_context.primary_context.value if resolved_context else None,
            secondary_contexts=[ctx.value for ctx in resolved_context.secondary_contexts] if resolved_context else [],
            context_confidence=resolved_context.confidence if resolved_context else 0.0,
            context_window=resolved_context.context_window.text[:200] if resolved_context else None,
            extraction_method=getattr(entity, 'extraction_method', 'cales'),
            metadata=getattr(entity, 'metadata', {})
        )
        entities_with_context.append(entity_with_context)
    
    # Convert relationships
    relationship_info = []
    for rel in cales_result.relationships:
        relationship_info.append(RelationshipInfo(
            source_entity=rel.get('source_entity', ''),
            target_entity=rel.get('target_entity', ''),
            relationship_type=rel.get('relationship_type', 'unknown'),
            confidence=rel.get('confidence', 0.5),
            evidence=rel.get('evidence', ''),
            metadata=rel.get('metadata', {})
        ))
    
    # Convert unpatterned entities
    unpatterned_info = []
    for unp in cales_result.unpatterned_entities:
        unpatterned_info.append(UnpatternedEntityInfo(
            text=unp.get('text', ''),
            suggested_type=unp.get('suggested_type', 'unknown'),
            confidence=unp.get('confidence', 0.4),
            context=unp.get('context', ''),
            reasoning=unp.get('reasoning', ''),
            metadata=unp.get('metadata', {})
        ))
    
    return ContextualExtractionResponse(
        extraction_id=cales_result.extraction_id,
        document_id=cales_result.document_id,
        extraction_time=cales_result.extraction_time,
        processing_time_ms=cales_result.processing_time_ms,
        entities=entities_with_context,
        relationships=relationship_info,
        unpatterned_entities=unpatterned_info,
        total_entities=cales_result.total_entities,
        context_resolution_rate=cales_result.context_resolution_rate,
        relationship_extraction_rate=cales_result.relationship_extraction_rate,
        unpatterned_detection_rate=cales_result.unpatterned_detection_rate,
        overall_confidence=cales_result.overall_confidence,
        models_used=cales_result.models_used,
        processing_stages=cales_result.processing_stages,
        performance_metrics=cales_result.performance_metrics,
        warnings=cales_result.warnings,
        errors=cales_result.errors
    )


async def _log_extraction_success(extraction_id: str, document_id: str, 
                                entity_count: int, processing_time: float):
    """Log successful extraction in background"""
    logger.info(f"Contextual extraction {extraction_id} for document {document_id}: "
               f"{entity_count} entities extracted in {processing_time:.2f}ms")


async def _log_extraction_error(extraction_id: str, document_id: str, 
                              error_msg: str, processing_time: float):
    """Log extraction error in background"""
    logger.error(f"Contextual extraction {extraction_id} for document {document_id} failed "
                f"after {processing_time:.2f}ms: {error_msg}")


# Enhanced extract endpoint for backward compatibility
@router.post("/extract", response_model=None)
async def extract_with_context_option(
    request: Dict[str, Any],
    background_tasks: BackgroundTasks,
    enable_context: bool = Query(
        False, 
        description="Enable context-aware extraction using CALES"
    )
) -> Union[ContextualExtractionResponse, Dict[str, Any]]:
    """
    Enhanced extract endpoint with optional context-aware capabilities.
    
    This endpoint maintains backward compatibility while adding CALES integration:
    - enable_context=False: Uses existing extraction pipeline
    - enable_context=True: Uses CALES for context-aware extraction
    
    Args:
        request: Extraction request (flexible format)
        background_tasks: Background tasks
        enable_context: Enable CALES context-aware extraction
        cales_service: CALES service (optional)
    
    Returns:
        Either contextual or standard extraction response
    """
    # Get CALES service if available
    cales_service = None
    try:
        from src.core.cales.cales_service import ContextAwareExtractionService
        # This would typically come from dependency injection
        # For now, indicate that it would need to be integrated
        pass
    except ImportError:
        pass
        
    if enable_context and cales_service:
        # Convert to contextual extraction request
        contextual_request = ContextualExtractionRequest(
            document_id=request.get('document_id', str(uuid.uuid4())),
            content=request.get('content', ''),
            entity_types=request.get('entity_types'),
            confidence_threshold=request.get('confidence_threshold', 0.6),
            enable_context=True,
            enable_relationships=True,
            enable_unpatterned=True
        )
        
        return await contextual_extract(contextual_request, background_tasks, cales_service)
    else:
        # Fallback to existing extraction service
        # This would integrate with the existing extract endpoint
        raise HTTPException(
            status_code=501,
            detail="Standard extraction fallback not implemented in this endpoint"
        )