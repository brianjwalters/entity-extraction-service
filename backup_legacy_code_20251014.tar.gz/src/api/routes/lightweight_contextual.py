"""
Lightweight Contextual Extraction Endpoint

Uses the new hybrid extraction pipeline with optional vLLM
for fast, efficient entity extraction with context resolution.
"""

import asyncio
import logging
import time
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime

from fastapi import APIRouter, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel, Field

# Import lightweight CALES components
try:
    from src.core.cales.hybrid_extraction_pipeline import (
        HybridExtractionPipeline,
        ExtractionConfig,
        ExtractionMode,
        ExtractionResult,
        UnifiedEntity
    )
    from src.core.cales.pattern_context_resolver import (
        PatternContextResolver,
        ResolvedContext,
        EntityRole
    )
    from src.core.cales.relationship_extractor import (
        RelationshipExtractor,
        LegalRelationship,
        RelationshipType
    )
    LIGHTWEIGHT_AVAILABLE = True
except ImportError:
    LIGHTWEIGHT_AVAILABLE = False
    logging.warning("Lightweight CALES components not available")

logger = logging.getLogger(__name__)
router = APIRouter()

# Global instances (initialized on first use)
_extraction_pipeline = None
_context_resolver = None
_relationship_extractor = None


class LightweightExtractionRequest(BaseModel):
    """Request for lightweight contextual extraction"""
    document_id: str = Field(..., description="Document ID")
    content: str = Field(..., description="Document content")
    
    # Extraction modes
    mode: str = Field(
        default="hybrid",
        description="Extraction mode: regex_only, fast_ai, full_ai, hybrid"
    )
    
    # Feature flags
    enable_regex: bool = Field(default=True, description="Enable regex patterns")
    enable_fast_ai: bool = Field(default=True, description="Enable lightweight NER")
    enable_vllm: bool = Field(default=False, description="Enable vLLM (optional)")
    enable_context: bool = Field(default=True, description="Enable context resolution")
    enable_relationships: bool = Field(default=True, description="Enable relationships")
    enable_unpatterned: bool = Field(default=True, description="Enable unpatterned entities")
    
    # Performance settings
    max_vllm_size: int = Field(default=5000, description="Max doc size for vLLM")
    confidence_threshold: float = Field(default=0.6, description="Min confidence")
    
    # Entity filtering
    entity_types: Optional[List[str]] = Field(None, description="Specific entity types")
    unpatterned_types: Optional[List[str]] = Field(None, description="Unpatterned types")


class LightweightEntity(BaseModel):
    """Entity with lightweight extraction info"""
    text: str
    entity_type: str
    start_pos: Optional[int]
    end_pos: Optional[int]
    confidence: float
    extraction_method: str
    context: Optional[str] = None
    role: Optional[str] = None


class LightweightRelationship(BaseModel):
    """Relationship between entities"""
    source: str
    target: str
    relationship_type: str
    confidence: float
    evidence: str


class LightweightExtractionResponse(BaseModel):
    """Response from lightweight extraction"""
    extraction_id: str
    document_id: str
    extraction_time_ms: float
    
    # Results
    entities: List[LightweightEntity]
    relationships: List[LightweightRelationship]
    
    # Metrics
    total_entities: int
    methods_used: List[str]
    entity_count_by_method: Dict[str, int]
    performance_metrics: Dict[str, float]
    
    # Context metrics
    context_resolution_rate: float = 0.0
    relationship_extraction_rate: float = 0.0
    
    # Warnings
    warnings: List[str] = Field(default_factory=list)


def get_extraction_pipeline() -> "HybridExtractionPipeline":
    """Get or initialize extraction pipeline"""
    global _extraction_pipeline
    if _extraction_pipeline is None:
        _extraction_pipeline = HybridExtractionPipeline(device="cuda:1")
    return _extraction_pipeline


def get_context_resolver() -> "PatternContextResolver":
    """Get or initialize context resolver"""
    global _context_resolver
    if _context_resolver is None:
        _context_resolver = PatternContextResolver(device="cuda:1", use_embeddings=True)
    return _context_resolver


def get_relationship_extractor() -> "RelationshipExtractor":
    """Get or initialize relationship extractor"""
    global _relationship_extractor
    if _relationship_extractor is None:
        _relationship_extractor = RelationshipExtractor(device="cuda:1")
    return _relationship_extractor


@router.post("/extract/lightweight", response_model=LightweightExtractionResponse)
async def extract_lightweight(
    request: LightweightExtractionRequest,
    background_tasks: BackgroundTasks
) -> LightweightExtractionResponse:
    """
    Lightweight contextual extraction endpoint.
    
    Primary extraction methods:
    1. Fast regex patterns (always enabled)
    2. Lightweight NER (DistilBERT, Legal-BERT-small)
    3. Optional vLLM for small documents only
    
    Performance targets:
    - Regex only: < 500ms
    - With lightweight NER: < 3s
    - With vLLM (small docs): < 8s
    """
    if not LIGHTWEIGHT_AVAILABLE:
        raise HTTPException(
            status_code=503,
            detail="Lightweight CALES not available"
        )
    
    start_time = time.time()
    extraction_id = str(uuid.uuid4())
    
    logger.info(f"Starting lightweight extraction {extraction_id}")
    
    try:
        # Get pipeline
        pipeline = get_extraction_pipeline()
        
        # Configure extraction
        config = ExtractionConfig(
            mode=ExtractionMode[request.mode.upper()],
            enable_regex=request.enable_regex,
            enable_fast_ai=request.enable_fast_ai,
            enable_vllm=request.enable_vllm,
            enable_context=request.enable_context,
            enable_relationships=request.enable_relationships,
            enable_unpatterned=request.enable_unpatterned,
            max_document_size_for_vllm=request.max_vllm_size,
            confidence_threshold=request.confidence_threshold,
            entity_types=request.entity_types,
            unpatterned_types=request.unpatterned_types
        )
        
        # Extract entities
        extraction_result = await pipeline.extract(request.content, config)
        
        # Context resolution (if enabled)
        if request.enable_context:
            context_resolver = get_context_resolver()
            resolved_contexts = context_resolver.resolve_all_contexts(
                extraction_result.entities,
                request.content
            )
            
            # Update entities with context
            context_map = {ctx.entity.text: ctx for ctx in resolved_contexts}
            for entity in extraction_result.entities:
                if entity.text in context_map:
                    ctx = context_map[entity.text]
                    entity.context = ctx.primary_role.value
        
        # Relationship extraction (if enabled)
        relationships = []
        if request.enable_relationships and len(extraction_result.entities) > 1:
            rel_extractor = get_relationship_extractor()
            legal_relationships = rel_extractor.extract_relationships(
                extraction_result.entities,
                request.content,
                resolved_contexts if request.enable_context else None
            )
            
            # Convert to response format
            for rel in legal_relationships:
                relationships.append(LightweightRelationship(
                    source=rel.source_entity.text,
                    target=rel.target_entity.text,
                    relationship_type=rel.relationship_type.value,
                    confidence=rel.confidence,
                    evidence=rel.evidence or ""
                ))
        
        # Convert entities to response format
        response_entities = []
        for entity in extraction_result.entities:
            response_entities.append(LightweightEntity(
                text=entity.text,
                entity_type=entity.entity_type,
                start_pos=entity.start_pos,
                end_pos=entity.end_pos,
                confidence=entity.confidence,
                extraction_method=entity.extraction_method,
                context=entity.context,
                role=entity.context  # Same as context for now
            ))
        
        # Calculate metrics
        total_time_ms = (time.time() - start_time) * 1000
        
        # Context resolution rate
        context_rate = 0.0
        if request.enable_context and response_entities:
            with_context = sum(1 for e in response_entities if e.context)
            context_rate = with_context / len(response_entities)
        
        # Relationship rate
        rel_rate = 0.0
        if request.enable_relationships and len(extraction_result.entities) > 1:
            max_possible_rels = len(extraction_result.entities) * (len(extraction_result.entities) - 1) / 2
            if max_possible_rels > 0:
                rel_rate = len(relationships) / max_possible_rels
        
        # Create response
        response = LightweightExtractionResponse(
            extraction_id=extraction_id,
            document_id=request.document_id,
            extraction_time_ms=total_time_ms,
            entities=response_entities,
            relationships=relationships,
            total_entities=len(response_entities),
            methods_used=extraction_result.methods_used,
            entity_count_by_method=extraction_result.entity_count_by_method,
            performance_metrics=extraction_result.performance_metrics,
            context_resolution_rate=context_rate,
            relationship_extraction_rate=rel_rate,
            warnings=extraction_result.warnings
        )
        
        logger.info(
            f"Extraction {extraction_id} complete: "
            f"{len(response_entities)} entities, "
            f"{len(relationships)} relationships, "
            f"{total_time_ms:.2f}ms"
        )
        
        # Log in background
        background_tasks.add_task(
            log_extraction_metrics,
            extraction_id,
            request.document_id,
            response.total_entities,
            total_time_ms,
            response.methods_used
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Extraction {extraction_id} failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Extraction failed: {str(e)}"
        )


@router.get("/extract/lightweight/status")
async def get_lightweight_status():
    """Get status of lightweight extraction components"""
    status = {
        "available": LIGHTWEIGHT_AVAILABLE,
        "pipeline_initialized": _extraction_pipeline is not None,
        "context_resolver_initialized": _context_resolver is not None,
        "relationship_extractor_initialized": _relationship_extractor is not None,
        "device": "cuda:1",
        "models": {
            "distilbert_ner": "dslim/distilbert-NER",
            "legal_bert_small": "nlpaueb/legal-bert-small-uncased",
            "deberta_small": "microsoft/deberta-v3-small",
            "phi3_mini": "microsoft/Phi-3-mini-4k-instruct"
        }
    }
    return status


async def log_extraction_metrics(
    extraction_id: str,
    document_id: str,
    entity_count: int,
    time_ms: float,
    methods: List[str]
):
    """Log extraction metrics (background task)"""
    logger.info(
        f"Extraction metrics - ID: {extraction_id}, "
        f"Doc: {document_id}, "
        f"Entities: {entity_count}, "
        f"Time: {time_ms:.2f}ms, "
        f"Methods: {methods}"
    )